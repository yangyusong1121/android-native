package com.dawoo.lotterybox.view.activity;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.blankj.utilcode.util.ActivityUtils;
import com.blankj.utilcode.util.AppUtils;
import com.blankj.utilcode.util.NetworkUtils;
import com.blankj.utilcode.util.SPUtils;
import com.dawoo.coretool.util.LogUtils;
import com.dawoo.lotterybox.BuildConfig;
import com.dawoo.lotterybox.ConstantValue;
import com.dawoo.lotterybox.R;
import com.dawoo.lotterybox.bean.CheckAccountBean;
import com.dawoo.lotterybox.bean.DataCenter;
import com.dawoo.lotterybox.bean.LoginBean;
import com.dawoo.lotterybox.bean.User;
import com.dawoo.lotterybox.mvp.presenter.UserPresenter;
import com.dawoo.lotterybox.mvp.view.ILoginView;
import com.dawoo.lotterybox.net.HttpResult;
import com.dawoo.lotterybox.util.ActivityUtil;
import com.dawoo.lotterybox.util.BalanceUtils;
import com.dawoo.lotterybox.util.IpConnectHelper;
import com.dawoo.lotterybox.util.MSPropties;
import com.dawoo.lotterybox.util.SPConfig;
import com.dawoo.lotterybox.util.SharePreferenceUtil;
import com.dawoo.lotterybox.view.activity.team.base.OnMultiClickListener;
import com.hwangjr.rxbus.RxBus;
import com.hwangjr.rxbus.annotation.Subscribe;
import com.hwangjr.rxbus.annotation.Tag;
import com.wang.avi.AVLoadingIndicatorView;

import java.util.Objects;

import butterknife.BindView;
import butterknife.ButterKnife;
import skin.support.SkinCompatManager;

/**
 * 过渡页
 * Created by benson on 17-12-27.
 */

public class SplashActivity extends AppCompatActivity implements ILoginView, IpConnectHelper.IpConnectCallback {

    private UserPresenter mPresenter;
    private String mName;
    private String mPwd;
    @BindView(R.id.tvLoading)
    TextView tvLoadingInfo;
    @BindView(R.id.avi)
    AVLoadingIndicatorView aviLoadingView;
    @BindView(R.id.tv_retry)
    TextView tvRetry;
    @BindView(R.id.ll_1)
    LinearLayout llShow;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.acitivity_splash);
        ButterKnife.bind(this);
        RxBus.get().register(this);
        initData();
    }

    private void noNetWork() {
        aviLoadingView.setVisibility(View.GONE);
        tvRetry.setVisibility(View.VISIBLE);
        llShow.setVisibility(View.VISIBLE);
        tvLoadingInfo.setText("网络未链接请检查后重试");
    }

    protected void initData() {

        mPresenter = new UserPresenter(this, this);
        // doLogin();
        IpConnectHelper ipConnectHelper = new IpConnectHelper();
        if (NetworkUtils.isConnected()) {
            if (MSPropties.isApkDebugable()) {
                DataCenter.getInstance().setHost(BuildConfig.HOST_URL).setImgDomain(BuildConfig.HOST_IMG_URL).setDomain(BuildConfig.HOST_URL);

                doLogin();
            } else {
                llShow.setVisibility(View.VISIBLE);
                ipConnectHelper.startConnect(this);
            }
        } else {
            noNetWork();
        }

        tvRetry.setOnClickListener(new OnMultiClickListener() {
            @Override
            public void onMultiClick(View v) {
                aviLoadingView.setVisibility(View.VISIBLE);
                tvRetry.setVisibility(View.GONE);
                tvLoadingInfo.setText("重新获取线路");
                if (MSPropties.isApkDebugable()) {
                    if (!NetworkUtils.isConnected()) {
                        noNetWork();
                        return;
                    }
                    DataCenter.getInstance().setHost(BuildConfig.HOST_URL).setImgDomain(BuildConfig.HOST_IMG_URL).setDomain(BuildConfig.HOST_URL);
                    doLogin();
                } else {
                    ipConnectHelper.getLine(SplashActivity.this);
                }
            }
        });
    }


    @Override
    public void doLogin() {
        mName = SPUtils.getInstance().getString(SPConfig.USERNAME);
        mPwd = SPUtils.getInstance().getString(SPConfig.PASSWORD);
        if (Objects.equals("", mPwd)) {
            goNextActivity();
        } else {
            llShow.setVisibility(View.VISIBLE);
            tvLoadingInfo.setText("拉取用户数据");
            String appKey = getResources().getString(R.string.app_key);
            String appSecret = getResources().getString(R.string.app_secret);
            String serialNo = DataCenter.getInstance().getSysInfo().getMac();
            mPresenter.login(mName, mPwd, appKey, appSecret, serialNo, false);
        }
    }

    private void goNextActivity() {
        if (SPUtils.getInstance().getBoolean(SPConfig.LAUNCH)) {
            ActivityUtils.startActivity(MainActivity.class);
        } else {
            ActivityUtils.startActivity(LaunchActivity.class);
        }
        finish();
    }

    @Override
    public void onLoginResult(LoginBean loginBean) {
        if (loginBean != null) {
            User user = new User();
            user.setUsername(mName);
            user.setLogin(true);
            user.setToken(loginBean.getToken());
            user.setRefreshToken(loginBean.getRefreshToken());
            user.setExpire(loginBean.getExpire());
            user.setPassword(mPwd);
            user.setAvatarUrl(mPresenter.getHeadIcon());
            DataCenter.getInstance().setUser(user);
            RxBus.get().post(ConstantValue.EVENT_TYPE_LOGINED, "login");
            tvLoadingInfo.setText("准备进入");
            mPresenter.getUserInfo(false);
        } else {
            goNextActivity();
        }
    }


    @Override
    public void doPwdToggle() {

    }

    @Override
    public void onGetUserInfo(User user) {
        if (user != null) {
            mPresenter.setUserWithoutToken(user);
        }
        goNextActivity();
    }

    @Override
    public void checkName(CheckAccountBean bean) {

    }

    @Override
    public void onCheckReal(HttpResult httpResult) {

    }


    @Subscribe(tags = {@Tag(ConstantValue.EVENT_TYPE_NETWORK_EXCEPTION)})
    public void shrinkRefreshView(String s) {
        DataCenter.getInstance().clearUser();
        goNextActivity();
    }


    @Override
    public void startConnecting() {
        tvLoadingInfo.setText("开始获取线路");
    }

    @Override
    public void succeedConnected() {
        runOnUiThread(() -> {
            tvLoadingInfo.setText("线路获取成功");
            //登录
            doLogin();
        });
    }

    @Override
    public void failureConnected(String message) {
        runOnUiThread(() -> {
            aviLoadingView.setVisibility(View.GONE);
            tvRetry.setVisibility(View.VISIBLE);
            tvLoadingInfo.setText(message);
        });
    }

    @Override
    protected void onDestroy() {
        RxBus.get().unregister(this);
        if (mPresenter != null) {
            mPresenter.onDestory();
        }
        super.onDestroy();
    }
}
