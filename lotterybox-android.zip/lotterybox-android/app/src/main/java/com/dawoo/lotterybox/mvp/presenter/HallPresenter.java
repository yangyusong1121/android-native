package com.dawoo.lotterybox.mvp.presenter;

import android.content.Context;

import com.dawoo.lotterybox.BoxApplication;
import com.dawoo.lotterybox.bean.AllMode;
import com.dawoo.lotterybox.bean.BannerBean;
import com.dawoo.lotterybox.bean.Bulletin;
import com.dawoo.lotterybox.bean.lottery.hall.HotLotteryBean;
import com.dawoo.lotterybox.mvp.model.Lottery.ILotteryModel;
import com.dawoo.lotterybox.mvp.model.Lottery.LotteryModel;
import com.dawoo.lotterybox.mvp.model.activity.ActivityModel;
import com.dawoo.lotterybox.mvp.model.activity.IActivityModel;
import com.dawoo.lotterybox.mvp.view.HallView;
import com.dawoo.lotterybox.mvp.view.IBaseView;
import com.dawoo.lotterybox.mvp.view.IHallView;
import com.dawoo.lotterybox.mvp.view.IMCenterFragmentView;
import com.dawoo.lotterybox.net.ApiException;
import com.dawoo.lotterybox.net.HttpResult;
import com.dawoo.lotterybox.net.rx.ProgressSubscriber;
import java.util.List;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Function;


/**
 * 购彩大厅相关
 * Created by b on 18-2-16.
 */

public class HallPresenter<T extends IBaseView> extends BasePresenter {


    private final Context mContext;
    private T mView;
    private final IActivityModel mActivityModel;
    private final ILotteryModel mLotteryModel;

    public HallPresenter(Context context, T mView) {
        super(context, mView);

        mContext = context;
        this.mView = mView;
        mActivityModel = new ActivityModel();
        mLotteryModel = new LotteryModel();
    }

    public void getPageData() {


    }

    /**
     * 轮播图
     */
    public void getBanner() {
        Disposable Disposable = mActivityModel.getBanner(new ProgressSubscriber(o ->
                ((IHallView) mView).onBanner((List<BannerBean>) o), mContext, false));
        subList.add(Disposable);
    }



    public class HttpResultFunc<T> implements Function<HttpResult<T>, T> {


        @Override
        public T apply(HttpResult<T> httpResult) throws Exception {
            if (0 != httpResult.getError()) {
                throw new ApiException(httpResult.getCode(), httpResult.getMessage());

            }
            BoxApplication.HttpStateCode = httpResult.getError();
            return httpResult.getData();
        }
    }

    /**
     * 公告
     */
    public void getBulletin() {
        Disposable Disposable = mActivityModel.getBulletin(new ProgressSubscriber(o ->
                ((IHallView) mView).onBulletin((List<Bulletin>) o), mContext, false));
        subList.add(Disposable);
    }


    /**
     * 首页热门数据
     */
    public void getHomeLottery() {
        Disposable Disposable = mLotteryModel.getHomeLottery(new ProgressSubscriber(o ->
                ((IHallView) mView).onHomeLottery((HotLotteryBean) o), mContext, false));
        subList.add(Disposable);
    }



    /**
     * 获取客服链接
     */
    public void getCSLink() {
        Disposable Disposable = mActivityModel.getCSLink(new ProgressSubscriber(o ->
                ((IMCenterFragmentView) mView).onCSLinkResult((String) o), mContext, false));
        subList.add(Disposable);
    }

    public void getAllLottery() {
        Disposable Disposable = mLotteryModel.getAllLottery(new ProgressSubscriber(o ->
                ((IHallView) mView).onAllDatas((AllMode) o), mContext, false));
        subList.add(Disposable);
    }



    public void getAllLottery(boolean noProgress) {
        Disposable Disposable = mLotteryModel.getAllLottery(new ProgressSubscriber(o ->
                ((IHallView) mView).onAllDatas((AllMode) o), mContext, noProgress));
        subList.add(Disposable);
    }

    public void getHallPageData() {
        Disposable Disposable = mLotteryModel.getHallPageData(new ProgressSubscriber(o ->
                ((HallView) mView).onResult(o), mContext, false));
        subList.add(Disposable);
    }

    @Override
    public void ondetach() {
        super.ondetach();
    }
}
