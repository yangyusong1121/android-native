package com.dawoo.lotterybox.mvp.presenter;

import android.content.Context;

import com.dawoo.lotterybox.bean.lottery.BaseHandicap;
import com.dawoo.lotterybox.bean.lottery.Handicap;
import com.dawoo.lotterybox.bean.lottery.HandicapWithOpening;
import com.dawoo.lotterybox.bean.lottery.LotteryLastOpenAndOpening;
import com.dawoo.lotterybox.bean.lottery.lotteryenum.BaseLotteryEnum;
import com.dawoo.lotterybox.mvp.model.Lottery.ILotteryModel;
import com.dawoo.lotterybox.mvp.model.Lottery.LotteryModel;
import com.dawoo.lotterybox.mvp.view.IBaseView;
import com.dawoo.lotterybox.mvp.view.ILastLotteryRecView;
import com.dawoo.lotterybox.mvp.view.IRecentOpenRecView;
import com.dawoo.lotterybox.net.rx.ProgressSubscriber;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.disposables.Disposable;


/**
 * 彩票开奖记录
 * Created by benson on 18-2-13.
 */

public class LotteryRecordPresenter<T extends IBaseView> extends BasePresenter {
    private final Context mContext;
    private T mView;
    private final ILotteryModel mModel;

    public LotteryRecordPresenter(Context context, T mView) {
        super(context, mView);

        mContext = context;
        this.mView = mView;
        mModel = new LotteryModel();
    }

    /**
     * 获取盘口数据
     */
    public void getLotteryExpect(String code) {
        Disposable Disposable = mModel.getLotteryExpect(new ProgressSubscriber<>(o ->
                        ((ILastLotteryRecView) mView).onLotteryExpect((BaseHandicap) o), mContext, false),
                code);
        subList.add(Disposable);
    }

    /**
     * 最新一期彩票开奖和下一期未开奖开票
     */
    public void getLastOpenedAndOpeningResult(boolean needProgress) {
        Disposable Disposable = mModel.getLastOpenedAndOpeningResult(new ProgressSubscriber(o ->
                ((ILastLotteryRecView) mView).onLastLotteryRecResult((List<LotteryLastOpenAndOpening>) o), mContext, needProgress));
        subList.add(Disposable);
    }


    /**
     * 获取已封盘最近一期开奖数据（开奖号码（空则说明正在开奖中））；
     */

    public void getRecentCloseExpect(String code) {
        Disposable Disposable = mModel.getRecentCloseExpect(new ProgressSubscriber(o ->
                        ((ILastLotteryRecView) mView).onRecentCloseExpect((Handicap) o), mContext, false),
                code);
        subList.add(Disposable);
    }


    @Override
    public void onDestory() {
        super.onDestory();
    }

    /**
     * 最近开奖记录
     */
    public void getRecentRecords(String code, String pageSize) {
        Disposable Disposable = mModel.getRecentRecords(new ProgressSubscriber(o ->
                        ((IRecentOpenRecView) mView).onRecentRecResult((List<HandicapWithOpening>) o), mContext, false),
                code,
                pageSize);
        subList.add(Disposable);
    }

    /**
     * 刷新最近开奖记录
     */
    public void refreshRecentRecords(String code, String pageSize) {
        Disposable Disposable = mModel.getRecentRecords(new ProgressSubscriber(o ->
                        ((IRecentOpenRecView) mView).onRefreshRecResult((List<HandicapWithOpening>) o), mContext, false),
                code,
                pageSize);
        subList.add(Disposable);
    }


    public List<HandicapWithOpening> addItemType2(List<HandicapWithOpening> lastOpenAndOpenings) {
        List<HandicapWithOpening> list = new ArrayList();
        list.clear();
        HandicapWithOpening itemData = null;
        for (int i = 0; i < lastOpenAndOpenings.size(); i++) {
            itemData = lastOpenAndOpenings.get(i);
            if (itemData.getOpenCode() == null || itemData.getOpenCode().isEmpty()) {
                continue;
            }
            if (BaseLotteryEnum.SSC.getType().equals(itemData.getType())) {
                itemData.setItemType(BaseLotteryEnum.SSC.getRcdFlag());
                list.add(itemData);
            } else if (BaseLotteryEnum.PK10.getType().equals(itemData.getType())
                    || BaseLotteryEnum.NN.getType().equalsIgnoreCase(itemData.getType())
                    || BaseLotteryEnum.BJL.getType().equalsIgnoreCase(itemData.getType())) {
                itemData.setItemType(BaseLotteryEnum.PK10.getRcdFlag());
                list.add(itemData);

            } else if (BaseLotteryEnum.LHC.getType().equals(itemData.getType())) {
                itemData.setItemType(BaseLotteryEnum.LHC.getRcdFlag());
                list.add(itemData);

            } else if (BaseLotteryEnum.K3.getType().equals(itemData.getType())) {
                itemData.setItemType(BaseLotteryEnum.K3.getRcdFlag());
                list.add(itemData);

            } else if (BaseLotteryEnum.SFC.getType().equals(itemData.getType())) {
                itemData.setItemType(BaseLotteryEnum.SFC.getRcdFlag());
                list.add(itemData);

            } else if (BaseLotteryEnum.KENO.getType().equals(itemData.getType())) {
                itemData.setItemType(BaseLotteryEnum.KENO.getRcdFlag());
                list.add(itemData);

            } else if (BaseLotteryEnum.XY28.getType().equals(itemData.getType())) {
                itemData.setItemType(BaseLotteryEnum.XY28.getRcdFlag());
                list.add(itemData);

            } else if (BaseLotteryEnum.PL3.getType().equals(itemData.getType())) {
                itemData.setItemType(BaseLotteryEnum.PL3.getRcdFlag());
                list.add(itemData);
            } else if (BaseLotteryEnum.SYXW.getType().equalsIgnoreCase(itemData.getType())) {
                itemData.setItemType(BaseLotteryEnum.SYXW.getRcdFlag());
                list.add(itemData);
            }
        }

        return list;
    }


}
