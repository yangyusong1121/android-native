package com.dawoo.lotterybox.bean;

/**
 * Created by alex on 18-5-1.
 */

public class OALinkBean {

    /**
     * agent : D0a5cNnG3hPBBaM6rZFzJA==
     * status : true
     * member : b4HCXxpfMyGQLUZ/nO1OHg==
     */

    private String agent;
    private boolean status;

    @Override
    public String toString() {
        return "OALinkBean{" +
                "agent='" + agent + '\'' +
                ", status=" + status +
                ", member='" + member + '\'' +
                '}';
    }

    private String member;

    public String getAgent() {
        return agent;
    }

    public void setAgent(String agent) {
        this.agent = agent;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public String getMember() {
        return member;
    }

    public void setMember(String member) {
        this.member = member;
    }
}
