package com.dawoo.lotterybox.mvp.view;

import com.dawoo.lotterybox.bean.TeamParticipationBean;
import com.dawoo.lotterybox.bean.TeamSalaryBean;

import java.util.List;

/**
 * Created by alex on 18-4-24.
 */

public interface ITeamParticipationView extends IBaseView {
    void onParticipationResult(TeamParticipationBean o);

    void onSaveTeamParticipationResult(Boolean o);
}
