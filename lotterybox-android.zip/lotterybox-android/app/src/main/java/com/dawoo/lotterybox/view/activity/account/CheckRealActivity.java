package com.dawoo.lotterybox.view.activity.account;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.dawoo.coretool.ToastUtil;
import com.dawoo.coretool.util.activity.KeyboardUtil;
import com.dawoo.lotterybox.R;
import com.dawoo.lotterybox.bean.CheckAccountBean;
import com.dawoo.lotterybox.bean.LoginBean;
import com.dawoo.lotterybox.bean.User;
import com.dawoo.lotterybox.mvp.presenter.UserPresenter;
import com.dawoo.lotterybox.mvp.view.ILoginView;
import com.dawoo.lotterybox.net.HttpResult;
import com.dawoo.lotterybox.util.RexConstantValue;
import com.dawoo.lotterybox.util.RexUtils;
import com.dawoo.lotterybox.util.SingleToast;
import com.dawoo.lotterybox.view.activity.BaseActivity;
import com.dawoo.lotterybox.view.view.HeaderView;
import com.hwangjr.rxbus.RxBus;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * Created by rain on 18-6-14.
 */

public class  CheckRealActivity extends BaseActivity implements ILoginView {

    @BindView(R.id.head_view)
    HeaderView mHeader;
    @BindView(R.id.username)
    TextView username;
    @BindView(R.id.card_name)
    EditText cardName;
    @BindView(R.id.card_number)
    EditText cardNumber;
    @BindView(R.id.ll_real_name)
    LinearLayout realName;
    @BindView(R.id.num_ll)
    LinearLayout numLL;
    String name;
    String pwd;
    boolean isRealName;
    boolean isBank;
    private UserPresenter mPresenter;
    @Override
    protected void createLayoutView() {
        setContentView(R.layout.activity_check_real);
        RxBus.get().register(this);
    }

    @Override
    protected void initViews() {
        Bundle mBundle = getIntent().getExtras();
        if (mBundle == null) {
            finish();
            return;
        }
        mHeader.setHeader("账户校验", true);
        name = mBundle.getString("name");
        pwd = mBundle.getString("pwd");
        isRealName = mBundle.getBoolean("isRealName", false);
        isBank = mBundle.getBoolean("isBankCard", false);
        if (name == null) {
            finish();
            return;
        }
        username.setText("账户名：" + name);
        if (!isRealName){
            realName.setVisibility(View.GONE);
        }
        if (!isBank) {
            numLL.setVisibility(View.GONE);
        }
        mPresenter = new UserPresenter<>(this, this);
    }

    @Override
    protected void initData() {

    }

    @Override
    public void onLoginResult(LoginBean o) {

    }

    @Override
    public void doLogin() {

    }

    @Override
    public void onCheckReal(HttpResult httpResult) {
        if (httpResult.getError() == 0){
            SingleToast.showMsg("校验成功，设置密码中");
            mPresenter.setpwd(name,pwd);
        }else {
            SingleToast.showMsg(httpResult.getMessage());
        }
    }

    @Override
    public void doPwdToggle() {
        SingleToast.showMsg("密码设置成功，请到登录页面进行登录");
        RxBus.get().post("accountFinish","-1");
        finish();
    }

    @Override
    public void onGetUserInfo(User user) {

    }

    @Override
    public void checkName(CheckAccountBean bean) {

    }


    @OnClick({R.id.login_btn})
    public void onClickCiew(View view) {
        if (view.getId() == R.id.login_btn) {
            if (TextUtils.isEmpty(cardName.getText().toString().trim())) {
                SingleToast.showMsg("用戶名为空,请重新输入");
                return;
            }
            if (isBank) {
                if (TextUtils.isEmpty(cardNumber.getText().toString().trim())) {
                    SingleToast.showMsg("银行卡号为空,请重新输入");
                    return;
                }
                if (!isBank(cardNumber.getText().toString())) {
                    SingleToast.showMsg("卡号不正确");
                    return;
                }
            }
            KeyboardUtil.hideInputKeyboard(this);
            String realName = cardName.getText().toString().trim();
            if (TextUtils.isEmpty(name))
                realName = null;
            String number = cardNumber.getText().toString().trim();
            if (TextUtils.isEmpty(number))
                number = null;
            mPresenter.checkReal(name,realName,number);
        }
    }

    public static boolean isBank(final String str) {
        Pattern p = null;
        Matcher m = null;
        boolean b = false;
        p = Pattern.compile(RexConstantValue.BANK); // 验证手机号
        m = p.matcher(str);
        b = m.matches();
        return b;
    }

    @Override
    protected void onDestroy() {
        mPresenter.onDestory();
        RxBus.get().unregister(this);
        super.onDestroy();
    }


}
