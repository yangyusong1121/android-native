package com.dawoo.lotterybox.view.activity.lottery;

import android.animation.AnimatorSet;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.CountDownTimer;
import android.os.Parcelable;
import android.support.design.widget.BottomSheetBehavior;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.dawoo.coretool.ToastUtil;
import com.dawoo.coretool.util.activity.DensityUtil;
import com.dawoo.lotterybox.ConstantValue;
import com.dawoo.lotterybox.R;
import com.dawoo.lotterybox.adapter.LotteryHeadPullAdapter;
import com.dawoo.lotterybox.adapter.ssc.GamePlayAdapter;
import com.dawoo.lotterybox.bean.BetOrderBean;
import com.dawoo.lotterybox.bean.BetParamBean;
import com.dawoo.lotterybox.bean.DataCenter;
import com.dawoo.lotterybox.bean.OrderEventBean;
import com.dawoo.lotterybox.bean.lottery.BaseHandicap;
import com.dawoo.lotterybox.bean.lottery.Handicap;
import com.dawoo.lotterybox.bean.lottery.HandicapWithOpening;
import com.dawoo.lotterybox.bean.lottery.LotteryOddBean;
import com.dawoo.lotterybox.bean.lottery.SaveOrderResult;
import com.dawoo.lotterybox.bean.lottery.lotteryenum.BaseLotteryEnum;
import com.dawoo.lotterybox.bean.playtype.PlayTypeBean;
import com.dawoo.lotterybox.mvp.presenter.LotteryPresenter;
import com.dawoo.lotterybox.mvp.view.ILotteryAView;
import com.dawoo.lotterybox.util.ActivityUtil;
import com.dawoo.lotterybox.util.AssetsReader;
import com.dawoo.lotterybox.util.BitmapUtil;
import com.dawoo.lotterybox.util.GsonUtil;
import com.dawoo.lotterybox.util.SingleToast;
import com.dawoo.lotterybox.util.anim.LotteryBAnimSetUtil;
import com.dawoo.lotterybox.view.activity.BaseActivity;
import com.dawoo.lotterybox.view.activity.NoteRcdActivity;
import com.dawoo.lotterybox.view.activity.lottery.ssc.PlayExplainActivity;
import com.dawoo.lotterybox.view.activity.lottery.ssc.SSCWayPaperActivity;
import com.dawoo.lotterybox.view.activity.record.CharseNumRecordFragment;
import com.dawoo.lotterybox.view.activity.record.HistoryRepotFormFragment;
import com.dawoo.lotterybox.view.activity.webview.AndroidBug5497Workaround2;
import com.dawoo.lotterybox.view.view.CountDownTimerUtils;
import com.dawoo.lotterybox.view.view.HeaderLotteryAView;
import com.dawoo.lotterybox.view.view.PlayTypePopupWindow;
import com.dawoo.lotterybox.view.view.RequestTouchTextView;
import com.dawoo.lotterybox.view.view.TimeTextView;
import com.dawoo.lotterybox.view.view.dialog.BettingSetDialog;
import com.dawoo.lotterybox.view.view.dialog.BottomNumDialog;
import com.dawoo.lotterybox.view.view.dialog.HowToPlayDialog;
import com.dawoo.lotterybox.view.view.dialog.OrderTipDialog;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import butterknife.BindView;
import butterknife.OnClick;

import static com.dawoo.lotterybox.ConstantValue.LT_CODE;
import static com.dawoo.lotterybox.ConstantValue.LT_NAME;
import static com.dawoo.lotterybox.ConstantValue.LT_TYPE;
import static com.dawoo.lotterybox.view.activity.lottery.LotteryAShoppingCartActivity.PLAY_BEAN;
import static com.dawoo.lotterybox.view.activity.lottery.LotteryAShoppingCartActivity.PLAY_MODEL;
import static com.dawoo.lotterybox.view.activity.lottery.LotteryAShoppingCartActivity.SHOP_DATA;

/**
 * 彩票A盘base
 * Created by b on 18-3-27.
 */

public class BaseLotteryAActivity extends BaseActivity implements ILotteryAView, HeaderLotteryAView.HeadPopupItemClick {

    @BindView(R.id.lLayout_ssc_bottom_second)
    protected LinearLayout mLLayoutSscBottomSecond;
    @BindView(R.id.head_view)
    protected HeaderLotteryAView mHeadView;
    @BindView(R.id.rlv_lottery_record)
    protected RecyclerView mRlvLotteryRecord;
    @BindView(R.id.rlv_game_play)
    protected RecyclerView mRlvGamePlay;
    @BindView(R.id.tv_now_stage)
    protected TextView mTvNowStage;
    @BindView(R.id.tv_now_stage_state)
    protected TextView mTvNowStageState;
    @BindView(R.id.sm_timer)
    protected TimeTextView mTimeTextView;
    @BindView(R.id.tv_periods)
    protected TextView mTvPeriods;
    @BindView(R.id.tv_computer_select)
    protected TextView mTvComputerSelect;
    @BindView(R.id.tv_setting_special)
    protected TextView mTvSettingSpecial;
    @BindView(R.id.et_multiple)
    protected TextView mEtMultiple;
    @BindView(R.id.tv_place_order)
    protected TextView mTvPlaceOrder;
    @BindView(R.id.tv_bet_info)
    protected TextView mTvBetInfo;
    @BindView(R.id.ll_bottom_menu)
    protected LinearLayout mLlBottomMenu;
    @BindView(R.id.ll_stop_sale)
    public LinearLayout lLStopSale;
    @BindView(R.id.fendan_tv)
    public RequestTouchTextView fendanTv;
    @BindView(R.id.tv_xdh)
    protected
    TextView mTvXdh;
    @BindView(R.id.tv_play_method)
    TextView tvTopClikc;

    @BindView(R.id.ll_nums)
    protected RelativeLayout mLl_nums;

    private BottomSheetBehavior mBottomSheetBehavior;
    private PlayTypePopupWindow mPlayTypePopupWindow;
    public PlayTypeBean.PlayBean mPlayTypeBean;//当前的玩法对象

    private CountDownTimerUtils mCountDownTimerUtils;
    private OrderTipDialog mOrderTipDialog;
    public GamePlayAdapter mGamePlayAdapter;
    public LotteryPresenter mLotteryPresenter;
    BetParamBean mBetParamBean = new BetParamBean(); //投注所需参数实体类
    public List<BetOrderBean> mBetOrderBeans = new ArrayList<>();  //已有记录
    private BottomNumDialog mBottomNumDialog;
    private List<Handicap> mHandicapList = new ArrayList<>();
    protected String dataFile;
    private boolean isComputerSelect = false;  //是否已机选
    protected String mLotteryCode;
    private String mLotteryType;
    private String mLotteryName;
    boolean isCallBack;
    private PopupWindow headPop;
    private AnimatorSet mAnimSetPeriods = new AnimatorSet();//期数动画
    private AnimatorSet mAnimSetPeriodsNext = new AnimatorSet();//下一期期数动画
    private AnimatorSet mAnimSetXh = new AnimatorSet();//形態动画
    private AnimatorSet mAnimSetNums = new AnimatorSet();//号码动画
    private AnimatorSet mAnimSetStatus = new AnimatorSet();//盘口状态动画
    private AnimatorSet mAnimSetTime = new AnimatorSet();//时间

    private Drawable lessDrawable, moreDrawable;
    /**
     * @param hideViews 需要隐藏的view
     */
    protected void setViewsGone(List<TextView> hideViews) {
        if (hideViews == null) return;
        for (TextView tv : hideViews) {
            tv.setVisibility(View.GONE);
        }
    }

    @Override
    protected void createLayoutView() {
        setContentView(R.layout.activity_base_ssc);
    }

    private void initHeadPullPop() {
        View view = LayoutInflater.from(this).inflate(R.layout.view_lottery_select_pop_top, null, false);
        TabLayout tlHead = view.findViewById(R.id.tl_head);
        ViewPager vpBody = view.findViewById(R.id.vp_body_ss);
        List<PlayTypeBean> mList = GsonUtil.jsonToList(AssetsReader.getJson(this, dataFile), PlayTypeBean.class);
        mList.get(0).getPlayBeans().get(0).setSelected(true);
        LotteryHeadPullAdapter lotteryHeadPullAdapter = new LotteryHeadPullAdapter(mList, (adapter, position, childPosition) -> {
            //选中的playBean
            mPlayTypeBean = mList.get(position).getPlayBeans().get(childPosition);
            processSelectedData(mList, adapter, position, childPosition);
            headPop.dismiss();
            changView();
        });
        vpBody.setAdapter(lotteryHeadPullAdapter);
        tlHead.setupWithViewPager(vpBody);
        headPop = new PopupWindow();
        headPop.setContentView(view);
        headPop.setWidth(WindowManager.LayoutParams.MATCH_PARENT);
        headPop.setHeight(WindowManager.LayoutParams.WRAP_CONTENT);
        headPop.setFocusable(true);
        headPop.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        headPop.setOnDismissListener(new PopupWindow.OnDismissListener() {
            @Override
            public void onDismiss() {
                isOpen = false;
                Drawable drawable = getResources().getDrawable(R.mipmap.ic_up_white);
                drawable.setBounds(0, 0, drawable.getMinimumWidth(), drawable.getMinimumHeight());
                tvTopClikc.setCompoundDrawables(null, null, drawable, null);
//                vZheZhao.setVisibility(View.GONE);
            }
        });
    }

    private void processSelectedData(List<PlayTypeBean> mList, LotteryHeadPullAdapter adapter, int position, int childPosition) {
        for (int i = 0; i < mList.size(); i++) {
            for (int j = 0; j < mList.get(i).getPlayBeans().size(); j++) {
                mList.get(i).getPlayBeans().get(j).setSelected(false);
            }
        }
        mList.get(position).getPlayBeans().get(childPosition).setSelected(true);
        mLotteryPresenter.setComputerSelected(false);
        adapter.setNewData(mList);
    }


    @Override
    protected void initViews() {
        mHeadView.setPopupItemClick(this);
        mBottomSheetBehavior = BottomSheetBehavior.from(mLLayoutSscBottomSecond);
        mBottomSheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED);
        mRlvLotteryRecord.setLayoutManager(new LinearLayoutManager(this));
        mRlvGamePlay.setLayoutManager(new LinearLayoutManager(this));

        lessDrawable = BitmapUtil.getTextDrawable(this, R.drawable.ic_expand_less_black_40dp);
        moreDrawable = BitmapUtil.getTextDrawable(this, R.drawable.ic_expand_more_black_40dp);
        mTvPeriods.setCompoundDrawables(null, null, null, moreDrawable);
    }

    @Override
    protected void setErrorTitleName(TextView tvTitle) {
        super.setErrorTitleName(tvTitle);
        tvTitle.setText("页面错误");
    }

    @Override
    protected void initData() {
        mLl_nums.setVisibility(View.GONE);
        List<PlayTypeBean> mList = GsonUtil.jsonToList(AssetsReader.getJson(this, dataFile), PlayTypeBean.class);
        mPlayTypeBean = mList.get(0).getPlayBeans().get(0);
        if (mPlayTypeBean.getMainType().equals(mPlayTypeBean.getPlayTypeName()))
            mHeadView.setPlayMethodLeftText(mPlayTypeBean.getMainType());
        else
            mHeadView.setPlayMethodLeftText(mPlayTypeBean.getMainType() + " " + mPlayTypeBean.getPlayTypeName());
        mGamePlayAdapter = new GamePlayAdapter(this, mPlayTypeBean);
        mRlvGamePlay.setAdapter(mGamePlayAdapter);
        initPlayTypePopWindow(mList);
//        initHeadPullPop();
        initBetParamBean();
        mLotteryName = getIntent().getStringExtra(LT_NAME);
//        tvTopClikc.setText(titleName);
        mLotteryCode = getIntent().getStringExtra(LT_CODE);
        mLotteryType = getIntent().getStringExtra(LT_TYPE);
        mLotteryPresenter = new LotteryPresenter(this, this, mLotteryCode);
        mLotteryPresenter.initLayoutChildBean(mPlayTypeBean);
        mLotteryPresenter.getResultByCode();
        mLotteryPresenter.getLotteryExpect();
        mLotteryPresenter.getLotteryOdd(mPlayTypeBean.getBetCode());
        mLotteryPresenter.getLtToken();
        mCountDownTimerUtils = CountDownTimerUtils.getCountDownTimer();
    }

    private void initBetParamBean() {
        mBetParamBean.setCode(getIntent().getStringExtra(LT_CODE));
        mBetParamBean.setPlayCode(mPlayTypeBean.getPlayTypeCode());
        mBetParamBean.setBetCode(mPlayTypeBean.getBetCode());
        mBetParamBean.setPlayTypeName(mPlayTypeBean.getMainType() + mPlayTypeBean.getPlayTypeName());
        mEtMultiple.setText(mBetParamBean.getMultiple());
    }

    @Override
    protected void errorRetry() {
        super.errorRetry();
        checkNetWork();
        mLotteryPresenter.getLotteryExpect();
    }

    /**
     * 初始化头部玩法弹窗
     *
     * @param mList
     */
    private void initPlayTypePopWindow(List<PlayTypeBean> mList) {
        mPlayTypePopupWindow = new PlayTypePopupWindow(this, getIntent().getStringExtra(LT_CODE), mList);
        mPlayTypePopupWindow.setOnClickPlayType(new PlayTypePopupWindow.OnClickPlayType() {
            @Override
            public void callBackTypeName(PlayTypeBean.PlayBean playTypeBean) {
                mPlayTypeBean = playTypeBean;
                changView();
            }
        });
    }

    private void changView() {
        mLotteryPresenter.initLayoutChildBean(mPlayTypeBean);
        mGamePlayAdapter.setNewData(mPlayTypeBean);
        if (mPlayTypeBean.getMainType().equals(mPlayTypeBean.getPlayTypeName()))
            mHeadView.setPlayMethodLeftText(mPlayTypeBean.getMainType());
        else
            mHeadView.setPlayMethodLeftText(mPlayTypeBean.getMainType() + " " + mPlayTypeBean.getPlayTypeName());
        mLotteryPresenter.getLotteryOdd(mPlayTypeBean.getBetCode());
        mTvBetInfo.setVisibility(View.GONE);
        mBetParamBean.setPlayCode(mPlayTypeBean.getPlayTypeCode());
        mBetParamBean.setBetCode(mPlayTypeBean.getBetCode());
        changePlayBean(mPlayTypeBean);
        openHotColdOrOmit(mGamePlayAdapter.type);  //上个玩法保留的是否开启冷热遗漏状态
        clearSelect();
    }

    private boolean isOpen;

    @OnClick({R.id.tv_play_method, R.id.tv_place_order, R.id.tv_setting_special, R.id.tv_computer_select, R.id.et_multiple, R.id.tv_periods})
    public void onBaseClick(View v) {
        switch (v.getId()) {
            case R.id.tv_play_method:
                // 玩法弹窗打开或关闭
                mPlayTypePopupWindow.doTogglePopupWindow(v, mPlayTypeBean);
                break;

            case R.id.tv_place_order:
                // 下单
                doPlaceOrder();
                break;

            case R.id.tv_setting_special:
                // 订单配置设置
                BettingSetDialog mBettingSetDialog = new BettingSetDialog(this, mBetParamBean);
                mBettingSetDialog.show();
                break;

            case R.id.tv_computer_select:
                // 机选
                if (isComputerSelect) {
                    clearSelect();
                } else {
                    doComputerSelect();
                }
                break;
            case R.id.et_multiple:
                // 键盘输入框
                createBottomNum();
                break;
            case R.id.tv_periods:
                if (mBottomSheetBehavior.getState() == BottomSheetBehavior.STATE_COLLAPSED) {
                    mTvPeriods.setCompoundDrawables(null, null, null, moreDrawable);
                    mBottomSheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED);
                } else {
                    mTvPeriods.setCompoundDrawables(null, null, null, lessDrawable);
                    mBottomSheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
                }
                break;
            default:
                break;
        }
    }

    /**
     * 执行下单
     */
    public void doPlaceOrder() {
        if (mBetParamBean.isBetHint()) {
            goPlaceOrder();
        } else {
            mOrderTipDialog = new OrderTipDialog(this, mBetParamBean);
            mOrderTipDialog.show();
        }
    }


    /**
     * 执行机选
     */
    public void doComputerSelect() {
        if (mPlayTypeBean.getLayoutBeans().get(0).getLayoutType() == 0) {
            mLotteryPresenter.computerSelect(mPlayTypeBean);
        } else {
            ToastUtil.showToastLong(this, "不支持机选");
        }
        mLotteryPresenter.isBetBtEnable(mPlayTypeBean);
    }

    public void clearSelect() {   //清除选择
        isComputerSelect = false;
        mTvBetInfo.setVisibility(View.GONE);
        mTvPlaceOrder.setEnabled(false);
        if (mPlayTypeBean.getLayoutBeans().get(0).getLayoutType() == 2) {
            View viewByPosition = mRlvGamePlay.getLayoutManager().findViewByPosition(1);
            if (viewByPosition != null) {
                EditText editText = viewByPosition.findViewById(R.id.et_bet_input);
                if (editText == null) {
                    return;
                }
                editText.setText("");//清除输入框内的数据
            }
            return;
        }
        mLotteryPresenter.clearSelect(mPlayTypeBean);
        mLotteryPresenter.isBetBtEnable(mPlayTypeBean);
        mTvComputerSelect.setText(getString(R.string.machine_selection));
        mGamePlayAdapter.notifyDataSetChanged();
    }

    public void goPlaceOrder() {
        if (!DataCenter.getInstance().isLogin()) {
            SingleToast.showMsg("请先登录");
            ActivityUtil.startLoginActivity();
            return;
        }


        BetOrderBean betOrderBean = new BetOrderBean();
        betOrderBean.setParam(mBetParamBean);
        mBetOrderBeans.add(0, betOrderBean);
        Intent intent = new Intent(this, LotteryAShoppingCartActivity.class);
        intent.putExtra(LT_NAME, getIntent().getStringExtra(LT_NAME));
        intent.putExtra(LT_CODE, getIntent().getStringExtra(LT_CODE));
        intent.putExtra(PLAY_MODEL, "official");
        intent.putExtra(PLAY_BEAN, mPlayTypeBean);
        intent.putExtra("isRX", mPlayTypeBean.getLayoutBeans().get(0).isShowTop());
        intent.putParcelableArrayListExtra(SHOP_DATA, (ArrayList<? extends Parcelable>) mBetOrderBeans);
        startActivity(intent);
        mTvBetInfo.setVisibility(View.GONE);
        clearSelect();
        mBetParamBean.setMultiple("1");
        mBetParamBean.setNowRebate(0);
        mEtMultiple.setText(mBetParamBean.getMultiple());
    }

    //倒计时期间回调
    CountDownTimerUtils.TickDelegate mTickDelegate = new CountDownTimerUtils.TickDelegate() {
        SimpleDateFormat sdf1 = new SimpleDateFormat("mm:ss");

        @Override
        public void onTick(long pMillisUntilFinished) {
            String str1 = sdf1.format(pMillisUntilFinished);
            mTimeTextView.setText(str1);
        }
    };

    //设置倒计时期间回调
    protected void setTickDelegate(CountDownTimerUtils.TickDelegate tickDelegate) {
        mTickDelegate = tickDelegate;
    }


    //距离开盘时间 倒计时结束回调
    CountDownTimerUtils.FinishDelegate mLeftOpenTimeFinishDelegate;

    //设置开盘倒计时
    protected void setLeftOpenTimeFinishDelegate(CountDownTimerUtils.FinishDelegate finishDelegate) {
        mLeftOpenTimeFinishDelegate = finishDelegate;
    }

    //距离封盘时间 倒计时结束回调
    CountDownTimerUtils.FinishDelegate mLeftTimeFinishDelegate;

    //设置封盘倒计时
    protected void setLeftTimeFinishDelegate(CountDownTimerUtils.FinishDelegate finishDelegate) {
        mLeftTimeFinishDelegate = finishDelegate;
    }

    @Override
    public void OnClickItem(int viewId) {
        switch (viewId) {
            case R.id.tv_lzt_pop:
                SSCWayPaperActivity.goLztActivity(this, getIntent().getStringExtra(LT_CODE));
                break;
            case R.id.tv_wf_pop:
                Intent intent = new Intent(this, PlayExplainActivity.class);
                intent.putExtra(PlayExplainActivity.ASSETS_FILE_NAME, dataFile);
                startActivity(intent);
                break;
            case R.id.tv_trend_chart:
                mHeadView.dismissPop();
                goTrendChart(mHandicapList);
                break;
            case R.id.tv_recent_awards:
                ActivityUtil.startRecentOpenRecActivity(mLotteryCode, mLotteryName, mLotteryType);
                break;
            case R.id.tv_my_bet:
                NoteRcdActivity.goRcordActivity(this, HistoryRepotFormFragment.class.getSimpleName());
                break;
            case R.id.tv_my_chase_number:
                NoteRcdActivity.goRcordActivity(this, CharseNumRecordFragment.class.getSimpleName());
                break;
            default:
        }
    }

    /**
     * 更换玩法
     */
    protected void changePlayBean(PlayTypeBean.PlayBean playBean) {
    }

    /**
     * 跳转折线图
     */
    protected void goTrendChart(List<Handicap> mHandicapList) {
        ActivityUtil.startChartActivity(this, mHandicapList, mLotteryType, mLotteryCode, mLotteryName);
    }

    /**
     * 打开冷热或遗漏
     *
     * @param type -1 ：关闭    0：冷热   1：遗漏
     */
    public void openHotColdOrOmit(int type) {
    }

    /**
     * 开奖
     */
    protected void onOpenLottery() {
    }

    /**
     * 历史数据
     */
    protected void onResultByCodeChild(List<Handicap> handicapList) {
    }

    /**
     * 设置正在开奖ui
     */
    protected void openLottery() {
    }

    /**
     * 设置开奖结果
     */
    protected void setResultToBall(String lotteryCode) {
    }


    //show游戏说明dialog
    public void showHowPlayDialog() {
        HowToPlayDialog howToPlayDialog = new HowToPlayDialog(this);
        howToPlayDialog.setPlayWay(mPlayTypeBean.getPlayTypeExplain());
        howToPlayDialog.setSamleBettingProgramTv(mPlayTypeBean.getSampleBet());
        howToPlayDialog.setLotteryNOteNumber(mPlayTypeBean.getSampleOpen());
        howToPlayDialog.show();
    }

    @Override
    public void onResultByCode(List<Handicap> handicapList) {
        errorRetryResult();
        if (handicapList != null) {
            mHandicapList = handicapList;
            mTvPeriods.setText(getString(R.string.which_periods, handicapList.get(0).getExpect()));
            onResultByCodeChild(mHandicapList);
            mLl_nums.setVisibility(View.VISIBLE);
            LotteryBAnimSetUtil.doPeriodTextViewAnim(mAnimSetPeriods, mTvPeriods, DensityUtil.dp2px(this, 30));
            LotteryBAnimSetUtil.doXhAnim(mAnimSetXh, mTvXdh, DensityUtil.dp2px(this, 30));
            LotteryBAnimSetUtil.doNumsAnim(mAnimSetNums, mLl_nums, DensityUtil.dp2px(this, 500));
        }
        mLotteryPresenter.getRecentCloseExpect();
    }

    boolean isFirstOpenLottery = true; //第一次进入

    @Override
    public void onRecentCloseExpect(Handicap handicap) {
        errorRetryResult();
        if (handicap != null && !TextUtils.isEmpty(handicap.getOpenCode())) {
            setResultToBall(handicap.getOpenCode());  //设置开奖结果
            if (mHandicapList.size() != 0) {
                if (!handicap.getExpect().equals(mHandicapList.get(0).getExpect())) {
                    if (mHandicapList != null && mHandicapList.size() - 1 > 0) {
                        mHandicapList.remove(mHandicapList.size() - 1);
                        mHandicapList.add(0, handicap);
                        onResultByCodeChild(mHandicapList);
                    }

                }
                mLl_nums.setVisibility(View.VISIBLE);
            }

        } else {
            if (isFirstOpenLottery)//第一次进入正在开奖，设置开奖动画。
                openLottery();
            countDownTimer.cancel();
            countDownTimer.start();
        }
        if (handicap != null && !TextUtils.isEmpty(handicap.getExpect())) {
            mTvPeriods.setText(getString(R.string.which_periods, handicap.getExpect()));
        }
        isFirstOpenLottery = false;
    }


    boolean isNotLotteryWait = false; //处理某些彩种没有封盘的情况

    @Override
    public void onLotteryExpect(BaseHandicap expectDataBean) {
        errorRetryResult();
        if (expectDataBean != null) {
            if (expectDataBean.getStatus().equalsIgnoreCase(ConstantValue.NORMAL)) {
                fendanTv.setText("封单中");
                lLStopSale.setVisibility(View.GONE);
            } else if (expectDataBean.getStatus().equalsIgnoreCase(ConstantValue.MAINTAIN)) {
                fendanTv.setText("维护中");
                lLStopSale.setVisibility(View.VISIBLE);
            } else if (expectDataBean.getStatus().equalsIgnoreCase(ConstantValue.DISABLE)) {
                fendanTv.setText("已下架");
                lLStopSale.setVisibility(View.VISIBLE);
            } else if (expectDataBean.getStatus().equalsIgnoreCase(ConstantValue.CLOSE)) {
                fendanTv.setText("停市");
                lLStopSale.setVisibility(View.VISIBLE);
            }


            if (expectDataBean.getLeftOpenTime() == 0 && expectDataBean.getLeftTime() == 0) {
                ToastUtil.showToastLong(this, getString(R.string.getexpect_error));
                return;
            }
            mBetParamBean.setExpect(expectDataBean.getExpect());
            if (TextUtils.isEmpty(mTvNowStage.getText().toString())) {
                LotteryBAnimSetUtil.doPeriodTextViewAnim(mAnimSetPeriodsNext, mTvNowStage, DensityUtil.dp2px(this, 30));
            }
            mTvNowStage.setText(getString(R.string.which_periods, expectDataBean.getExpect()));
            if (expectDataBean.getLeftOpenTime() > 0) {
                mCountDownTimerUtils.cancel();
                mCountDownTimerUtils.setMillisInFuture(expectDataBean.getLeftOpenTime() * 1000)
                        .setCountDownInterval(1000)
                        .setFinishDelegate(mLeftOpenTimeFinishDelegate)
                        .setTickDelegate(mTickDelegate)
                        .start();

                if (mLotteryType.equals(BaseLotteryEnum.KENO.getType())) {
                    LotteryBAnimSetUtil.doStatusAnimBjkl8(mAnimSetStatus, mTvNowStageState, DensityUtil.dp2px(this, 30));
                    LotteryBAnimSetUtil.doStatusAnimBjkl8(mAnimSetTime, mTimeTextView, DensityUtil.dp2px(this, 30));
                } else {
                    if (TextUtils.isEmpty(mTvNowStageState.getText().toString())) {
                        LotteryBAnimSetUtil.doStatusAnim(mAnimSetStatus, mTvNowStageState, DensityUtil.dp2px(this, 60));
                        LotteryBAnimSetUtil.doTimeAnim(mAnimSetTime, mTimeTextView, DensityUtil.dp2px(this, 50));
                    }
                }

                mTvNowStageState.setText(R.string.not_bet);
                lLStopSale.setVisibility(View.VISIBLE);
                isNotLotteryWait = false;
                mTvXdh.setText("");

            } else {
                mCountDownTimerUtils.cancel();
                mCountDownTimerUtils.setMillisInFuture((expectDataBean.getLeftTime() + 2) * 1000)
                        .setCountDownInterval(1000)
                        .setFinishDelegate(mLeftTimeFinishDelegate)
                        .setTickDelegate(mTickDelegate)
                        .start();

                if (mLotteryType.equals(BaseLotteryEnum.KENO.getType())) {
                    LotteryBAnimSetUtil.doStatusAnimBjkl8(mAnimSetStatus, mTvNowStageState, DensityUtil.dp2px(this, 30));
                    LotteryBAnimSetUtil.doStatusAnimBjkl8(mAnimSetTime, mTimeTextView, DensityUtil.dp2px(this, 30));
                } else {
                    if (TextUtils.isEmpty(mTvNowStageState.getText().toString())) {
                        LotteryBAnimSetUtil.doStatusAnim(mAnimSetStatus, mTvNowStageState, DensityUtil.dp2px(this, 60));
                        LotteryBAnimSetUtil.doTimeAnim(mAnimSetTime, mTimeTextView, DensityUtil.dp2px(this, 50));
                    }
                }

                mTvNowStageState.setText(R.string.stop);
                if (isNotLotteryWait) {
                    mTvXdh.setText("");
                    onOpenLottery();
                }
                isNotLotteryWait = true;
            }
        }
    }


    protected CountDownTimer countDownTimer = new CountDownTimer(15000, 15000) {
        @Override
        public void onTick(long millisUntilFinished) {
        }

        @Override
        public void onFinish() {
            mLotteryPresenter.getRecentCloseExpect();
        }
    };

    @Override
    public void onLotteryOdd(Map<String, LotteryOddBean> o) {
        List<LotteryOddBean> mLotteryOddBeans = new ArrayList<>();  //当前玩法赔率集合
        if (o != null) {
            for (Map.Entry<String, LotteryOddBean> entity : o.entrySet()) {
                LotteryOddBean lotteryOddBean = entity.getValue();
                if (lotteryOddBean != null)
                    mLotteryOddBeans.add(lotteryOddBean);
            }
        }
        if (mLotteryOddBeans.size() != 0) {
            mBetParamBean.setLotteryOddBeans(mLotteryOddBeans);
        }
    }

    @Override
    public void onLtToken(String token) {
        if (token != null) {
            mBetParamBean.setToken(token);
        }
    }

    @Override
    public void onSaveBetOrder(SaveOrderResult submitOrderResultBean) {
//        if (submitOrderResultBean != null) {
//            mBetParamBean.setToken(submitOrderResultBean.getExtend());
//            if (submitOrderResultBean.getError() == 0)
//                ToastUtil.showToastLong(this, "下单成功");
//            else
//                ToastUtil.showToastLong(this, submitOrderResultBean.getMessage());
//        }
    }

    @Override
    public void onSureBetOrder() {
//        mLotteryPresenter.saveBetOrderA(mBetParamBean);

    }

    @Override
    public void onComputerSelect(int position) {
        mGamePlayAdapter.notifyItemChanged(position);
        //计算
    }

    @Override
    public void onBetBtEnable(boolean isBtEnable) {
        mTvPlaceOrder.setEnabled(isBtEnable);
        if (isBtEnable) {
            isComputerSelect = isBtEnable;
            mTvComputerSelect.setText(getString(R.string.clear_all));
            mTvBetInfo.setVisibility(View.VISIBLE);
        } else {
            mTvComputerSelect.setText(getString(R.string.machine_selection));
            mTvBetInfo.setVisibility(View.GONE);
        }
    }

    @Override
    public void onMosaicNum(String buffer) {
        if (!Objects.equals("",buffer)){
            mBetParamBean.setBetNum(buffer);
        }

    }

    @Override
    public void onComputBetInfo(int bets) {
        mLotteryPresenter.setShowBetInfo(bets, mBetParamBean);
    }

    @Override
    public void onShowBetInfo(String buffer) {
        mTvBetInfo.setText(buffer);
    }

    public void isBetBtEnable() {
        mLotteryPresenter.isBetBtEnable(mPlayTypeBean);
    }

    public void setShowBetInfo(int bets) {
        mLotteryPresenter.setShowBetInfo(bets, mBetParamBean);
        mEtMultiple.setText(mBetParamBean.getMultiple());   //同步设置dialog返回时设置的倍数
        if ("1".equals(mBetParamBean.getBonusModel())) {
            mTvSettingSpecial.setText(getString(R.string.tv_setting_special));
        } else if ("10".equals(mBetParamBean.getBonusModel())) {
            mTvSettingSpecial.setText(getString(R.string.tv_setting_horn));
        } else if ("100".equals(mBetParamBean.getBonusModel())) {
            mTvSettingSpecial.setText(getString(R.string.tv_setting_branch));
        }
    }

    public void computBetInfoByInput(String str, int bets) {
        if (TextUtils.isEmpty(str) || bets == 0) {
            mTvPlaceOrder.setEnabled(false);
            mTvBetInfo.setVisibility(View.GONE);
        } else {
            mBetParamBean.setBetNum(str);
            setShowBetInfo(bets);
            mTvBetInfo.setVisibility(View.VISIBLE);
            mTvPlaceOrder.setEnabled(true);
        }
    }

    void createBottomNum() {
        if (mBottomNumDialog == null) {
            mBottomNumDialog = new BottomNumDialog(this, mEtMultiple);
            mBottomNumDialog.setListener(mBottomNumDialogShowOrHide);
            mBottomNumDialog.show();
        } else {
            mBottomNumDialog.show();
        }
    }

    BottomNumDialog.BottomNumDialogShowOrHide mBottomNumDialogShowOrHide = new BottomNumDialog.BottomNumDialogShowOrHide() {

        @Override
        public void show() {
            int bottomHeight = mBottomNumDialog.mLLBottomNum.getHeight();
            LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) mLlBottomMenu.getLayoutParams();
            lp.setMargins(0, 0, 0, bottomHeight);
            mLlBottomMenu.setLayoutParams(lp);
        }

        @Override
        public void hide() {
            LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) mLlBottomMenu.getLayoutParams();
            lp.setMargins(0, 0, 0, 0);
            mLlBottomMenu.setLayoutParams(lp);
            String multiple = mEtMultiple.getText().toString().trim();
            if (!TextUtils.isEmpty(multiple)) {
                mBetParamBean.setMultiple(multiple);
                mLotteryPresenter.setShowBetInfo(mBetParamBean.getBetCount(), mBetParamBean);
            } else {
                mEtMultiple.setText(mBetParamBean.getMultiple());
            }
        }
    };

    /**
     * 返回隐藏dialog键盘
     */
    @Override
    public void onBackPressed() {
        if (mBottomNumDialog != null && mBottomNumDialog.mBaseDialog.isShowing()) {
            mBottomNumDialog.dismiss();
        } else if (mPlayTypePopupWindow != null && mPlayTypePopupWindow.isShow()) {
            mPlayTypePopupWindow.dissMissPopWindow();
        } else {
            super.onBackPressed();
        }
    }

    public void orderDataChange(OrderEventBean orderEventBean) {
        int type = orderEventBean.getChangeDataType();
        if (type == -1) {
            mBetOrderBeans.clear();
        } else if (type >= 3000) {
            mBetOrderBeans.add(0, orderEventBean.getBetOrderBean());
        } else if (type >= 2000) {
            if (mBetOrderBeans.size() == 0)
                return;
            mBetOrderBeans.get(type % 2000).setMultiple(orderEventBean.getBetOrderBean().getMultiple());
            mBetOrderBeans.get(type % 2000).setBetAmount(orderEventBean.getBetOrderBean().getBetAmount());
        } else if (type >= 1000) {
            if (mBetOrderBeans.size() == 0)
                return;
            mBetOrderBeans.remove(type % 1000);
        }
    }

    @Override
    protected void onDestroy() {
        mPlayTypePopupWindow.dissMissPopWindow();
        mCountDownTimerUtils.cancel();
        countDownTimer.cancel();
        mHeadView.dismissPop();
        mLotteryPresenter.onDestory();
        if (mBottomNumDialog != null)
            mBottomNumDialog.onDestory();
        super.onDestroy();
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        isCallBack = true;
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (isCallBack) {
            isCallBack = false;
            if (mCountDownTimerUtils != null && mLotteryPresenter != null) {
                if (mTimeTextView.getText().toString().equalsIgnoreCase("00:00:00")) {
                    mLotteryPresenter.getLotteryExpect();
                }
            }
        }
    }
}
