package com.dawoo.lotterybox.mvp.model.activity;

import com.dawoo.lotterybox.bean.BannerBean;
import com.dawoo.lotterybox.bean.Bulletin;
import com.dawoo.lotterybox.bean.PromoContentBean;
import com.dawoo.lotterybox.bean.PromoListBean;
import com.dawoo.lotterybox.mvp.model.BaseModel;
import com.dawoo.lotterybox.mvp.service.IActivityService;
import com.dawoo.lotterybox.net.RetrofitHelper;
import java.util.List;

import io.reactivex.Observable;
import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;


/**
 * Created by b on 18-2-16.
 */

public class ActivityModel extends BaseModel implements IActivityModel {


    public void getHallPageData() {
        Observable<List<BannerBean>> observableBanner = RetrofitHelper
                .getService(IActivityService.class)
                .getBanner()
                .map(new HttpResultFunc<List<BannerBean>>());
        Observable<List<Bulletin>> observableBullet = RetrofitHelper
                .getService(IActivityService.class)
                .getBulletin()
                .map(new HttpResultFunc<List<Bulletin>>());

    }

    @Override
    public Disposable getBanner(Observer subscriber) {
        Observable<List<BannerBean>> observable = RetrofitHelper
                .getService(IActivityService.class)
                .getBanner()
                .map(new HttpResultFunc<List<BannerBean>>());

        return toSubscribe(observable, subscriber);
    }

    @Override
    public Disposable getBulletin(Observer subscriber) {
        Observable<List<Bulletin>> observable = RetrofitHelper
                .getService(IActivityService.class)
                .getBulletin()
                .map(new HttpResultFunc<List<Bulletin>>());
        return toSubscribe(observable, subscriber);
    }

    @Override
    public Disposable getPromoList(Observer subscriber, int pageSize, int pageNumber) {
        Observable<PromoListBean> observable = RetrofitHelper
                .getService(IActivityService.class)
                .getPromoList(pageSize, pageNumber);
        return toSubscribe(observable, subscriber);
    }

    @Override
    public Disposable getPromoContent(Observer subscriber, int id) {
        Observable<PromoContentBean> observable = RetrofitHelper
                .getService(IActivityService.class)
                .getPromoContent(id)
                .map(new HttpResultFunc<PromoContentBean>());
        return toSubscribe(observable, subscriber);
    }

    @Override
    public Disposable getCSLink(Observer subscriber) {
        Observable<String> observable = RetrofitHelper
                .getService(IActivityService.class)
                .getCustomerServiceLink()
                .map(new HttpResultFunc<String>());
        return toSubscribe(observable, subscriber);
    }
}
