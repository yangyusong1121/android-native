package com.dawoo.lotterybox.util.lottery;

import android.text.TextUtils;

import com.dawoo.lotterybox.R;
import com.dawoo.lotterybox.bean.lottery.lotteryenum.BaseLotteryEnum;
import com.dawoo.lotterybox.bean.lottery.lotteryenum.LotteryBettingEnum;
import com.dawoo.lotterybox.bean.lottery.lotteryenum.LotteryPlayEnum;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * 彩票工具类
 * Created by benson on 18-2-13.
 */

public class LotteryUtil {

    /**
     * 彩票头部右侧布局 index
     */

    public static final int TOP_BASE = 0;
    public static final int TOP_XY28 = 1;
    public static final int TOP_BJKL8 = 2;
    public static final int TOP_PK10 = 3;
    public static final int TOP_HKLHC = 4;


    /**
     * 根据彩种代码获取彩种名称
     *
     * @param code
     * @return
     */
    public static int getDataTypeByCode(String code) {
        for (BaseLotteryEnum num : BaseLotteryEnum.values()) {
            if (num.getType().equalsIgnoreCase(code)) {
                return num.getRcdFlag();
            }
        }
        return 10;
    }

    /**
     * 根据彩票玩法
     *
     * @param betCode
     * @return
     */
    public static String getPlayNameByCode(String betCode, String playCode) {
        String playName = "";
        for (LotteryBettingEnum num : LotteryBettingEnum.values()) {
            if (num.getCode().equalsIgnoreCase(betCode)) {
                playName += num.getTrans();
                break;
            }
        }

        for (LotteryPlayEnum num : LotteryPlayEnum.values()) {
            if (num.getCode().equalsIgnoreCase(playCode)) {
                playName += num.getTrans();
                break;
            }
        }
        return playName;
    }

    /**
     * 根据彩票玩法  有@
     *
     * @param betCode
     * @return
     */
    public static String getPlayNameByCode2(String betCode, String playCode) {
        String playName = "";
        for (LotteryBettingEnum num : LotteryBettingEnum.values()) {
            if (num.getCode().equalsIgnoreCase(betCode)) {
                playName += num.getTrans();
                break;
            }
        }

        for (LotteryPlayEnum num : LotteryPlayEnum.values()) {
            if (num.getCode().equalsIgnoreCase(playCode)) {
                playName += ("@" + num.getTrans());
                break;
            }
        }
        return playName;
    }

    /**
     * 根据彩票玩法
     *
     * @param betCode
     * @return
     */
    public static String getBetNameByCode(String betCode) {
        String playName = "";
        for (LotteryBettingEnum num : LotteryBettingEnum.values()) {
            if (num.getCode().equalsIgnoreCase(betCode)) {
                playName += num.getTrans();
                break;
            }
        }
        return playName;
    }

    public static String getPlayName(String playCode) {
        String playName = "";

        for (LotteryPlayEnum num : LotteryPlayEnum.values()) {
            if (num.getCode().equalsIgnoreCase(playCode)) {
                playName += num.getTrans();
                break;
            }
        }
        return playName;
    }

    /**
     * 获取A盘11选5的 和数 跨度
     *
     * @param openCode
     * @return
     */

    public static String get11Select5_A(String openCode) {
        if (TextUtils.isEmpty(openCode)) return "";
        String[] numbers = openCode.split(",");
        if (numbers == null) return "";
        List<String> numberList = Arrays.asList(numbers);
        Collections.sort(numberList);
        int count = 0;
        int mantissa = 0;
        if (numbers.length == 5) {
            for (String s : numbers) {
                if (!s.isEmpty()) {
                    count += Integer.parseInt(s);
                }
            }
            mantissa = Math.abs(Integer.parseInt(numbers[0]) - Integer.parseInt(numbers[4]));
        }
        return "和数:" + count + ",跨度:" + mantissa;
    }

    /**
     * 获取A盘K3中奖结果
     *
     * @param openCode
     * @return
     */
    public static String getK3_A(String openCode) {

        if (TextUtils.isEmpty(openCode)) return "";
        String[] nums = openCode.split(",");
        if (nums == null) return "";

        int count = 0;
        for (String s : nums) {
            if (!s.isEmpty())
                count += Integer.parseInt(s);
        }

        if (nums[0].equalsIgnoreCase(nums[1]) && nums[1].equalsIgnoreCase(nums[2])) {
            return count + " " + "通吃";
        } else {
            String dx = (count < 11) ? "小" : "大";
            String ds = ((count % 2) == 0) ? "双" : "单";
            return count + " " + dx + " " + ds;
        }
    }

    /**
     * 获取A盘PK10 中奖结果
     *
     * @param openCode
     * @return
     */
    public static String getPK10_A(String openCode) {

        if (TextUtils.isEmpty(openCode)) return "";
        String[] nums = openCode.split(",");
        if (nums == null) return "";

        StringBuffer strNum = new StringBuffer();
        int num = Integer.valueOf(nums[0]) + Integer.valueOf(nums[1]);
        strNum.append(num + ",");
        strNum.append((num % 2) == 0 ? "双," : "单,");
        strNum.append(num < 12 ? "小," : "大,");
        strNum.append(Integer.valueOf(nums[0]) > Integer.valueOf(nums[9]) ? "龙," : "虎,");
        strNum.append(Integer.valueOf(nums[1]) > Integer.valueOf(nums[8]) ? "龙," : "虎,");
        strNum.append(Integer.valueOf(nums[2]) > Integer.valueOf(nums[7]) ? "龙," : "虎,");
        strNum.append(Integer.valueOf(nums[3]) > Integer.valueOf(nums[6]) ? "龙," : "虎,");
        strNum.append(Integer.valueOf(nums[4]) > Integer.valueOf(nums[5]) ? "龙" : "虎");
        return strNum.toString();
    }

    /**
     * 获取A盘福彩3D 中奖结果
     *
     * @param openCode
     * @return
     */

    public static String getFC3D_A(String openCode) {
        if (TextUtils.isEmpty(openCode)) return "";
        String[] numbers = openCode.split(",");
        if (numbers == null) return "";

        int count = 0;
        int[] num = new int[numbers.length];
        for (int i = 0; i < numbers.length; i++) {
            num[i] = Integer.parseInt(numbers[i]);
            count += num[i];
        }

        if (numbers.length == 3) {   //接口没做好，可能会有奇怪的结果
            StringBuffer numStatus = new StringBuffer();
            String dxds1, dxds2;
            dxds1 = (num[1] < 5) ? "小" : "大" + (((num[1] % 2) == 0) ? "双" : "单");
            dxds2 = (num[2] < 5) ? "小" : "大" + (((num[2] % 2) == 0) ? "双" : "单");

            String mantissa;
            if (Integer.valueOf(numbers[0]) == Integer.valueOf(numbers[1]) ||
                    Integer.valueOf(numbers[0]) == Integer.valueOf(numbers[2]) ||
                    Integer.valueOf(numbers[1]) == Integer.valueOf(numbers[2]))
                mantissa = "组三";

            else mantissa = "组六";

            return count + " " + dxds1 + " " + dxds2 + " " + mantissa;
        } else return "";
    }
}
