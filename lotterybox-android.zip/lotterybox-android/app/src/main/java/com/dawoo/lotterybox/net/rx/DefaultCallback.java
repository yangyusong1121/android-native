package com.dawoo.lotterybox.net.rx;

/**
 * Created by alex on 18-4-2.
 */

public interface DefaultCallback {
    void start();
    void complete();
}
