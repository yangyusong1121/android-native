package com.dawoo.lotterybox.mvp.model.user;


import org.reactivestreams.Subscriber;
import org.reactivestreams.Subscription;

import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;

/**
 * Created by benson on 17-12-21.
 */

public interface IUserModel {
    Disposable login(Observer subscriber, String name, String pwd, String appKey, String appSecret, String serialNo);

    Disposable register(Observer subscriber, String name, String pwd, String confirmPwd, String createChannel, String playerType, String mode, String promoCode);

    Disposable createAccount(Observer subscriber, String name, String pwd, String createChannel, String playerType, String parentId);

    Disposable getUserInfo(Observer subscriber);

    Disposable signOut(Observer subscriber);

    Disposable upDatePasswold(Observer subscriber, String oldPwd, String newPwd);

    Disposable upDateNickName(Observer subscriber, String nickName);

    Disposable upDateRealName(Observer subscriber, String realName);

    Disposable upDatePermissionPassword(Observer subscriber, String upDatePermissionPassword);

    Disposable quirePermissionPassword(Observer subscriber, String upDatePermissionPassword);


    Disposable getUserInfoWithSystemSetting(Observer subscriber);

    Disposable getCreateAccocuntLink(Observer subscriber);

    Disposable checkLoginName(Observer subscriber, String name);

    Disposable checkAccount(Observer subscriber, String name, String realName, String bankCardNumber);

    Disposable accountPassword(Observer subscriber, String name, String password);

    Disposable testAccountLogin(Observer subscriber, String appkey, String appSecret, String serialNo);

    Disposable applyAgent(Observer subscriber);

    Disposable getHelp(Observer subscriber);

}
