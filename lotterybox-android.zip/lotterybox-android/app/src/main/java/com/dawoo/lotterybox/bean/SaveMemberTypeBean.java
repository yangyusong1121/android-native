package com.dawoo.lotterybox.bean;

import android.os.Parcel;
import android.os.Parcelable;

/**
 - @Description:  保存下级会员申请代理审核结果
 - @Author:  bella
 - @Time:  18-7-19 上午9:23
 */

public class SaveMemberTypeBean implements Parcelable {
    private int error;
    private boolean data;

    public int getError() {
        return error;
    }

    public void setError(int error) {
        this.error = error;
    }

    public boolean isData() {
        return data;
    }

    public void setData(boolean data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "SaveMemberTypeBean{" +
                "error=" + error +
                ", data=" + data +
                '}';
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(this.error);
        dest.writeByte(this.data ? (byte) 1 : (byte) 0);
    }

    public SaveMemberTypeBean() {
    }

    protected SaveMemberTypeBean(Parcel in) {
        this.error = in.readInt();
        this.data = in.readByte() != 0;
    }

    public static final Creator<SaveMemberTypeBean> CREATOR = new Creator<SaveMemberTypeBean>() {
        @Override
        public SaveMemberTypeBean createFromParcel(Parcel source) {
            return new SaveMemberTypeBean(source);
        }

        @Override
        public SaveMemberTypeBean[] newArray(int size) {
            return new SaveMemberTypeBean[size];
        }
    };
}
