package com.dawoo.lotterybox.mvp.view;

/**
 * Created by alex on 18-5-4.
 */

public interface IFeedBackView extends IBaseView {
    void feedBackResult(Object o);
}
