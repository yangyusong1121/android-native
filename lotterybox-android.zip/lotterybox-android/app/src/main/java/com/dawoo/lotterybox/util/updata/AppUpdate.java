package com.dawoo.lotterybox.util.updata;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Message;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.FileProvider;

import com.dawoo.coretool.ToastUtil;
import com.dawoo.coretool.util.activity.ActivityStackManager;
import com.dawoo.lotterybox.BuildConfig;
import com.dawoo.lotterybox.R;
import com.dawoo.lotterybox.bean.UpdateInfo;
import com.dawoo.lotterybox.view.view.sweetalert.SweetAlertDialog;
import com.zhy.http.okhttp.OkHttpUtils;

import java.io.File;

import okhttp3.Call;

public class AppUpdate {

    private static final String TAG = AppUpdate.class.getSimpleName();
    private Activity activity;
    private UpdateInfo ui;
    private SweetAlertDialog pDialog;
    private String apkName;

    public AppUpdate(Activity activity) {
        this.activity = activity;
        apkName = "/" + activity.getResources().getString(R.string.app_name) + ".apk";
    }


    /**
     * 获取版本号(内部识别号)
     *
     * @param context
     * @return
     */
    public static int getVersionCode(Context context)//获取版本号(内部识别号)
    {
        try {
            PackageInfo pi = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
            return pi.versionCode;
        } catch (PackageManager.NameNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return 0;
        }
    }

    /**
     * 检查版本更新
     */
    public void checkUpdate(SweetAlertDialog mDialog, UpdateInfo updateInfo) {
        this.pDialog = mDialog;
        this.ui = updateInfo;
        if (ui.versionCode <= BuildConfig.VERSION_CODE || ui == null) {
            return;
        }
        pDialog = new SweetAlertDialog(activity, SweetAlertDialog.APPUPDATA_TYPE)
                .setContentTitle("版本提示")
                .setTitleText("发现新版本："+ui.versionName)
                .setContentText(ui.memo)
                .setConfirmText("立即更新")
                .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                    @Override
                    public void onClick(SweetAlertDialog sweetAlertDialog) {
                        // pDialog.dismiss();
                        applyAuth();
                    }
                })
                .setCancelText("暂不更新")
                .setCancelClickListener(new SweetAlertDialog.OnSweetClickListener() {
                    @Override
                    public void onClick(SweetAlertDialog sweetAlertDialog) {
                        if (ui.renew) {
                            pDialog.dismiss();
                            ActivityStackManager.getInstance().finishAllActivity();
                        } else {
                            pDialog.dismiss();
                        }
                        //  finish();
                    }
                });
        if (ui.renew) {
            pDialog.setCancelable(false);
            pDialog.setCanceledOnTouchOutside(false);
        } else {
            pDialog.setCancelable(true);
            pDialog.setCanceledOnTouchOutside(true);
        }

        pDialog.show();
    }


    private void applyAuth() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            // 检查该权限是否已经获取
            int hasAuth = ContextCompat.checkSelfPermission(activity, Manifest.permission.WRITE_EXTERNAL_STORAGE);
            // 权限是否已经 授权 GRANTED---授权  DINIED---拒绝
            if (hasAuth != PackageManager.PERMISSION_GRANTED) {
                // 提交请求权限
                ActivityCompat.requestPermissions(activity,
                        new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
            } else {
                downloadApp();
            }
        } else {
            downloadApp();
        }
    }


    public void downloadApp() {
        pDialog.changeAlertType(SweetAlertDialog.PROGRESS_TYPE);
        pDialog.showCancelButton(false);
        pDialog.showContentText(false);
        pDialog.setCancelable(false);
        pDialog.getProgressHelper().setBarColor(activity.getResources().getColor(R.color.colorPrimary));
        pDialog.show();
        //  pDialog.getProgressHelper().stopSpinning();
        //http://gbapifdxssaa20.info:88/android/4.0.0/app_8l6r_4.0.0.apk
        // 是不是http开头
        // 第一个字符是不是包含反斜杠
        if (ui.getAndroidUpdateUrl() == null || ui.getAndroidUpdateUrl().equals("")) {
            pDialog.changeAlertType(SweetAlertDialog.ERROR_TYPE);
            pDialog.setTitleText("更新地址为空!");
            pDialog.setConfirmText("取消");
            pDialog.setCancelable(true);
            pDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                @RequiresApi(api = Build.VERSION_CODES.O)
                @Override
                public void onClick(SweetAlertDialog sweetAlertDialog) {
                    pDialog.dismiss();
                }
            });
            return;
        }
//        if (!ui.appUrl.contains("http") || !ui.appUrl.contains("www.") || !ui.appUrl.contains(".apk")) {
//            pDialog.changeAlertType(SweetAlertDialog.ERROR_TYPE);
//            pDialog.setTitleText("更新地址不正确!");
//            pDialog.setConfirmText("取消");
//            pDialog.setCancelable(true);
//            pDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
//                @RequiresApi(api = Build.VERSION_CODES.O)
//                @Override
//                public void onClick(SweetAlertDialog sweetAlertDialog) {
//                    pDialog.dismiss();
//                }
//            });
//        } else {
        try {
            OkHttpUtils.get().url(ui.getAndroidUpdateUrl()).build().execute(new com.zhy.http.okhttp.callback.FileCallBack(getPublicDirectory(), apkName) {
                @Override
                public void onError(Call call, Exception e, int id) {
                    pDialog.changeAlertType(SweetAlertDialog.ERROR_TYPE);
                    pDialog.setTitleText("下载失败");
                    pDialog.showCancelButton(false);
                    pDialog.setConfirmText("确定");
                    pDialog.setCancelable(false);
                    pDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                        @Override
                        public void onClick(SweetAlertDialog sweetAlertDialog) {
                            pDialog.dismiss();
                            activity.finish();
                        }
                    });
                }

                @Override
                public void onResponse(File response, int id) {
                    File file = new File(getPublicDirectory() + apkName);
                    if (!file.getParentFile().exists()) {
                        file.getParentFile().mkdir();
                    }
                    final Intent intent = new Intent(Intent.ACTION_VIEW);
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                        intent.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        Uri contentUri = FileProvider.getUriForFile(activity, activity.getPackageName() + ".fileprovider", file);
                        intent.setDataAndType(contentUri, "application/vnd.android.package-archive");
                    } else {
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        intent.setDataAndType(Uri.parse("file://" + file.getAbsolutePath()),
                                "application/vnd.android.package-archive");
                    }

                    pDialog.changeAlertType(SweetAlertDialog.SUCCESS_TYPE);
                    pDialog.setTitleText("下载完成!");
                    pDialog.setConfirmText("安装");
                    pDialog.setCancelable(true);
                    pDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                        @RequiresApi(api = Build.VERSION_CODES.O)
                        @Override
                        public void onClick(SweetAlertDialog sweetAlertDialog) {
                            activity.startActivity(intent);
                        }
                    });
                }

                @Override
                public void inProgress(float progress, long total, int id) {
                    pDialog.setTitleText("已下载" + (int) (progress * 100) + "%");
                    // pDialog.getProgressHelper().setInstantProgress(progress);
                    // pDialog.getProgressHelper().setProgress(progress);
                }
            });
        } catch (Exception e) {
            pDialog.changeAlertType(SweetAlertDialog.ERROR_TYPE);
            pDialog.setTitleText("更新地址不正确!");
            pDialog.setConfirmText("取消");
            pDialog.setCancelable(true);
            pDialog.setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                @RequiresApi(api = Build.VERSION_CODES.O)
                @Override
                public void onClick(SweetAlertDialog sweetAlertDialog) {
                    pDialog.dismiss();
                }
            });
        }

//        }

    }


    public void permissionsResult(@NonNull int[] grantResults) {
        if (ui != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                downloadApp();
            }
        }
    }

    public static String getPublicDirectory() {
        return Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_DOWNLOADS).getAbsolutePath();
    }
}
