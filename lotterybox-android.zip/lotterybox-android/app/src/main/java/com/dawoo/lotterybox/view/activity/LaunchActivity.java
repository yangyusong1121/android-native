package com.dawoo.lotterybox.view.activity;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.Space;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.blankj.utilcode.util.ActivityUtils;
import com.blankj.utilcode.util.SPUtils;
import com.dawoo.lotterybox.R;
import com.dawoo.lotterybox.util.SPConfig;
import com.dawoo.lotterybox.view.activity.team.base.BindLayout;
import com.dawoo.lotterybox.view.activity.team.base.OnMultiClickListener;
import com.dawoo.lotterybox.view.activity.team.base.SuperBaseActivity;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * @author alex
 */
@BindLayout(R.layout.activity_launch)
public class LaunchActivity extends SuperBaseActivity {


    @BindView(R.id.vp_root)
    ViewPager vpRoot;
    @BindView(R.id.tv_in)
    Space tvIn;

    @Override
    protected void initData() {
        super.initData();
        LauncherAdapter launcherAdapter = new LauncherAdapter();
        vpRoot.setAdapter(launcherAdapter);

        tvIn.setOnClickListener(new OnMultiClickListener() {
            @Override
            public void onMultiClick(View v) {
                SPUtils.getInstance().put(SPConfig.LAUNCH,true);
                ActivityUtils.startActivity(MainActivity.class);
                finish();
            }
        });
        vpRoot.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                tvIn.setVisibility(position==2?View.VISIBLE:View.GONE);
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
    }

    class LauncherAdapter extends PagerAdapter{
        int [] drawables={R.mipmap.launch01,R.mipmap.launch02,R.mipmap.launch03};
        @Override
        public int getCount() {
            return drawables.length;
        }

        @Override
        public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
            return view==object;
        }

        @Override
        public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
            container.removeView((View) object);
        }


        @NonNull
        @Override
        public Object instantiateItem(@NonNull ViewGroup container, int position) {
            ImageView imageView = new ImageView(container.getContext());
            imageView.setBackground(getResources().getDrawable(drawables[position]));
            container.addView(imageView);
            return imageView;
        }
    }
}
