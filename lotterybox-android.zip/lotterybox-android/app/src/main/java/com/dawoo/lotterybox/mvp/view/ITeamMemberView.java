package com.dawoo.lotterybox.mvp.view;

import com.dawoo.lotterybox.bean.TeamMemberBean;
import com.dawoo.lotterybox.bean.TeamhasRatioBean;

import java.util.List;

/**
 * Created by alex on 18-4-24.
 */

public interface ITeamMemberView extends IBaseView {
    void onRefreshResult(List<TeamMemberBean> o);

    void onLoaderMoreResult(List<TeamMemberBean> o);

    void onHasRatioResult(TeamhasRatioBean o);
}
