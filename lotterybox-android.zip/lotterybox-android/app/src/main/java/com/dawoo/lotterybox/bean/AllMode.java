package com.dawoo.lotterybox.bean;

import com.dawoo.lotterybox.bean.lottery.hall.AllLotteryBean;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by rain on 18-5-31.
 */

public class AllMode {
    private List<AllLotteryBean> official = new ArrayList<>();
    private List<AllLotteryBean> tradition = new ArrayList<>();

    public List<AllLotteryBean> getOfficial() {
        return official;
    }

    public void setOfficial(List<AllLotteryBean> official) {
        this.official = official;
    }

    public List<AllLotteryBean> getTradition() {
        return tradition;
    }

    public void setTradition(List<AllLotteryBean> tradition) {
        this.tradition = tradition;
    }
}
