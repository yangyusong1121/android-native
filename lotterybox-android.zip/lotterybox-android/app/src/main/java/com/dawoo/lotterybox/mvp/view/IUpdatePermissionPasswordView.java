package com.dawoo.lotterybox.mvp.view;

import com.dawoo.lotterybox.bean.InfoMation;
import com.dawoo.lotterybox.net.BaseHttpResult;

/**
 * Created by jack on 18-2-12.
 */

public interface IUpdatePermissionPasswordView extends IBaseView {
    void onResult(BaseHttpResult baseHttpResult);
}
