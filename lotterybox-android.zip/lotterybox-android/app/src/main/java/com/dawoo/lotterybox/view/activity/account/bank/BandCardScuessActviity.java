package com.dawoo.lotterybox.view.activity.account.bank;

import android.support.v7.widget.CardView;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.dawoo.lotterybox.R;
import com.dawoo.lotterybox.bean.DataCenter;
import com.dawoo.lotterybox.bean.MyBandCard;
import com.dawoo.lotterybox.mvp.presenter.BankCardPreserter;
import com.dawoo.lotterybox.mvp.view.IBandCardListIView;
import com.dawoo.lotterybox.util.MSPropties;
import com.dawoo.lotterybox.util.NetUtil;
import com.dawoo.lotterybox.util.ViewUtils;
import com.dawoo.lotterybox.view.activity.BaseActivity;
import com.dawoo.lotterybox.view.activity.account.withdraw.WithdrawalsActivity;
import com.dawoo.lotterybox.view.view.HeaderView;

import java.util.List;

import butterknife.BindView;

/**
 * @author jack
 * @date 18-2-20
 * 银行卡列表成功界面
 */
public class BandCardScuessActviity extends BaseActivity implements  IBandCardListIView {
    @BindView(R.id.head_view)
    HeaderView headView;
    @BindView(R.id.card_iamge)
    ImageView cardIamge;
    @BindView(R.id.card_name)
    TextView cardName;
    @BindView(R.id.card_number)
    TextView cardNumber_tv;
    @BindView(R.id.user_name)
    TextView userName;
    @BindView(R.id.card_type)
    TextView cardType;
    @BindView(R.id.add_card)
    LinearLayout addCard;
    private CardView bandcardscuessActivity;


    private BankCardPreserter bankCardPreserter;


    @Override
    protected void createLayoutView() {
        setContentView(R.layout.activity_bankcardscuess);

        bandcardscuessActivity = findViewById(R.id.bandcardscuessActivity);
        bankCardPreserter = new BankCardPreserter<IBandCardListIView>(this, this);
        bandcardscuessActivity.setVisibility(View.VISIBLE);
    }

    @Override
    protected void initViews() {
        headView.setHeader(getResources().getString(R.string.my_card), true);

    }

    @Override
    protected void errorRetry() {
        super.errorRetry();
        initData();
    }

    @Override
    protected void initData() {
        super.initData();
        MSPropties.getBanklistStastus(bankCardPreserter);
    }

    @Override
    public void bandCardList(Object o) {
        errorRetryResult();
        List<MyBandCard> myBandCard = (List<MyBandCard>) o;
        bandcardscuessActivity.setVisibility(View.VISIBLE);
        cardName.setText(myBandCard.get(0).getBankName());
        cardType.setText(myBandCard.get(0).getBankCode());
        userName.setText(myBandCard.get(0).getMasterName());
        cardNumber_tv.setText(myBandCard.get(0).getCardNumber());
        //ViewUtils.showBankImage(this,cardIamge,myBandCard.get(0).getBankName());
        RequestOptions requestOptions = new RequestOptions();
        requestOptions.placeholder(getResources().getDrawable(R.drawable.ic_default_img));
        Glide.with(BandCardScuessActviity.this).load(NetUtil.handleUrl( myBandCard.get(0).getIconUrl())).apply(requestOptions).into(cardIamge);
        if (DataCenter.getInstance().getUser().isBindBankCard()){
            addCard.setVisibility(View.GONE);
        }else {
            addCard.setVisibility(View.VISIBLE);
        }

    }


}
