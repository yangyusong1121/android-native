package com.dawoo.lotterybox.mvp.view;

import com.dawoo.lotterybox.bean.WithDrawsDetailBean;

/**
 * Created by alex on 18-5-14.
 */

public interface IWithDrawsDetailView extends IBaseView{

    void resultDetail(WithDrawsDetailBean drawsDetailBean);
}
