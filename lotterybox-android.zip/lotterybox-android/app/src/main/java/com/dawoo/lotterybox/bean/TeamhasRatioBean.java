package com.dawoo.lotterybox.bean;

/**
 * Created by alex on 18-4-25.
 */

public class TeamhasRatioBean {
    /**
     * dividenStatus : 1
     * salaryStatus : 0
     */

    private int dividenStatus;
    private int salaryStatus;

    public int getDividenStatus() {
        return dividenStatus;
    }

    public void setDividenStatus(int dividenStatus) {
        this.dividenStatus = dividenStatus;
    }

    public int getSalaryStatus() {
        return salaryStatus;
    }

    public void setSalaryStatus(int salaryStatus) {
        this.salaryStatus = salaryStatus;
    }
}
