package com.dawoo.lotterybox.mvp.view;

import com.dawoo.lotterybox.bean.PromoContentBean;

import java.util.List;

/**
 * Created by b on 18-3-16.
 */

public interface IPromoContentView extends IBaseView {
    void onPromoContent(PromoContentBean promoContentBeans);
}
