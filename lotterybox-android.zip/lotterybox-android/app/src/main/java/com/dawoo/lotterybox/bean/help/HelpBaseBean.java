package com.dawoo.lotterybox.bean.help;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.List;

public class HelpBaseBean implements Parcelable {
    private  int error;

    @Override
    public String toString() {
        return "HelpBaseBean{" +
                "error=" + error +
                ", data=" + data +
                '}';
    }

    private  List<HelpBean> data;


    public int getError() {
        return error;
    }

    public void setError(int error) {
        this.error = error;
    }

    public List<HelpBean> getData() {
        return data;
    }

    public void setData(List<HelpBean> data) {
        this.data = data;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(this.error);
        dest.writeTypedList(this.data);
    }

    public HelpBaseBean() {
    }

    protected HelpBaseBean(Parcel in) {
        this.error = in.readInt();
        this.data = in.createTypedArrayList(HelpBean.CREATOR);
    }

    public static final Creator<HelpBaseBean> CREATOR = new Creator<HelpBaseBean>() {
        @Override
        public HelpBaseBean createFromParcel(Parcel source) {
            return new HelpBaseBean(source);
        }

        @Override
        public HelpBaseBean[] newArray(int size) {
            return new HelpBaseBean[size];
        }
    };
}
