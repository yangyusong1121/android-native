package com.dawoo.lotterybox.bean.record;

/**
 * Created by rain on 18-4-19.
 */

public class BillCommonBean {
    private double expendmoney;
    private double withdrawmoney;
    private double depositmoney;
    private double favorablemoney;
    private double incomemoney;

    public double getExpendmoney() {
        return expendmoney;
    }

    public void setExpendmoney(double expendmoney) {
        this.expendmoney = expendmoney;
    }

    public double getWithdrawmoney() {
        return withdrawmoney;
    }

    public void setWithdrawmoney(double withdrawmoney) {
        this.withdrawmoney = withdrawmoney;
    }

    public double getDepositmoney() {
        return depositmoney;
    }

    public void setDepositmoney(double depositmoney) {
        this.depositmoney = depositmoney;
    }

    public double getFavorablemoney() {
        return favorablemoney;
    }

    public void setFavorablemoney(double favorablemoney) {
        this.favorablemoney = favorablemoney;
    }

    public double getIncomemoney() {
        return incomemoney;
    }

    public void setIncomemoney(double incomemoney) {
        this.incomemoney = incomemoney;
    }
}
