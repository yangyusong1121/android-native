package com.dawoo.lotterybox.mvp.view;


/**
 * Created by jack on 18-2-11.
 */

public interface ISignOutView extends IBaseView {
    void onResult(Object o);
}
