package com.dawoo.lotterybox.util;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.text.TextUtils;
import android.util.Log;

import com.dawoo.coretool.util.packageref.PackageInfoUtil;
import com.dawoo.lotterybox.BoxApplication;
import com.dawoo.lotterybox.BuildConfig;
import com.dawoo.lotterybox.ConstantValue;
import com.dawoo.lotterybox.bean.DataCenter;

import java.io.IOException;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.Enumeration;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;
import okhttp3.logging.HttpLoggingInterceptor;

/**
 * Created by archar on 18-1-25.
 * <p>
 * 上传所有的错误线路信息
 */

public class UploadErrorLinesUtil {

    private static int count = 0;

    /**
     * 上传app崩溃日志
     *
     * @param errorMessages
     * @param mark
     * @param isApp         2:为app崩溃bug  1为域名bug
     */
    public static void uploadAppCrashLog(String errorMessages, String codes, String mark, boolean isApp) {
        Log.e("LineUtil  errorMessages", errorMessages);
        Log.e("LineUtil  mark", mark);
        String siteId = resolvePackgeName();
        String userName = DataCenter.getInstance().getUser().getUsername();
        String lastLoginTime = "";
        String domain = DataCenter.getInstance().getDomain();
        //String ip = DataCenter.getInstance().getIp();
        doUpload(siteId, userName, lastLoginTime, domain, errorMessages, codes, mark, isApp);
    }


    /**
     * 发起请求
     *
     * @param siteId
     * @param userName
     * @param lastLoginTime
     * @param domain
     * @param errorMessages
     * @param codes
     * @param mark
     * @param isApp
     */
    public static void doUpload(String siteId, String userName, String lastLoginTime, String domain,
                                String errorMessages, String codes, String mark, boolean isApp) {
        if (TextUtils.isEmpty(domain)) {
            return;
        }
        if (count > 0) return;
        String url = BuildConfig.BASE_URL + ConstantValue.CATCH_URL;
        String content = "";

        StringBuffer sb = new StringBuffer();
        sb.append("siteId==" + siteId + "\n"); // 站点
        sb.append("username==" + userName + "\n"); // 名字
        sb.append("lastLoginTime==" + lastLoginTime + "\n"); // 时间
        sb.append("domain==" + domain + "\n"); // 域名
        sb.append("code==" + codes + "\n");  // 站点标示 或者错误域名的code
        sb.append("mark==" + mark + "\n"); // 标记随机码
        sb.append("versionName==" + PackageInfoUtil.getVersionName(BoxApplication.getContext()) + "\n");// 版本号
        sb.append("sysCode==" + Build.VERSION.RELEASE + "\n");// 版本号
        sb.append("brand==" + Build.BRAND + "\n");// 版本号
        sb.append("Androidversions==" + Build.VERSION.RELEASE + "\n");// Android 版本号
        sb.append("model==" + Build.MODEL + "\n");// 手机型号
        sb.append("errorMessage==" + errorMessages + "\n");// 手机型号
        content = sb.toString();
        String token = DataCenter.getInstance().getUser().getToken();
        Log.e("LineUtil  siteId", siteId);

        // okHttpClient.newBuilder().sslSocketFactory(SSLUtil.createSSLSocketFactory(), new SSLUtil.TrustAllManager());

        count++;
        RequestBody body = new FormBody.Builder().add("content", content)
                .build();
        OkHttpClient.Builder builder = new OkHttpClient.Builder();
        Request request = new Request.Builder().url(url).post(body).build();
        Call call = builder.build().newCall(request);

        call.enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.e("LineUtil  ", "上传错误线路信息失败: " + e.getMessage());
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                 Log.e("LineUtil  ", "上传错误线路信息结果 response:" + response.toString());
                Log.e("LineUtil  ", "上传错误线路信息结果 code:" + response.code());
            }
        });
    }


    /**
     * 处理站点id
     *
     * @return
     */
    public static String resolvePackgeName() {
        String packageName = BoxApplication.getContext().getPackageName();

        String subStr = packageName.substring(packageName.indexOf("sid"));
        if (subStr.contains("debug")) {
            return subStr.substring(3, subStr.lastIndexOf("."));
        } else {
            return subStr.substring(3);
        }
    }


    private static String getIPAddress(Context context) {
        NetworkInfo info = ((ConnectivityManager) context
                .getSystemService(Context.CONNECTIVITY_SERVICE)).getActiveNetworkInfo();
        if (info != null && info.isConnected()) {
            if (info.getType() == ConnectivityManager.TYPE_MOBILE) {//当前使用2G/3G/4G网络
                try {
                    //Enumeration<NetworkInterface> en=NetworkInterface.getNetworkInterfaces();
                    for (Enumeration<NetworkInterface> en = NetworkInterface.getNetworkInterfaces(); en.hasMoreElements(); ) {
                        NetworkInterface intf = en.nextElement();
                        for (Enumeration<InetAddress> enumIpAddr = intf.getInetAddresses(); enumIpAddr.hasMoreElements(); ) {
                            InetAddress inetAddress = enumIpAddr.nextElement();
                            if (!inetAddress.isLoopbackAddress() && inetAddress instanceof Inet4Address) {
                                return inetAddress.getHostAddress();
                            }
                        }
                    }
                } catch (SocketException e) {
                    e.printStackTrace();
                }

            } else if (info.getType() == ConnectivityManager.TYPE_WIFI) {//当前使用无线网络
                WifiManager wifiManager = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);
                WifiInfo wifiInfo = wifiManager.getConnectionInfo();
                String ipAddress = intIP2StringIP(wifiInfo.getIpAddress());//得到IPV4地址
                return ipAddress;
            }
        } else {
            //当前无网络连接,请在设置中打开网络
        }
        return null;
    }

    /**
     * 将得到的int类型的IP转换为String类型
     *
     * @param ip
     * @return
     */
    private static String intIP2StringIP(int ip) {
        return (ip & 0xFF) + "." +
                ((ip >> 8) & 0xFF) + "." +
                ((ip >> 16) & 0xFF) + "." +
                (ip >> 24 & 0xFF);
    }
}
