package com.dawoo.lotterybox.mvp.view;


import com.dawoo.lotterybox.net.BaseHttpResult;

/**
 * @author jack
 * @date 18-2-11
 */

public interface IUserInfoMation extends IBaseView {
    void onResultNickName(BaseHttpResult o);
}
