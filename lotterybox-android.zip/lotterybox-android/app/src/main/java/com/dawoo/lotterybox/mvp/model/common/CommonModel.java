package com.dawoo.lotterybox.mvp.model.common;

import com.dawoo.lotterybox.mvp.model.BaseModel;
import com.dawoo.lotterybox.mvp.service.ICommonService;
import com.dawoo.lotterybox.mvp.service.ILotteryService;
import com.dawoo.lotterybox.net.RetrofitHelper;

import io.reactivex.Observable;
import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;

/**
 * Created by b on 18-5-24.
 */

public class CommonModel extends BaseModel implements ICommonModel {

    /**
     *获取防重token
     * */

    @Override
    public Disposable getLtToken(Observer subscriber) {
        Observable<String> observable = RetrofitHelper
                .getService(ICommonService.class)
                .getLtToken()
                .map(new BaseModel.HttpResultFunc<>());
        return toSubscribe(observable, subscriber);
    }
}
