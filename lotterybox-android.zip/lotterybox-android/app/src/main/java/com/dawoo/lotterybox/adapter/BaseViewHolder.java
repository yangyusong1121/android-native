package com.dawoo.lotterybox.adapter;

import android.support.v7.widget.RecyclerView;
import android.view.View;

/**
 * Created by benson on 17-12-24.
 */

public class BaseViewHolder extends RecyclerView.ViewHolder {

    public BaseViewHolder(View itemView) {
        super(itemView);

    }


    public void onBindView(int position) {

    }
}
