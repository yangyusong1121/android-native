package com.dawoo.lotterybox.bean;

import com.dawoo.lotterybox.net.BaseHttpResult;

/**
 * Created by rain on 18-5-24.
 */

public class EasyHttpResult extends BaseHttpResult{
    String data;
    String extend;

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getExtend() {
        return extend;
    }

    public void setExtend(String extend) {
        this.extend = extend;
    }
}
