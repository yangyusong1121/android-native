package com.dawoo.lotterybox.mvp.model.Lottery;


import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;


/**
 * Created by benson on 18-2-8.
 */

public interface ILotteryModel {

    Disposable getRecentCloseExpect(Observer observer, String code);

    Disposable getLastOpenedAndOpeningResult(Observer observer);


    Disposable getResultByCode(Observer observer, String code, String pageSize, String pageNumber);

    Disposable getRecentRecords(Observer observer, String code, String pageSize);

    Disposable getLotteryExpect(Observer observer, String code);

    Disposable getLotteryOdd(Observer observer, String code, String betCode);

    Disposable saveBetOrder(Observer observer, String token, String betForm);


    Disposable getOrderInfo(Observer observer, String billNo, String code);

    Disposable getHomeLottery(Observer observer);

    Disposable getAllLottery(Observer Observer);

    Disposable getHallPageData(Observer observer);

    Disposable getAllCustomerbyCode(Observer observer,String expect,String code);
}
