package com.dawoo.lotterybox.bean;

import java.util.List;

public class NNCustomBean {

    /**
     * nn_xian_er : 400.0
     * nn_xian_san : 400.0
     * nn_xian_si : 200.0
     * nn_xian_wu : 200.0
     * nn_xian_yi : 400.0
     * listName : ["sm0001"]
     */

    private double nn_xian_er;
    private double nn_xian_san;
    private double nn_xian_si;
    private double nn_xian_wu;
    private double nn_xian_yi;
    private List<String> listName;

    public double getNn_xian_er() {
        return nn_xian_er;
    }

    public void setNn_xian_er(double nn_xian_er) {
        this.nn_xian_er = nn_xian_er;
    }

    public double getNn_xian_san() {
        return nn_xian_san;
    }

    public void setNn_xian_san(double nn_xian_san) {
        this.nn_xian_san = nn_xian_san;
    }

    public double getNn_xian_si() {
        return nn_xian_si;
    }

    public void setNn_xian_si(double nn_xian_si) {
        this.nn_xian_si = nn_xian_si;
    }

    public double getNn_xian_wu() {
        return nn_xian_wu;
    }

    public void setNn_xian_wu(double nn_xian_wu) {
        this.nn_xian_wu = nn_xian_wu;
    }

    public double getNn_xian_yi() {
        return nn_xian_yi;
    }

    public void setNn_xian_yi(double nn_xian_yi) {
        this.nn_xian_yi = nn_xian_yi;
    }

    public List<String> getListName() {
        return listName;
    }

    public void setListName(List<String> listName) {
        this.listName = listName;
    }
}
