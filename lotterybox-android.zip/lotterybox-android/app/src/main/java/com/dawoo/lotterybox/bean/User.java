package com.dawoo.lotterybox.bean;

import android.os.Parcel;
import android.os.Parcelable;

import com.blankj.utilcode.util.LogUtils;
import com.dawoo.lotterybox.bean.record.MutType;

import java.text.DecimalFormat;

/**
 * Created by benson on 17-12-21.
 */

public class User extends LoginBean implements Parcelable {
    /**
     * 协议头cookie
     */
    public String cookie = "";

    public String getCookie() {
        return cookie;
    }

    public void setCookie(String cookie) {
        this.cookie = cookie;
    }

    /**
     * 域名线路
     */
    private String domain;

    /**
     * 图片的服务器域名
     */
    private String imgDomain;

    /**
     * 是否登录
     */
    private boolean isLogin;

    /**
     * 玩家id
     */
    private long userId;
    /**
     * 玩家账号
     */
    private String username;
    /**
     * 用户的登录密码
     */
    private String password;
    /**
     * 昵称
     */
    private String nickname;

    /**
     * 玩家钱包余额
     */
    private String balance;

    /**
     * 头像相对路径
     */
    private String avatarUrl;

    /**
     * 是否绑定银行卡
     */
    private boolean isBindBankCard;

    /**
     * 是否设置安全密码
     */
    private boolean hasSecPwd;

    /**
     * 玩家等级
     */
    private String playerLevel;

    private String playerType;

    /**
     * 真实姓名
     *
     * @return
     */
    private String realname;

    private MutType mutType;

    private String authKey;


    /**
     * 申请代理状态
     * pending 待审核
     * success 审核成功
     * fail  审核失败
     * 默认为空
     * 为空 和fail 可以申请审核
     */
    private String becomeAgent;

    /**
     * 玩家类型 1 正常 2测试3混合 4试玩
     */
    private String mode;


    public String getPromoCode() {
        return promoCode;
    }

    public void setPromoCode(String promoCode) {
        this.promoCode = promoCode;
    }

    /**
     * 推广码
     */
    private String promoCode;



    private String host;

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public String getRealname() {
        return realname;
    }

    public void setRealname(String realname) {
        this.realname = realname;
    }

    public String getAuthKey() {
        return authKey;
    }

    public void setAuthKey(String authKey) {
        this.authKey = authKey;
    }

    public String getPlayerType() {
        return playerType;
    }

    public void setPlayerType(String playerType) {
        this.playerType = playerType;
    }


    public MutType getMutType() {
        return mutType;
    }

    public void setMutType(MutType mutType) {
        this.mutType = mutType;
    }

    public String getRealName() {
        return realname;
    }

    public void setRealName(String realname) {
        this.realname = realname;
    }

    public boolean isHasSecPwd() {
        return hasSecPwd;
    }

    public void setHasSecPwd(boolean hasSecPwd) {
        this.hasSecPwd = hasSecPwd;
    }

    public String getPlayerLevel() {
        return playerLevel;
    }

    public void setPlayerLevel(String playerLevel) {
        this.playerLevel = playerLevel;
    }

    public User() {
    }


    public String getImgDomain() {
        return imgDomain;
    }

    public void setImgDomain(String imgDomain) {
        this.imgDomain = imgDomain;
    }

    public String getDomain() {
        return domain;
    }

    public void setDomain(String domain) {
        this.domain = domain;

    }

    public boolean isLogin() {
        return isLogin;
    }

    public void setLogin(boolean login) {
        isLogin = login;
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public String getBalance() {
        return balance;
    }

    public void setBalance(String balance) {
        this.balance = balance;
    }

    public String getAvatarUrl() {
        return avatarUrl;
    }

    public void setAvatarUrl(String avatarUrl) {
        this.avatarUrl = avatarUrl;
    }

    public boolean isBindBankCard() {
        return isBindBankCard;
    }

    public void setBindBankCard(boolean bindBankCard) {
        isBindBankCard = bindBankCard;
    }

    public String getBecomeAgent() {
        return becomeAgent;
    }

    public void setBecomeAgent(String becomeAgent) {
        this.becomeAgent = becomeAgent;
    }

    public String getMode() {
        return mode;
    }

    public void setMode(String mode) {
        this.mode = mode;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.cookie);
        dest.writeString(this.domain);
        dest.writeString(this.imgDomain);
        dest.writeByte(this.isLogin ? (byte) 1 : (byte) 0);
        dest.writeLong(this.userId);
        dest.writeString(this.username);
        dest.writeString(this.password);
        dest.writeString(this.nickname);
        dest.writeString(this.balance);
        dest.writeString(this.avatarUrl);
        dest.writeByte(this.isBindBankCard ? (byte) 1 : (byte) 0);
        dest.writeByte(this.hasSecPwd ? (byte) 1 : (byte) 0);
        dest.writeString(this.playerLevel);
        dest.writeString(this.playerType);
        dest.writeString(this.realname);
        dest.writeSerializable(this.mutType);
        dest.writeString(this.authKey);
        dest.writeString(this.becomeAgent);
        dest.writeString(this.promoCode);
        dest.writeString(this.host);
        dest.writeString(this.mode);
    }

    protected User(Parcel in) {
        this.cookie = in.readString();
        this.domain = in.readString();
        this.imgDomain = in.readString();
        this.isLogin = in.readByte() != 0;
        this.userId = in.readLong();
        this.username = in.readString();
        this.password = in.readString();
        this.nickname = in.readString();
        this.balance = in.readString();
        this.avatarUrl = in.readString();
        this.isBindBankCard = in.readByte() != 0;
        this.hasSecPwd = in.readByte() != 0;
        this.playerLevel = in.readString();
        this.playerType = in.readString();
        this.realname = in.readString();
        this.mutType = (MutType) in.readSerializable();
        this.authKey = in.readString();
        this.becomeAgent = in.readString();
        this.promoCode = in.readString();
        this.host = in.readString();
        this.mode = in.readString();
    }

    public static final Creator<User> CREATOR = new Creator<User>() {
        @Override
        public User createFromParcel(Parcel source) {
            return new User(source);
        }

        @Override
        public User[] newArray(int size) {
            return new User[size];
        }
    };

    @Override
    public String toString() {
        return "User{" +
                "cookie='" + cookie + '\'' +
                ", domain='" + domain + '\'' +
                ", imgDomain='" + imgDomain + '\'' +
                ", isLogin=" + isLogin +
                ", userId=" + userId +
                ", username='" + username + '\'' +
                ", password='" + password + '\'' +
                ", nickname='" + nickname + '\'' +
                ", balance='" + balance + '\'' +
                ", avatarUrl='" + avatarUrl + '\'' +
                ", isBindBankCard=" + isBindBankCard +
                ", hasSecPwd=" + hasSecPwd +
                ", playerLevel='" + playerLevel + '\'' +
                ", playerType='" + playerType + '\'' +
                ", realname='" + realname + '\'' +
                ", mutType=" + mutType +
                ", authKey='" + authKey + '\'' +
                ", becomeAgent='" + becomeAgent + '\'' +
                ", promoCode='" + promoCode + '\'' +
                ", host='" + host + '\'' +
                '}';
    }
}

