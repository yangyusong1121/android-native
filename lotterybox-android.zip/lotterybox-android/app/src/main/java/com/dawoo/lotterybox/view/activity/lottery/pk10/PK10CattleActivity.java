package com.dawoo.lotterybox.view.activity.lottery.pk10;

import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.blankj.utilcode.util.ToastUtils;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.dawoo.lotterybox.ConstantValue;
import com.dawoo.lotterybox.R;
import com.dawoo.lotterybox.bean.lottery.Pk10BetOderBean;
import com.dawoo.lotterybox.bean.lottery.lotteryenum.LotteryPlayEnum;
import com.dawoo.lotterybox.view.activity.team.base.OnMultiClickListener;
import com.dawoo.lotterybox.view.fragment.pk10_bet_room.BasePk10Fragment;
import com.dawoo.lotterybox.view.fragment.pk10_bet_room.Pk10CattleFragment;
import com.hwangjr.rxbus.RxBus;
import com.hwangjr.rxbus.annotation.Subscribe;
import com.hwangjr.rxbus.annotation.Tag;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;


/**
 * @author alex
 * PK10牛牛玩法
 */
public class PK10CattleActivity extends BasePk10BetRoomActivity {

    private PopupWindow headPop;
    private Pk10CattleFragment pk10CattleFragment;

    @Override
    protected void initViews() {
        super.initViews();
        //pk牛牛平倍双倍
        View inflate = LayoutInflater.from(this).inflate(R.layout.view_pk10_multiple, null);
        TextView tvPkNNFalat = inflate.findViewById(R.id.tv_pk_nn_flat);
        TextView tvPkNNDouble = inflate.findViewById(R.id.tv_pk_nn_double);
        titleName.setText(tvPkNNFalat.getText().toString());
        Drawable drawableup = getResources().getDrawable(R.mipmap.ic_up_white);
        Drawable drawabledown = getResources().getDrawable(R.mipmap.ic_down_white);
        drawableup.setBounds(0, 0, drawableup.getMinimumWidth(), drawableup.getMinimumHeight());
        titleName.setCompoundDrawables(null, null, drawableup, null);
        tvPkNNFalat.setOnClickListener(new OnMultiClickListener() {
            @Override
            public void onMultiClick(View v) {
                tvPkNNFalat.setTextColor(getResources().getColor(R.color.colorPrimary));
                tvPkNNDouble.setTextColor(getResources().getColor(R.color.color_gray_333333));
                titleName.setText(tvPkNNFalat.getText().toString());
                pk10CattleFragment.setPlayCode(LotteryPlayEnum.NN_LEVEL.getCode());
                //要在setplaycode 之后调用
                getOtherPlayerData();
                headPop.dismiss();
            }
        });

        tvPkNNDouble.setOnClickListener(new OnMultiClickListener() {
            @Override
            public void onMultiClick(View v) {
                tvPkNNDouble.setTextColor(getResources().getColor(R.color.colorPrimary));
                tvPkNNFalat.setTextColor(getResources().getColor(R.color.color_gray_333333));
                titleName.setText(tvPkNNDouble.getText().toString());
                pk10CattleFragment.setPlayCode(LotteryPlayEnum.NN_MULTIPLE.getCode());
                getOtherPlayerData();
                headPop.dismiss();
            }
        });

        headPop = new PopupWindow();
        headPop.setContentView(inflate);
        headPop.setWidth(WindowManager.LayoutParams.MATCH_PARENT);
        headPop.setHeight(WindowManager.LayoutParams.WRAP_CONTENT);
        headPop.setFocusable(true);
        headPop.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        headPop.setOnDismissListener(() -> {
            drawableup.setBounds(0, 0, drawableup.getMinimumWidth(), drawableup.getMinimumHeight());
            titleName.setCompoundDrawables(null, null, drawableup, null);
        });
        titleName.setOnClickListener(new OnMultiClickListener() {
            @Override
            public void onMultiClick(View v) {
                drawabledown.setBounds(0, 0, drawabledown.getMinimumWidth(), drawabledown.getMinimumHeight());
                titleName.setCompoundDrawables(null, null, drawabledown, null);
                headPop.showAsDropDown(rlTop);
            }
        });
    }

    @Override
    public BasePk10Fragment setBody() {
        pk10CattleFragment = new Pk10CattleFragment();
        return pk10CattleFragment;
    }

    @Override
    public View setComfireDialogBodyHead() {
        return LayoutInflater.from(this).inflate(R.layout.item_pk_cattle_commit_bet, null);
    }

    @Override
    public BaseQuickAdapter setComfireDialogAdapter() {
        return new Pk10CattleCommitBetAdapter();
    }

    class Pk10CattleCommitBetAdapter extends BaseQuickAdapter<Pk10BetOderBean.BetOrdersBean, Pk10CattleCommitBetAdapter.ViewHolder> {
        final String x1 = LotteryPlayEnum.NN_XIAN_YI.getCode();
        final String x2 = LotteryPlayEnum.NN_XIAN_ER.getCode();
        final String x3 = LotteryPlayEnum.NN_XIAN_SAN.getCode();
        final String x4 = LotteryPlayEnum.NN_XIAN_SI.getCode();
        final String x5 = LotteryPlayEnum.NN_XIAN_WU.getCode();

        public Pk10CattleCommitBetAdapter() {
            super(R.layout.item_pk_cattle_commit_bet);
        }

        @Override
        protected void convert(ViewHolder helper, Pk10BetOderBean.BetOrdersBean item) {
            String contentHead = "";
            String contentTail = "";
            if (x1.equals(item.getBetNum())) {
                contentHead = item.getFreezAmount() != 0 ? "翻倍" : "平倍";
                contentTail = "闲一";
            }
            if (x2.equals(item.getBetNum())) {
                contentHead = item.getFreezAmount() != 0 ? "翻倍" : "平倍";
                contentTail = "闲二";
            }
            if (x3.equals(item.getBetNum())) {
                contentHead = item.getFreezAmount() != 0 ? "翻倍" : "平倍";
                contentTail = "闲三";
            }
            if (x4.equals(item.getBetNum())) {
                contentHead = item.getFreezAmount() != 0 ? "翻倍" : "平倍";
                contentTail = "闲四";
            }
            if (x5.equals(item.getBetNum())) {
                contentHead = item.getFreezAmount() != 0 ? "翻倍" : "平倍";
                contentTail = "闲五";
            }

            helper.tvBetContent.setText(String.valueOf(contentHead + " " + contentTail));
            helper.tvBetRate.setText("2-6");
            helper.tvBetSetting.setText("删除");
            helper.tvBetBalance.setText(String.valueOf(item.getBetAmount()));
            helper.tvBetBalance.setTextColor(mContext.getResources().getColor(R.color.colorPrimary));
            helper.tvBetFrezzNumber.setText(String.valueOf(item.getFreezAmount()));
            helper.tvBetFrezzNumber.setTextColor(mContext.getResources().getColor(R.color.pk_yellow_bjl));
            helper.tvBetSetting.setTextColor(mContext.getResources().getColor(R.color.colorPrimary));
            helper.tvBetSetting.setOnClickListener(new OnMultiClickListener() {
                @Override
                public void onMultiClick(View v) {
                    //删除
                    remove(helper.getPosition());
                    pk10CattleFragment.clearSingleViewState(helper.getPosition());
                }
            });
        }

        class ViewHolder extends BaseViewHolder {
            @BindView(R.id.tv_bet_content)
            TextView tvBetContent;
            @BindView(R.id.tv_bet_rate)
            TextView tvBetRate;
            @BindView(R.id.tv_bet_balance)
            TextView tvBetBalance;
            @BindView(R.id.tv_bet_frezz_number)
            TextView tvBetFrezzNumber;
            @BindView(R.id.tv_bet_setting)
            TextView tvBetSetting;

            public ViewHolder(View view) {
                super(view);
                ButterKnife.bind(this, view);
            }
        }


    }


}
