package com.dawoo.lotterybox.util;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * @author alex
 */
public class HttpStateBroadCastReceiver extends BroadcastReceiver {
    public static final String ACTION="com.dawoo.lotterybox.util.HttpStateBroadCastReceiver";
    @Override
    public void onReceive(Context context, Intent intent) {
        onReturn(intent.getIntExtra("state",0));
    }
    public void onReturn(int state){

    }
}
