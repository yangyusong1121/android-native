package com.dawoo.lotterybox.view.activity.lottery.pk10;

import android.animation.AnimatorSet;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.blankj.utilcode.util.ActivityUtils;
import com.blankj.utilcode.util.NetworkUtils;
import com.blankj.utilcode.util.ToastUtils;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.dawoo.coretool.util.LogUtils;
import com.dawoo.coretool.util.activity.DensityUtil;
import com.dawoo.coretool.util.date.DateTool;
import com.dawoo.lotterybox.BoxApplication;
import com.dawoo.lotterybox.ConstantValue;
import com.dawoo.lotterybox.R;
import com.dawoo.lotterybox.bean.BetMessageBean;
import com.dawoo.lotterybox.bean.DataCenter;
import com.dawoo.lotterybox.bean.lottery.BaseHandicap;
import com.dawoo.lotterybox.bean.lottery.Handicap;
import com.dawoo.lotterybox.bean.lottery.LotteryOddBean;
import com.dawoo.lotterybox.bean.lottery.OrderInfo;
import com.dawoo.lotterybox.bean.lottery.SaveOrderResult;
import com.dawoo.lotterybox.bean.lottery.lotteryenum.LotteryPlayEnum;
import com.dawoo.lotterybox.bean.record.NoteRecordHisData;
import com.dawoo.lotterybox.mvp.presenter.BaseLotteryPresenter;
import com.dawoo.lotterybox.mvp.presenter.LotteryPresenter;
import com.dawoo.lotterybox.mvp.presenter.OrderInfoPresenter;
import com.dawoo.lotterybox.mvp.view.IBaseLotteryView;
import com.dawoo.lotterybox.mvp.view.IOrderView;
import com.dawoo.lotterybox.util.GsonUtil;
import com.dawoo.lotterybox.util.NetUtil;
import com.dawoo.lotterybox.util.SingleToast;
import com.dawoo.lotterybox.util.anim.LotteryBAnimSetUtil;
import com.dawoo.lotterybox.util.lottery.LotteryUtil;
import com.dawoo.lotterybox.view.activity.LoginActivity;
import com.dawoo.lotterybox.view.activity.account.deposit.PayParentActivity;
import com.dawoo.lotterybox.view.activity.team.base.OnMultiClickListener;
import com.dawoo.lotterybox.view.activity.team.base.SuperBaseActivity;
import com.dawoo.lotterybox.view.fragment.pk10_bet_room.BasePk10Fragment;
import com.dawoo.lotterybox.view.view.CountDownTimerUtils;
import com.dawoo.lotterybox.view.view.MeasureAllGridView;
import com.dawoo.lotterybox.view.view.RequestTouchTextView;
import com.dawoo.lotterybox.view.view.TimeTextView;
import com.dawoo.lotterybox.view.view.dialog.MyOrderResultDialog;
import com.dawoo.lotterybox.view.view.dialog.NNOpenCodeDialog;
import com.dawoo.lotterybox.view.view.dialog.PlayerOrderListDialog;
import com.dawoo.lotterybox.view.view.dialog.RoomCommitBetDialog;
import com.dawoo.lotterybox.view.view.sortcar.SortCarSurfaceView;
import com.example.pushsdk.callback.ReceiveMessageListener;
import com.example.pushsdk.client.WebSocketClient;
import com.google.common.base.Objects;
import com.google.gson.Gson;
import com.hwangjr.rxbus.RxBus;
import com.hwangjr.rxbus.annotation.Subscribe;
import com.hwangjr.rxbus.annotation.Tag;
import com.ufreedom.uikit.FloatingText;
import com.zhy.http.okhttp.OkHttpUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import butterknife.BindView;

/**
 * @author alex
 * pk十玩法基类抽取
 */
public abstract class BasePk10BetRoomActivity extends SuperBaseActivity implements IBaseLotteryView, ReceiveMessageListener, IOrderView {

    protected long OPEN_DELATED = 10000;//开奖延迟 默认10s  具体可由子类再改
    @BindView(R.id.rl_top)
    protected RelativeLayout rlTop;
    @BindView(R.id.v_top_child)
    protected View vTopChild;
    @BindView(R.id.v_top)
    protected LinearLayout vTop;
    @BindView(R.id.left_btn)
    protected FrameLayout leftBtn;
    @BindView(R.id.title_name)
    protected TextView titleName;
    @BindView(R.id.tv_bet_result_and_play_rule)
    protected TextView tvBetResultAndPlayRule;
    @BindView(R.id.fl_right_click)
    protected FrameLayout flRightClick;
    @BindView(R.id.tv_periods)
    protected TextView tvPeriods;
    @BindView(R.id.carView)
    protected SortCarSurfaceView carView;
    @BindView(R.id.tv_xdh)
    protected TextView tvXdh;
    @BindView(R.id.ll_nums)
    protected RelativeLayout llNums;
    @BindView(R.id.tv_now_stage)
    protected TextView tvNowStage;
    @BindView(R.id.tv_now_stage_state)
    protected TextView tvNowStageState;
    @BindView(R.id.sm_timer)
    protected TimeTextView smTimer;
    @BindView(R.id.llt_countdown)
    protected RelativeLayout lltCountdown;
    @BindView(R.id.view2)
    protected View view2;
    @BindView(R.id.fl_content_body)
    protected FrameLayout flContentBody;
    @BindView(R.id.iv_my_bet)
    protected ImageView ivMyBet;
    @BindView(R.id.iv_member_room)
    protected ImageView ivMemberRoom;
    @BindView(R.id.et_bill)
    protected EditText etBill;
    @BindView(R.id.tv_commit)
    protected TextView tvCommit;
    @BindView(R.id.tv_reset)
    protected TextView tvReset;
    @BindView(R.id.ll_deposit)
    protected LinearLayout llDeposit;
    @BindView(R.id.iv_bet5)
    protected ImageView ivBet5;
    @BindView(R.id.iv_bet50)
    protected ImageView ivBet50;
    @BindView(R.id.iv_bet200)
    protected ImageView ivBet200;
    @BindView(R.id.iv_bet500)
    protected ImageView ivBet500;
    @BindView(R.id.iv_bet2000)
    protected ImageView ivBet2000;
    @BindView(R.id.iv_bet5000)
    protected ImageView ivBet5000;
    @BindView(R.id.ll_bet_bottom)
    protected LinearLayout llBetBottom;
    protected BasePk10Fragment mFragment;
    @BindView(R.id.iv_betting)
    ImageView ivBetting;
    @BindView(R.id.fendan_tv)
    RequestTouchTextView fendanTv;
    @BindView(R.id.ll_stop_sale)
    LinearLayout llStopSale;
    private BaseLotteryPresenter<BasePk10BetRoomActivity> lotteryPresenter;
    boolean isNotLotteryWait = false; //处理某些彩种没有封盘的情况

    protected CountDownTimerUtils mCDTimerUtils;
    //倒计时期间回调
    //倒计时期间回调/覆盖父类的分秒制
    CountDownTimerUtils.TickDelegate mTickDelegate;
    //距离开盘时间 倒计时结束回调
    //距离开盘时间 倒计时结束回调
    CountDownTimerUtils.FinishDelegate mLeftOpenTimeFinishDelegate;

    //距离封盘时间 倒计时结束回调
    CountDownTimerUtils.FinishDelegate mLeftTimeFinishDelegate;

    private AnimatorSet mAnimSetPeriods = new AnimatorSet();//期数动画
    private AnimatorSet mAnimSetPeriodsNext = new AnimatorSet();//下一期期数动画
    private AnimatorSet mAnimSetXh = new AnimatorSet();//形態动画
    private AnimatorSet mAnimSetNums = new AnimatorSet();//号码动画
    private AnimatorSet mAnimSetStatus = new AnimatorSet();//盘口状态动画
    private AnimatorSet mAnimSetTime = new AnimatorSet();//时间
    //当前的期号
    public String mCurrentExpect;
    public String ltType;
    NNOpenCodeDialog nnOpenCodeDialog;
    private List<Handicap> mHandicapList = new ArrayList<>();
    private String betNumber = "";
    public String ltCode;
    MyOrderResultDialog myOrderResultDialog;

    private OrderInfoPresenter orderInfoPresenter;
    private final String today = DateTool.getTimeFromLong(DateTool.FMT_DATE, System.currentTimeMillis());
    protected Handler mHandler = new Handler();
    public PlayerOrderListDialog playerOrderListDialog;
    public RoomCommitBetDialog roomCommitBetDialog;

    @Override
    protected void createLayoutView() {
        setContentView(R.layout.activity_pk10_cattle);
    }

    /**
     * 界面的主体
     *
     * @return 返回fragment
     */
    public abstract BasePk10Fragment setBody();

    public abstract View setComfireDialogBodyHead();

    public abstract BaseQuickAdapter setComfireDialogAdapter();

    @Override
    protected void initViews() {
        RxBus.get().register(this);
        ltType = getIntent().getStringExtra(ConstantValue.LT_TYPE);
        carView.setVisibility(View.GONE);
        titleName.setText(getIntent().getStringExtra(ConstantValue.LT_NAME));
        carView.setRandPlay();
        mFragment = setBody();
        setBetRoomBody(mFragment);
        initClickListener();
        initDialog();

    }

    @Override
    protected void initData() {
        super.initData();
        ltCode = getIntent().getStringExtra(ConstantValue.LT_CODE);
        mCDTimerUtils = CountDownTimerUtils.getCountDownTimer();
        //设置timer回调
        initTimmerCallBack();
        //获取界面数据
        lotteryPresenter = new LotteryPresenter<>(this, this, ltCode);
        lotteryPresenter.getResultByCode();
        lotteryPresenter.getLotteryExpect();
        WebSocketClient.getInstance().setReceiveMessageLister(this);
        WebSocketClient.getInstance().login(DataCenter.getInstance().getHsot()
                , DataCenter.getInstance().getSysInfo().getSid(), ConstantValue.LOTTERY_BETORDER, DataCenter.getInstance().getDomain(), OkHttpUtils.getInstance().getOkHttpClient());

        orderInfoPresenter = new OrderInfoPresenter(this, this);
    }

    @Override
    protected void errorRetry() {
        super.errorRetry();
        lotteryPresenter.getResultByCode();
        lotteryPresenter.getLotteryExpect();
        WebSocketClient.getInstance().setReceiveMessageLister(this);
        WebSocketClient.getInstance().login(DataCenter.getInstance().getHsot()
                , DataCenter.getInstance().getSysInfo().getSid(), ConstantValue.LOTTERY_BETORDER, DataCenter.getInstance().getDomain(), OkHttpUtils.getInstance().getOkHttpClient());
    }

    protected void setBetRoomBody(Fragment fragment) {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.fl_content_body, fragment)
                .commit();
    }

    private void initTimmerCallBack() {
        mTickDelegate = pMillisUntilFinished -> {
            smTimer.setText(DateTool.convert2String(pMillisUntilFinished));
        };

        mLeftOpenTimeFinishDelegate = () -> {
            smTimer.setText("00:00");
            carView.setFenDanUI();
            lotteryPresenter.getLotteryExpect();
            lotteryPresenter.getRecentCloseExpect();
            if (fendanTv.getText().equals("封单中")) {
                llStopSale.setVisibility(View.VISIBLE);
            }
        };

        mLeftTimeFinishDelegate = () -> {
            smTimer.setText("00:00");
            carView.setFenDanUI();
            lotteryPresenter.getLotteryExpect();
            lotteryPresenter.getRecentCloseExpect();
            if (fendanTv.getText().equals("封单中")) {
                llStopSale.setVisibility(View.GONE);
            }
        };
    }

    private void initClickListener() {
        betWeigthClick(ivBet5, 5);
        betWeigthClick(ivBet50, 50);
        betWeigthClick(ivBet200, 200);
        betWeigthClick(ivBet500, 500);
        betWeigthClick(ivBet2000, 2000);
        betWeigthClick(ivBet5000, 5000);


        leftBtn.setOnClickListener(v -> finish());

        llDeposit.setOnClickListener(v -> ActivityUtils.startActivity(DataCenter.getInstance().isLogin() ? PayParentActivity.class : LoginActivity.class));

        tvReset.setOnClickListener(v -> {
            //点击重置
            etBill.setText("");
            etBill.setSelection(etBill.getText().length());
        });

        flRightClick.setOnClickListener(v -> {
            //开奖结果游戏数据点击
            nnOpenCodeDialog.show();
        });

        ivMyBet.setOnClickListener(v -> {
            //我的投注记录点击
            if (!DataCenter.getInstance().isLogin()) {
                ActivityUtils.startActivity(LoginActivity.class);
            } else {
                orderInfoPresenter.getRecords(ltCode, today);
                myOrderResultDialog.show();
            }
        });

        ivMemberRoom.setOnClickListener(v -> {
            //该局游戏的玩家
            playerOrderListDialog.show();

        });
        tvCommit.setOnClickListener(new OnMultiClickListener() {
            @Override
            public void onMultiClick(View v) {
                betNumber = etBill.getText().toString().trim();
                if (!DataCenter.getInstance().isLogin()) {
                    ActivityUtils.startActivity(LoginActivity.class);
                    return;
                }
                if (Objects.equal("", betNumber)) {
                    ToastUtils.showShort("投注金额为空");
                    return;
                }
                if (Double.valueOf(betNumber) <= 0) {
                    ToastUtils.showShort("投注金额不能为零");
                    return;
                }
                if (!mFragment.hasSelected()) {
                    return;
                }
                //钱不够
                if (Double.valueOf(betNumber) > Double.valueOf(DataCenter.getInstance().getUser().getBalance().replaceAll(",", ""))) {
                    ToastUtils.showShort("可用金额不足");
                    return;
                }
                if (!mFragment.isCanBet(Double.valueOf(betNumber))) {
                    return;
                }
                //显示一个dialog 让用户最终选择

                //投注 获取新的token
                roomCommitBetDialog.showDialog(mCurrentExpect, mFragment.processDataBeforeBet(Double.valueOf(betNumber)),
                        mFragment.processTotalBeforeBet(mFragment.processDataBeforeBet(Double.valueOf(betNumber))));

            }
        });
    }


    /**
     * 底部砝码的点击事件
     */
    private void betWeigthClick(ImageView ivBetWeigth, int weigthNumber) {
        ivBetWeigth.setOnClickListener(v -> {
            String number = etBill.getText().toString().trim();
            Double aDouble = Double.valueOf("".equals(number) ? "0" : number);
            aDouble = aDouble + weigthNumber;
            etBill.setText(String.valueOf(aDouble));
            etBill.setSelection(etBill.getText().length());
            floatTextInfo(etBill, "+" + weigthNumber);
        });
    }

    private void floatTextInfo(EditText et, String info) {
        FloatingText floatingText = new FloatingText.FloatingTextBuilder(BasePk10BetRoomActivity.this)
                .textColor(getResources().getColor(R.color.colorPrimary))
                .textSize(40)
                .textContent(info)
                .build();

        floatingText.attach2Window();
        floatingText.startFloating(et);
    }


    /**
     * 以下是接口的回调
     */

    @Override
    public void onResultByCode(List<Handicap> handicapList) {
        errorRetryResult();
        if (handicapList != null && handicapList.size() != 0) {
            mFragment.onLastDataForResult(handicapList.get(0));
            LotteryBAnimSetUtil.doPeriodTextViewAnim(mAnimSetPeriods, tvPeriods, DensityUtil.dp2px(this, 30));
            LotteryBAnimSetUtil.doXhAnim(mAnimSetXh, tvXdh, DensityUtil.dp2px(this, 30));
            LotteryBAnimSetUtil.doNumsAnim(mAnimSetNums, llNums, DensityUtil.dp2px(this, 500));
            mHandicapList = handicapList;
            nnOpenCodeDialog.setmHandicaps(handicapList);
            lotteryPresenter.getRecentCloseExpect();
        }

    }

    boolean isFirstOpenLottery = true; //第一次进入

    @Override
    public void onRecentCloseExpect(Handicap handicap) {
        if (handicap == null) {
            mHandler.postDelayed(mOpenLotteryRunnable, OPEN_DELATED);
            return;
        }
        //上游activity处理
        if (!TextUtils.isEmpty(handicap.getOpenCode())) {
            tvPeriods.setText(getString(R.string.which_periods, handicap.getExpect()));
            stopAnim(handicap.getOpenCode());
            tvXdh.setText(LotteryUtil.getPK10_A(handicap.getOpenCode()));
            if (mHandicapList != null && mHandicapList.size() - 1 > 0) {
                if (!handicap.getExpect().equals(mHandicapList.get(0).getExpect())) {
                    // mHandicapList.remove(mHandicapList.size() - 1);
                    mHandicapList.add(0, handicap);
                    nnOpenCodeDialog.setmHandicaps(mHandicapList);
                }
            }
            //下游子类处理
            mFragment.onRecentCloseExpect(handicap);
        } else {
            tvPeriods.setText(getString(R.string.which_periods, handicap.getExpect() + ""));
            carView.setRandPlay();
            tvXdh.setVisibility(View.GONE);
            mHandler.postDelayed(mOpenLotteryRunnable, OPEN_DELATED);
        }
        isFirstOpenLottery = false;
    }


    @Override
    public void onLotteryExpect(BaseHandicap baseHandicap) {
        errorRetryResult();
        carView.setVisibility(NetworkUtils.isConnected() ? View.VISIBLE : View.GONE);
        mFragment.resetViewState();
        doHandicap(baseHandicap);
    }

    @Override
    public void onLotteryOdd(Map<String, LotteryOddBean> o) {

    }

    @Override
    public void onLtToken(String token) {
        //计算投注单数
        String json = new Gson().toJson(mFragment.processDataBeforeRequestBet(roomCommitBetDialog.getData()));
        lotteryPresenter.saveBetOrder(token, json);
    }

    @Override
    public void onSaveBetOrder(SaveOrderResult saveOrderResult) {
        if (saveOrderResult == null) {
            ToastUtils.showShort("与服务器失去链接，请稍后重试");
            return;
        }
        if (saveOrderResult.getError() == 0) {
            mFragment.whenAfterBet(saveOrderResult, Double.valueOf(betNumber));
            roomCommitBetDialog.getData().clear();
        } else {
            roomCommitBetDialog.getData().clear();
            ToastUtils.showShort(saveOrderResult.getMessage() + "");
        }
        clearSelectView();
    }

    @Override
    public void onSureBetOrder() {

    }


    @Override
    public void onOrderResult(OrderInfo o) {

    }

    /**
     * 获取当期玩家列表和投注信息
     *
     * @param o
     */
    @Override
    public void onCustomers(Object o) {
        if (o != null) {
            mFragment.onOtherPlayerDataResult(o);
        }
    }

    @Override
    public void onRecords(NoteRecordHisData hisData) {
        if (hisData != null && hisData.getData() != null) {
            if (myOrderResultDialog == null) {
                myOrderResultDialog = new MyOrderResultDialog(this, ltType);
            }
            myOrderResultDialog.setmDatas(hisData.getData());
        }
    }


    void doHandicap(BaseHandicap baseHandicap) {
        if (baseHandicap != null) {
            if (baseHandicap.getStatus().equalsIgnoreCase(ConstantValue.NORMAL)) {
                fendanTv.setText("封单中");
                llStopSale.setVisibility(View.GONE);
            } else if (baseHandicap.getStatus().equalsIgnoreCase(ConstantValue.MAINTAIN)) {
                fendanTv.setText("维护中");
                llStopSale.setVisibility(View.VISIBLE);
            } else if (baseHandicap.getStatus().equalsIgnoreCase(ConstantValue.DISABLE)) {
                fendanTv.setText("已下架");
                llStopSale.setVisibility(View.VISIBLE);
            } else if (baseHandicap.getStatus().equalsIgnoreCase(ConstantValue.CLOSE)) {
                fendanTv.setText("停市");
                llStopSale.setVisibility(View.VISIBLE);
            }


            if (baseHandicap.getLeftOpenTime() == 0 && baseHandicap.getLeftTime() == 0) {
                SingleToast.showMsg("盘口数据获取失败");
                return;
            }

            mCurrentExpect = baseHandicap.getExpect();
            if (!tvNowStage.getText().toString().contains(mCurrentExpect) && baseHandicap.getStatus().equalsIgnoreCase(ConstantValue.NORMAL)) {
                //获取当前房间，当期的注单数据
                getOtherPlayerData();
            }

            tvNowStage.setText(getString(R.string.which_periods, baseHandicap.getExpect()) + "截止时间");
            // 设置封单倒计时
            if (baseHandicap.getLeftOpenTime() > 0) {
                mCDTimerUtils.cancel();
                mCDTimerUtils.setMillisInFuture(baseHandicap.getLeftOpenTime() * 1000)
                        .setCountDownInterval(1000)
                        .setTickDelegate(mTickDelegate)
                        .setFinishDelegate(mLeftOpenTimeFinishDelegate)
                        .start();

                LotteryBAnimSetUtil.doTimeAnim(mAnimSetTime, smTimer, DensityUtil.dp2px(this, 50));
                tvNowStageState.setText("封单中");
                llStopSale.setVisibility(View.VISIBLE);
                isNotLotteryWait = false;
                tvXdh.setText("");
            } else {
                // 设置投注截止倒计时
                mCDTimerUtils.cancel();
                mCDTimerUtils.setMillisInFuture((baseHandicap.getLeftTime() + 1) * 1000)
                        .setCountDownInterval(1000)
                        .setTickDelegate(mTickDelegate)
                        .setFinishDelegate(mLeftTimeFinishDelegate)
                        .start();
                LotteryBAnimSetUtil.doTimeAnim(mAnimSetTime, smTimer, DensityUtil.dp2px(this, 50));

                tvNowStageState.setText(R.string.stop);
                if (isNotLotteryWait) {
                    tvXdh.setText("");
                    carView.setRandPlay();
                    tvXdh.setVisibility(View.GONE);
                }
                isNotLotteryWait = true;
            }
        }
    }

    public void getOtherPlayerData() {
        //获取人数
        orderInfoPresenter.getCustomers(mCurrentExpect, ltCode);
        //获取投注的金额
    }

    /**
     * 数据回调
     *
     * @param json
     */
    @Override
    public void onReceiveJson(String json) {
        LogUtils.e("reciver:" + json);
        try {
            List<BetMessageBean> messageBeans = GsonUtil.jsonToList(json, BetMessageBean.class);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 初始化弹框
     */
    private void initDialog() {
        nnOpenCodeDialog = new NNOpenCodeDialog(this, ltType);
        myOrderResultDialog = new MyOrderResultDialog(this, ltType);
        playerOrderListDialog = new PlayerOrderListDialog(this);
        roomCommitBetDialog = new RoomCommitBetDialog(this, new RoomCommitBetDialog.ComfirmDialogCallBack() {
            @Override
            public View setDialogBodyHead() {
                return setComfireDialogBodyHead();
            }

            @Override
            public BaseQuickAdapter setAdapter() {
                return setComfireDialogAdapter();
            }

            @Override
            public void onDialogCommitBet(List<Object> objects) {
                //需要把具体确切的位置返回出去
                mFragment.processViewBeforeBet(objects);
                lotteryPresenter.getLtToken();
            }

            @Override
            public void onDialogContinueBet(List<Object> objects) {
                clearSelectView();
            }

            @Override
            public void onDialogCancleBet() {
                clearSelectView();
            }
        });
    }

    private void clearSelectView() {
        for (int i = 0; i < mFragment.addLayout().size(); i++) {
            if (mFragment.addLayout().get(i).getBackground() != null) {
                mFragment.addLayout().get(i).setBackground(null);
                mFragment.addLayout().get(i).setSelected(false);

            }
        }
    }

    @Override
    protected void onDestroy() {
        WebSocketClient.getInstance().logout();
        mCDTimerUtils.cancel();
        lotteryPresenter.onDestory();
        orderInfoPresenter.onDestory();
        RxBus.get().unregister(this);
        super.onDestroy();

    }

    private void stopAnim(String string) {
        if (TextUtils.isEmpty(string)) return;
        String[] numbers = string.split(",");
        ArrayList<Integer> nums = new ArrayList<>();
        for (int i = 0; i < numbers.length; i++) {
            nums.add(Integer.valueOf(numbers[i]));
        }
        carView.setResultNoPlay(nums);
    }

    @Subscribe(tags = {@Tag(ConstantValue.EVENT_TYPE_NETWORK_EXCEPTION)})
    public void shrinkRefreshView(String error) {
        ToastUtils.showShort(error);
        lotteryPresenter.getResultByCode();
        lotteryPresenter.getLotteryExpect();

    }

    //延时开奖 runnable
    protected OpenLotteryRunnable mOpenLotteryRunnable = new OpenLotteryRunnable();

    /**
     * 延时开奖
     */
    private class OpenLotteryRunnable implements Runnable {
        @Override
        public void run() {
            if (!isDestroyed()) {

                lotteryPresenter.getRecentCloseExpect();
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (mCDTimerUtils != null && lotteryPresenter != null) {
            if (smTimer.getText().toString().equalsIgnoreCase("00:00:00")) {
                lotteryPresenter.getLotteryExpect();
            }
        }
    }
}
