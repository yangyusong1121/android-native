package com.dawoo.lotterybox.adapter;

import android.app.Activity;
import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v4.app.FragmentActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.dawoo.lotterybox.BoxApplication;
import com.dawoo.lotterybox.R;
import com.dawoo.lotterybox.bean.DataCenter;
import com.dawoo.lotterybox.bean.lottery.hall.LotteryBean;
import com.dawoo.lotterybox.util.NetUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by rain on 18-5-31.
 */

public class AllLotteryAdapter extends RecyclerView.Adapter<AllLotteryAdapter.TypeHolder> {
    private List<LotteryBean> mDatas = new ArrayList<>();
    private Context context;
    private OnItemClickLintener onItemClickLintener;
    private RequestOptions hallOptions;

    public List<LotteryBean> getmDatas() {
        return mDatas;
    }

    public void setOnItemClickLintener(OnItemClickLintener onItemClickLintener) {
        this.onItemClickLintener = onItemClickLintener;
    }

    public void setmDatas(List<LotteryBean> mDatas) {
        this.mDatas = mDatas;
        notifyDataSetChanged();
    }

    public AllLotteryAdapter(Context context) {
        this.context = context;
        if (context instanceof Activity) {
            hallOptions = ((BoxApplication) ((FragmentActivity) context).getApplication()).getHallOptions();
        }
    }

    @NonNull
    @Override
    public TypeHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (viewType == 0) {
            View rootView = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_lottery_type_layout, parent, false);
            return new TypeHolder(rootView);
        } else {
            View rootView = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_lottery_item_layout, parent, false);
            rootView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (onItemClickLintener != null) {
                        onItemClickLintener.onItemClickLinter((Integer) v.getTag());
                    }
                }
            });
            return new TypeHolder(rootView);
        }

    }

    @Override
    public void onBindViewHolder(@NonNull TypeHolder holder, int position) {
        holder.itemView.setTag(position);
        LotteryBean bean = mDatas.get(position);
        Glide.with(context).load(NetUtil.handleUrl(bean.getImageUrl())).apply(hallOptions).into(holder.iconIV);
        holder.nameTV.setText(bean.getName());
    }

    @Override
    public int getItemCount() {
        return mDatas.size();
    }

    @Override
    public void onAttachedToRecyclerView(RecyclerView recyclerView) {
        super.onAttachedToRecyclerView(recyclerView);

        RecyclerView.LayoutManager manager = recyclerView.getLayoutManager();
        if (manager instanceof GridLayoutManager) {
            final GridLayoutManager gridManager = ((GridLayoutManager) manager);
            gridManager.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
                @Override
                public int getSpanSize(int position) {
                    int type = getItemViewType(position);
                    switch (type) {
                        case 0:
                            return 4;
                        default:
                            return 1;
                    }
                }
            });
        }
    }

    @Override
    public int getItemViewType(int position) {
        if (mDatas.get(position).getModel().equalsIgnoreCase("-1")) {
            return 0;
        } else {
            return 1;
        }
    }

    class TypeHolder extends RecyclerView.ViewHolder {
        private TextView nameTV;
        private ImageView iconIV;

        public TypeHolder(View itemView) {
            super(itemView);
            nameTV = itemView.findViewById(R.id.name_tv);
            iconIV = itemView.findViewById(R.id.icon_iv);
        }
    }

    public interface OnItemClickLintener {
        void onItemClickLinter(int position);
    }
}
