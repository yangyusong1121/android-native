package com.dawoo.lotterybox.mvp.view;

/**
 * Created by alex on 18-5-1.
 */

public interface IOAMormalView extends IBaseView {
    void onNormalResult(Object o);
}
