package com.dawoo.lotterybox.mvp.model.withdraws;

import com.dawoo.lotterybox.bean.Bank;
import com.dawoo.lotterybox.bean.EasyHttpResult;
import com.dawoo.lotterybox.bean.MyBandCard;
import com.dawoo.lotterybox.bean.WithDrawBean;
import com.dawoo.lotterybox.bean.WithDrawsAduitBean;
import com.dawoo.lotterybox.bean.WithDrawsDetailBean;
import com.dawoo.lotterybox.bean.WithDrawsFeeBean;
import com.dawoo.lotterybox.mvp.model.BaseModel;
import com.dawoo.lotterybox.mvp.service.ISettingService;
import com.dawoo.lotterybox.mvp.service.IUserService;
import com.dawoo.lotterybox.mvp.service.IWithDrawsService;

import com.dawoo.lotterybox.net.BaseHttpResult;
import com.dawoo.lotterybox.net.RetrofitHelper;

import java.util.HashMap;
import java.util.List;

import io.reactivex.Observable;
import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;

/**
 * Created by alex on 18-4-5.
 *
 * @author alex
 */

public class WithDrawsModel extends BaseModel implements IWithDrawsModel {

    /**
     * 我的银行卡
     */
    @Override
    public Disposable bankcardList(Observer Observer) {
        Observable<List<MyBandCard>> observable = RetrofitHelper.getService(IWithDrawsService.class).bankcardList().map(new HttpResultFunc<>());
        return toSubscribe(observable, Observer);
    }

    /**
     * 可绑定的银行卡列表
     *
     * @param Observer
     * @return
     */
    @Override
    public Disposable getBanks(Observer Observer) {
        Observable<List<Bank>> observable = RetrofitHelper.getService(IWithDrawsService.class).getBanks().map(new HttpResultFunc<>());
        return toSubscribe(observable, Observer);
    }

    /**
     * 绑定银行卡
     *
     * @param Observer
     * @param bankCode
     * @param bankName
     * @param cardNumber
     * @param masterName
     * @return
     */
    @Override
    public Disposable bindBankCard(Observer Observer, String bankCode, String bankName, String cardNumber, String masterName) {
        Observable<BaseHttpResult> observable = RetrofitHelper.getService(IWithDrawsService.class).bindBankCard(bankCode, bankName, cardNumber, masterName);
        return toSubscribe(observable, Observer);
    }

    @Override
    public Disposable getWithDrawsFee(Observer Observer, String money) {
        Observable<WithDrawsFeeBean> observable = RetrofitHelper.getService(IWithDrawsService.class).getWithDrawsFee(money).map(new HttpResultFunc<>());
        return toSubscribe(observable, Observer);
    }

    @Override
    public Disposable withDrawsInit(Observer Observer) {
        Observable<WithDrawBean> observable = RetrofitHelper.getService(IWithDrawsService.class).withDrawsInit().map(new HttpResultFunc<>());
        return toSubscribe(observable, Observer);
    }

    @Override
    public Disposable withDrawsAudit(Observer Observer) {
        Observable<List<WithDrawsAduitBean>> observable = RetrofitHelper.getService(IWithDrawsService.class).getWithDrawsAudit().map(new HttpResultFunc<>());
        return toSubscribe(observable, Observer);
    }

    @Override
    public Disposable withDrawsAuditDetail(Observer Observer, String id) {
        Observable<WithDrawsDetailBean> observable = RetrofitHelper.getService(IWithDrawsService.class).getWithDrawsAuditDetail(id).map(new HttpResultFunc<>());
        return toSubscribe(observable, Observer);

    }

    @Override
    public Disposable applyWithDraws(Observer Observer, String withdrawAmount , String token) {
        Observable<EasyHttpResult> observable = RetrofitHelper.getService(IWithDrawsService.class).applyWithDraws(withdrawAmount,token);
        return toSubscribe(observable, Observer);
    }
}
