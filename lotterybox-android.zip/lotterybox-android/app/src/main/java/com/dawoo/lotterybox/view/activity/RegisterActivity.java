package com.dawoo.lotterybox.view.activity;


import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.blankj.utilcode.util.ActivityUtils;
import com.blankj.utilcode.util.SPUtils;
import com.blankj.utilcode.util.ToastUtils;
import com.dawoo.coretool.ToastUtil;
import com.dawoo.coretool.util.activity.KeyboardUtil;
import com.dawoo.lotterybox.ConstantValue;
import com.dawoo.lotterybox.R;
import com.dawoo.lotterybox.bean.CheckAccountBean;
import com.dawoo.lotterybox.bean.DataCenter;
import com.dawoo.lotterybox.bean.LoginBean;
import com.dawoo.lotterybox.bean.User;
import com.dawoo.lotterybox.mvp.presenter.UserPresenter;
import com.dawoo.lotterybox.mvp.view.ILoginView;
import com.dawoo.lotterybox.mvp.view.IRegisterView;
import com.dawoo.lotterybox.net.HttpResult;
import com.dawoo.lotterybox.util.SPConfig;
import com.dawoo.lotterybox.view.view.ClearEditText;
import com.dawoo.lotterybox.view.view.HeaderView;
import com.hwangjr.rxbus.RxBus;
import com.hwangjr.rxbus.annotation.Subscribe;
import com.hwangjr.rxbus.annotation.Tag;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * 注册
 * Created by benson on 17-12-27.
 */

public class RegisterActivity extends BaseActivity implements IRegisterView, ILoginView, TextWatcher {
    private static final String TAG = "RegisterActivity";
    @BindView(R.id.head_view)
    HeaderView mHeadView;
    @BindView(R.id.name_et)
    ClearEditText mNameEt;
    @BindView(R.id.pwd_lable_tv)
    TextView mPwdLableTv;
    @BindView(R.id.pwd_et)
    ClearEditText mPwdEt;
    @BindView(R.id.input_type_iv)
    ImageView mInputTypeIv;
    @BindView(R.id.confirm_pwd_lable_tv)
    TextView mConfirmPwdLableTv;
    @BindView(R.id.confirm_pwd_et)
    ClearEditText mConfirmPwdEt;
    @BindView(R.id.confirm_yqm_et)
    ClearEditText mConfirmYqmEt;
    @BindView(R.id.confirm_input_type_iv)
    ImageView mConfirmInputTypeIv;
    @BindView(R.id.up_ll)
    LinearLayout mUpLl;
    @BindView(R.id.login_btn)
    Button mLoginBtn;
    @BindView(R.id.protocal_tv)
    TextView mProtocalTv;
    @BindView(R.id.protocal_ll)
    LinearLayout mProtocalLl;
    private UserPresenter mPresenter;
    public static final String MODE = "TYPE_MODE";
    public static final String MODE_STANDAR = "1";
    public static final String MODE_DEMO = "2";

    private String name, pwd, repwd, yqm;


    @Override
    protected void createLayoutView() {
        setContentView(R.layout.acitivity_register);
    }

    @Override
    protected void onDestroy() {
        mPresenter.onDestory();
        super.onDestroy();
    }

    @Override
    protected void initViews() {
        mHeadView.setHeader(getString(R.string.title_name_activity_register), true);
        mPresenter = new UserPresenter<>(this, this);
//        checkInput(mNameEt.getText().toString(), mPwdEt.getText().toString(), mConfirmPwdEt.getText().toString(), mConfirmYqmEt.getText().toString());
        mLoginBtn.setEnabled(false);
        mNameEt.addTextChangedListener(this);
        mPwdEt.addTextChangedListener(this);
        mConfirmPwdEt.addTextChangedListener(this);
        mConfirmYqmEt.addTextChangedListener(this);
    }

    @Override
    protected void initData() {

    }

    @OnClick({R.id.input_type_iv, R.id.confirm_input_type_iv, R.id.login_btn, R.id.protocal_ll})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.input_type_iv:
                doPwdToggle();
                break;
            case R.id.confirm_input_type_iv:
                doConPwdToggle();
                break;
            case R.id.login_btn:
                Log.d(TAG, "onViewClicked: register");
                doRigster();
                break;
            case R.id.protocal_ll:
                ToastUtil.showToastShort(this, "功能待续");
                break;
            default:
        }
    }

    @Override
    public void onRigsterResult(boolean isSuccess) {
        if (isSuccess) {
            ToastUtil.showResShort(this, R.string.register_success);
            //自动登录
            KeyboardUtil.hideInputKeyboard(this);
            doLogin();
        }
    }

    @Override
    public void doRigster() {
        String name = mNameEt.getText().toString().trim();
        String pwd = mPwdEt.getText().toString().trim();
        String confirmPwd = mConfirmPwdEt.getText().toString().trim();
        String promoCode = mConfirmYqmEt.getText().toString().trim();
        String reateChannel = "4";
        String playerType = "member";

        String mode = getIntent().getStringExtra(MODE);

        if (TextUtils.isEmpty(mode)) {
            mode = "1";//账号模式：1-正式，2-演示
        }

        mLoginBtn.setEnabled(mPresenter.validate(name, pwd, confirmPwd) ? true : false);
        mPresenter.register(name, pwd, confirmPwd, reateChannel, playerType, mode, promoCode);
    }

    @Override
    public void onLoginResult(LoginBean loginBean) {
        if (loginBean != null) {

            String name = mNameEt.getText().toString().trim();
            String pwd = mPwdEt.getText().toString().trim();
            SPUtils.getInstance().put(SPConfig.USERNAME, name);
            SPUtils.getInstance().put(SPConfig.PASSWORD, pwd);
            User user = new User();
            user.setUsername(name);
            user.setLogin(true);
            user.setToken(loginBean.getToken());
            user.setRefreshToken(loginBean.getRefreshToken());
            user.setExpire(loginBean.getExpire());
            user.setPassword(pwd);
            user.setAvatarUrl(mPresenter.getHeadIcon());
            DataCenter.getInstance().setUser(user);
            RxBus.get().post(ConstantValue.EVENT_TYPE_LOGINED, "login");
            mPresenter.getUserInfo(true);

        }
    }

    @Override
    public void doLogin() {
        String name = mNameEt.getText().toString().trim();
        String pwd = mPwdEt.getText().toString().trim();
        String appKey = getResources().getString(R.string.app_key);
        String appSecret = getResources().getString(R.string.app_secret);
        String serialNo = DataCenter.getInstance().getSysInfo().getMac();
        mPresenter.login(name, pwd, appKey, appSecret, serialNo, true);
    }

    @Override
    public void doPwdToggle() {
        if (mInputTypeIv.isSelected()) {
            mInputTypeIv.setSelected(false);
            mPwdEt.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        } else {
            mInputTypeIv.setSelected(true);
            mPwdEt.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_NORMAL);
        }

        KeyboardUtil.hideInputKeyboard(this);
    }

    @Override
    public void onGetUserInfo(User user) {
        if (user != null) {
            mPresenter.setUserWithoutToken(user);
            RxBus.get().post(ConstantValue.EVENT_TYPE_USER_INFO, "mcfragment_user_info");
            ActivityUtils.finishActivity(LoginActivity.class);
            finish();
        }

    }

    @Override
    public void checkName(CheckAccountBean bean) {

    }

    @Override
    public void onCheckReal(HttpResult httpResult) {

    }


    @Override
    public void doConPwdToggle() {
        if (mConfirmInputTypeIv.isSelected()) {
            mConfirmInputTypeIv.setSelected(false);
            mConfirmPwdEt.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        } else {
            mConfirmInputTypeIv.setSelected(true);
            mConfirmPwdEt.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_NORMAL);
        }
        KeyboardUtil.hideInputKeyboard(this);
    }

    String msg = "";

    @Subscribe(tags = @Tag(ConstantValue.EVENT_TYPE_NETWORK_EXCEPTION))
    public void onReturnError(String message) {
        if (msg.equals(message)) {
        } else {
            ToastUtils.showShort(message);
            msg = message;
        }
    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {
        name = mNameEt.getText().toString();
        pwd = mPwdEt.getText().toString();
        repwd = mConfirmPwdEt.getText().toString();
        yqm = mConfirmYqmEt.getText().toString();

        //禁止输入空格
        if (s.toString().contains(" ")) {
            String[] str = s.toString().split(" ");
            String str1 = "";
            for (int i = 0; i < str.length; i++) {
                str1 += str[i];
            }
            if (name.equals(s.toString())) {
                mNameEt.setText(str1);
                mNameEt.setSelection(start);
            } else if (pwd.equals(s.toString())) {
                mPwdEt.setText(str1);
                mPwdEt.setSelection(start);
            } else if (repwd.equals(s.toString())) {
                mConfirmPwdEt.setText(str1);
                mConfirmPwdEt.setSelection(start);
            } else if (yqm.equals(s.toString())) {
                mConfirmYqmEt.setText(str1);
                mConfirmYqmEt.setSelection(start);
            }
        }

        checkInput(name, pwd, repwd, yqm);

    }

    /**
     * 为空检测
     */
    private void checkInput(String name, String pwd, String repwd, String yqm) {
        if (TextUtils.isEmpty(name) || TextUtils.isEmpty(pwd) || TextUtils.isEmpty(repwd)) {
            mLoginBtn.setEnabled(false);
        } else {
            if (!TextUtils.isEmpty(yqm)) {
                if (yqm.length() == 6)
                    mLoginBtn.setEnabled(true);
                else
                    mLoginBtn.setEnabled(false);

            } else {
                mLoginBtn.setEnabled(true);
            }
        }
    }

    @Override
    public void afterTextChanged(Editable s) {

    }
}
