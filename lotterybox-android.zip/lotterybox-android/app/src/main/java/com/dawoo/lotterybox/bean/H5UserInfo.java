package com.dawoo.lotterybox.bean;

public class H5UserInfo {
    private String token;
    private String serialNo;
    public H5UserInfo(String token,String serialNo){
        this.token = token;
        this.serialNo = serialNo;
    }

    public String getSerialNo() {
        return serialNo;
    }

    public void setSerialNo(String serialNo) {
        this.serialNo = serialNo;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

}
