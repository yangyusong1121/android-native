package com.dawoo.lotterybox.util;


import android.support.annotation.NonNull;
import android.webkit.CookieManager;

import com.blankj.utilcode.util.LogUtils;
import com.bumptech.glide.load.model.GlideUrl;
import com.bumptech.glide.load.model.LazyHeaders;
import com.dawoo.lotterybox.bean.DataCenter;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import okhttp3.Response;

/**
 * Created by benson on 18-1-3.
 */

public class NetUtil {
    private static final String TAG = "NetUtil";

    public static GlideUrl handleUrl(String url) {
        String ip = DataCenter.getInstance().getHsot();
        // 是不是http开头
        // 第一个字符是不是包含反斜杠
        if (url == null) {
            return initWithHttp("");
        }

        LogUtils.e(TAG, "NetUtil url==" + url + "\n ip===" + ip);

        if (/*!url.contains("http") && !url.contains("www.")*/!isURL(url)) {

            if (url.indexOf("/") == 0) {
                return initWithHttp(ip + url);

            } else {
                return initWithHttp(ip + "/" + url);

            }


        } else {
            return initWithoutHttp(url);
        }
    }

    public static GlideUrl getImgHandlerUrl(String url) {
        String ip = DataCenter.getInstance().getImgDomain();
        // 是不是http开头
        // 第一个字符是不是包含反斜杠
        if (url == null) {
            return initWithHttp("");
        }
        if (!url.contains("http") && !url.contains("www.")) {
            if (url.indexOf("/") == 0) {
                return initWithHttp(ip + url);

            } else {
                return initWithHttp(ip + "/" + url);

            }
        } else {
            return initWithoutHttp(url);
        }
    }

    @NonNull
    public static Map<String, String> setHeaders() {
        Map<String, String> headers = new HashMap<>();
        headers.put("Host", DataCenter.getInstance().getDomain());
        headers.put("X-Requested-With", "XMLHttpRequest");
        headers.put("User-Agent", "app_android;Android");
        CookieManager cookieManager = CookieManager.getInstance();
        String cookie = DataCenter.getInstance().getCookie();
        LogUtils.e(String.format("请求的Cookie --> %s", cookie));
        if (cookie != null && cookieManager != null) {
            headers.put("Cookie", cookie);
            cookieManager.setCookie(DataCenter.getInstance().getDomain(), cookie);
        }
        return headers;
    }

    /**
     * 登录后设置cookie
     */
    public static void setCookie(Response response) {
        List<String> cookies = response.headers().values("Set-Cookie");
        for (String cookie : cookies) {
            if (cookie.contains("SID=") && cookie.length() > 80) {
                LogUtils.e("登录后Cookie ==> " + cookie);
                DataCenter.getInstance().setCookie(cookie);
                CookieManager.getInstance().setCookie(DataCenter.getInstance().getDomain(), cookie);
            }
        }
    }

    private static GlideUrl initWithoutHttp(String url) {
        return new GlideUrl(url, new LazyHeaders.Builder()
                .build());
    }

    private static GlideUrl initWithHttp(String url) {
        if (MSPropties.isApkDebugable()||DataCenter.getInstance().getDomain() == null || DataCenter.getInstance().getDomain().isEmpty()) {
            return new GlideUrl(url, new LazyHeaders.Builder()
                    .build());
        }
        return new GlideUrl(url, new LazyHeaders.Builder()
                .addHeader("HOST", DataCenter.getInstance().getDomain())
                .build());
    }

    public static boolean isURL(String str) {
        String regex = /*"^((https|http|ftp|rtsp|mms)?://)"
                + "?(([0-9a-z_!~*'().&=+$%-]+: )?[0-9a-z_!~*'().&=+$%-]+@)?" //ftp的user@
                + "(([0-9]{1,3}\\.){3}[0-9]{1,3}" // IP形式的URL- 199.194.52.184
                + "|" // 允许IP和DOMAIN（域名）
                + "([0-9a-z_!~*'()-]+\\.)*" // 域名- www.
//                 + "([0-9a-z][0-9a-z-]{0,61})?[0-9a-z]\\." // 二级域名
                + "[a-z]{2,6})" // first level domain- .com or .museum
                + "(:[0-9]{1,4})?" // 端口- :80
                + "((/?)|" // a slash isn't required if there is no file name
                + "(/[0-9a-z_!~*'().;?:@&=+$,%#-]+)+/?)$";*/
                "(((https|http)?://)?([a-z0-9]+[.])|(www.))"
                        + "\\w+[.|\\/]([a-z0-9]{0,})?[[.]([a-z0-9]{0,})]+((/[\\S&&[^,;\u4E00-\u9FA5]]+)+)?([.][a-z0-9]{0,}+|/?)";
        return match(regex, str);


    }

    /**
     * @param regex 正则表达式字符串
     * @param str   要匹配的字符串
     * @return 如果str 符合 regex的正则表达式格式,返回true, 否则返回 false;
     */
    private static boolean match(String regex, String str) {
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(str);
        return matcher.matches();

    }
}
