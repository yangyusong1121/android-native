package com.dawoo.lotterybox.mvp.view;

/**
 * - @Description: 用户申请代理
 * - @Author:  bella
 * - @Time:  18-7-18 上午10:04
 */

public interface IUserApplyAgent extends IBaseView {
    void applyAgentResult(Object o);
}
