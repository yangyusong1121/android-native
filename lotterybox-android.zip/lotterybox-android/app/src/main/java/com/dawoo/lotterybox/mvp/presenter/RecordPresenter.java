package com.dawoo.lotterybox.mvp.presenter;

import android.content.Context;

import com.dawoo.lotterybox.mvp.model.record.IRecordModel;
import com.dawoo.lotterybox.mvp.model.record.RecordModel;
import com.dawoo.lotterybox.mvp.service.IRecordService;
import com.dawoo.lotterybox.mvp.view.IBaseView;
import com.dawoo.lotterybox.mvp.view.INoteRecordDetailView;
import com.dawoo.lotterybox.mvp.view.INoteRecordHisView;
import com.dawoo.lotterybox.mvp.view.IRecordView;
import com.dawoo.lotterybox.net.RetrofitHelper;
import com.dawoo.lotterybox.net.rx.ProgressSubscriber;

import io.reactivex.disposables.Disposable;


/**
 * 记录相关的presenter
 * Created by benson on 18-1-7.
 */

public class RecordPresenter<T extends IBaseView> extends BasePresenter {
    private final Context mContext;
    private T mView;
    private final IRecordModel mModel;

    public RecordPresenter(Context context, T mView) {
        super(context, mView);

        mContext = context;
        this.mView = mView;
        mModel = new RecordModel();
    }


    /**
     * 玩家投注历史报表
     */
    public void getOrders(String code, String expect,
                          String status, String queryStartDate, String queryEndDate,
                          String pageSize, String pageNumber, String playModel, String order, String property) {
        Disposable Disposable = mModel.getOrders(new ProgressSubscriber(o ->
                        ((INoteRecordHisView) mView).onRefreshResult(o), mContext, false),
                code,
                expect,
                status,
                queryStartDate + " 00:00:00",
                queryEndDate + " 23:59:59",
                pageSize,
                pageNumber,
                playModel,
                order,
                property);

        subList.add(Disposable);
    }

    /**
     * 玩家投注历史报表 加载更多
     */
    public void getMoreOrders(String code, String expect,
                              String status, String queryStartDate, String queryEndDate,
                              String pageSize, String pageNumber, String playModel, String order, String property) {
        Disposable Disposable = mModel.getOrders(new ProgressSubscriber(o ->
                        ((INoteRecordHisView) mView).onLoadMoreResult(o), mContext, false),
                code,
                expect,
                status,
                queryStartDate + " 00:00:00",
                queryEndDate + " 23:59:59",
                pageSize,
                pageNumber,
                playModel, order, property);
        subList.add(Disposable);
    }


    /**
     * 获取所有彩种
     */
    public void getLottery() {
        Disposable Disposable = mModel.getLottery(new ProgressSubscriber(o ->
                ((INoteRecordHisView) mView).onLotteryDataResult(o), mContext, false));
        subList.add(Disposable);
    }

    /**
     * 获取下注总金额，派彩总金额（注单合计）
     */
    public void getAssets(String queryStartDate, String queryEndDate, String status, String code) {
        Disposable Disposable = mModel.getAssets(new ProgressSubscriber(o ->
                ((INoteRecordHisView) mView).onAssetsResult(o)
                , mContext, false), queryStartDate + " 00:00:00", queryEndDate + " 23:59:59", status, code);
        subList.add(Disposable);
    }

    /**
     * 获取30天内的盈亏数据
     */
    public void getRecentProfit(String status, String code) {
        Disposable Disposable = mModel.getRecentProfit(new ProgressSubscriber(o ->
                ((INoteRecordHisView) mView).onRecentProfit(o)
                , mContext, false), status, code);
        subList.add(Disposable);
    }

    /**
     * 获取注单详细
     */
    public void getOrderDetail(String id, String orign) {
        Disposable Disposable = mModel.getOrderDetail(new ProgressSubscriber(o ->
                ((INoteRecordDetailView) mView).onRefreshResult(o)
                , mContext), id, orign);
        subList.add(Disposable);
    }



    /**
     * 游戏记录
     */
    public void getOrderGroup(String startData, String endData) {
        Disposable orderGroup = mModel.getOrderGroup(new ProgressSubscriber(o ->
                ((INoteRecordHisView) mView).onRefreshResult(o)
                , mContext), startData+" 00:00:00", endData +" 23:59:59");
        subList.add(orderGroup);
    }

    @Override
    public void onDestory() {
        super.onDestory();
    }
}
