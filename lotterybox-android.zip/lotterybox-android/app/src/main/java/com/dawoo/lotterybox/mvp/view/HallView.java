package com.dawoo.lotterybox.mvp.view;

public interface HallView extends IBaseView {
    void onResult(Object o);
}
