package com.dawoo.lotterybox.bean;

/**
 * Created by rain on 18-6-12.
 */

public class CheckAccountBean {

    /*name_verification	bool	真实姓名是否需要验证 true需要 false 不
            bankNumber_verification
    bool	银行卡号是否需要验证 true 需要 false 不
    status	String	1 说明已通过玩家已激活 0 未激活*/
    boolean name_verification;
    boolean bankNumber_verification;
    int status=0;
    boolean verification = true;//false  直接登录 true走验证流程
    public boolean isName_verification() {
        return name_verification;
    }

    public void setName_verification(boolean name_verification) {
        this.name_verification = name_verification;
    }

    public boolean isBankNumber_verification() {
        return bankNumber_verification;
    }

    public void setBankNumber_verification(boolean bankNumber_verification) {
        this.bankNumber_verification = bankNumber_verification;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public boolean isVerification() {
        return verification;
    }

    public void setVerification(boolean verification) {
        this.verification = verification;
    }
}
