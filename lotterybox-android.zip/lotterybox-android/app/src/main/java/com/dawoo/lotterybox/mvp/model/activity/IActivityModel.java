package com.dawoo.lotterybox.mvp.model.activity;

import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;
import rx.Subscriber;
import rx.Subscription;

/**
 * Created by b on 18-2-16.
 */

public interface IActivityModel {


     Disposable getBanner(Observer subscriber);

     Disposable getBulletin(Observer subscriber);

     Disposable getPromoList(Observer subscriber , int pageSize, int pageNumber);

     Disposable getPromoContent(Observer subscriber ,int id);

     Disposable getCSLink(Observer subscriber);

}
