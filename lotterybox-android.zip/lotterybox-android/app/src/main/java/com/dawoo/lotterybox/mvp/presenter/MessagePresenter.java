package com.dawoo.lotterybox.mvp.presenter;

import android.content.Context;

import com.dawoo.lotterybox.mvp.model.common.CommonModel;
import com.dawoo.lotterybox.mvp.model.message.IMessageModel;
import com.dawoo.lotterybox.mvp.model.message.MessageModel;
import com.dawoo.lotterybox.mvp.view.IBaseView;
import com.dawoo.lotterybox.mvp.view.IAnnouncementView;
import com.dawoo.lotterybox.mvp.view.IMessageBaseView;
import com.dawoo.lotterybox.mvp.view.IMessageView;
import com.dawoo.lotterybox.net.rx.DefaultCallback;
import com.dawoo.lotterybox.net.rx.DefaultSubscriber;
import com.dawoo.lotterybox.net.rx.ProgressSubscriber;


import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;

import static com.dawoo.lotterybox.view.activity.message.MessageMailActivity.receiveMail_index;
import static com.dawoo.lotterybox.view.activity.message.MessageMailActivity.sendMail_index;


/**
 * 消息相关的presenter
 * Created by benson on 18-1-7.
 */

public class MessagePresenter<T extends IBaseView> extends BasePresenter {
    private final Context mContext;
    private T mView;
    private final IMessageModel mModel;
    private final CommonModel commonModel;

    public MessagePresenter(Context context, T mView) {
        super(context, mView);

        mContext = context;
        this.mView = mView;
        mModel = new MessageModel();
        commonModel = new CommonModel();
    }


    /**
     * 消息公告列表
     */
    public void getBulletins(int pageSize, int pageNumber, Boolean isLoadMore) {
        Disposable Disposable;
        if (!isLoadMore) {
            Disposable = mModel.getBulletins(new ProgressSubscriber(o ->
                            ((IAnnouncementView) mView).onRefreshResult(o), mContext, false),
                    pageSize + "",
                    pageNumber + "");
        } else {
            Disposable = mModel.getBulletins(new ProgressSubscriber(o ->
                            ((IAnnouncementView) mView).onLoadMoreResult(o), mContext, false),
                    pageSize + "",
                    pageNumber + "");
        }

        subList.add(Disposable);
    }

    public void getLtToken(Observer subscriber) {
        commonModel.getLtToken(subscriber);
    }


    public void getMsgList(int type, int pageSize, int pageNumber, Boolean isLoadMore) {
        if (type == receiveMail_index) {
            getReceiveMsg(pageSize, pageNumber, isLoadMore);
        } else if (type == sendMail_index) {
            getSendMsg(pageSize, pageNumber, isLoadMore);
        }
    }


    /**
     * 收件箱列表
     */
    public void getReceiveMsg(int pageSize, int pageNumber, Boolean isLoadMore) {
        Disposable Disposable;
        if (!isLoadMore) {
            Disposable = mModel.getReceiveMsg(new ProgressSubscriber(o ->
                            ((IMessageView) mView).onRefreshResult(o), mContext,false),
                    pageSize + "",
                    pageNumber + "");
        } else {
            Disposable = mModel.getReceiveMsg(new ProgressSubscriber(o ->
                            ((IMessageView) mView).onLoadMoreResult(o), mContext,false),
                    pageSize + "",
                    pageNumber + "");
        }

        subList.add(Disposable);
    }


    /**
     * 发件箱列表
     */
    public void getSendMsg(int pageSize, int pageNumber, Boolean isLoadMore) {
        Disposable Disposable;
        if (!isLoadMore) {
            Disposable = mModel.getSendMsg(new ProgressSubscriber(o ->
                            ((IMessageView) mView).onRefreshResult(o), mContext),
                    pageSize + "",
                    pageNumber + "");
        } else {
            Disposable = mModel.getSendMsg(new ProgressSubscriber(o ->
                            ((IMessageView) mView).onLoadMoreResult(o), mContext),
                    pageSize + "",
                    pageNumber + "");
        }

        subList.add(Disposable);
    }

    /**
     * 删除消息
     *
     * @param ids
     */
    public void deleteMsg(Object[] ids) {
        Disposable Disposable = mModel.deleteMsg(new ProgressSubscriber(o ->
                ((IMessageView) mView).onDeleteMsg(o), mContext), ids);

        subList.add(Disposable);
    }

    /**
     * 信箱详情
     */
    public void getMsgDetail(int id, int type) {
        Disposable Disposable = mModel.getMsgDetail(new ProgressSubscriber(o ->
                ((IMessageBaseView) mView).onRefreshResult(o), mContext), id, type);
        subList.add(Disposable);
    }

    /**
     * 删除消息
     */
    public void replyMsg(String username, String content, String title, String token) {
        Disposable Disposable = mModel.replyMsg(new ProgressSubscriber(o ->
                ((IMessageBaseView) mView).onRefreshResult(o), mContext), username, content, title, token);

        subList.add(Disposable);
    }


    /**
     * 发送消息
     */
    public void sendMsg(String sendType, String content, String title, String token) {
        Disposable Disposable = mModel.sendMsg(new ProgressSubscriber(o ->
                ((IMessageBaseView) mView).onRefreshResult(o), mContext), sendType, content, title, token);

        subList.add(Disposable);
    }

    /**
     * 下级代理，下级会员数量
     */
    public void getSubordinate() {
        Disposable Disposable = mModel.getSubordinate(new ProgressSubscriber(o ->
                ((IMessageBaseView) mView).onLoadSubordinate(o), mContext));

        subList.add(Disposable);
    }

    @Override
    public void onDestory() {
        super.onDestory();
    }
}
