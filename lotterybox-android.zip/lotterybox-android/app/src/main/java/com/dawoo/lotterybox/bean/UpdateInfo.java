package com.dawoo.lotterybox.bean;

/**
 * 更新信息
 * Created by fei on 16-11-21.
 */
public class UpdateInfo {
    /**
     * id : 15
     * appName : 12321
     * appType : android
     * versionCode : 5
     * versionName : 123
     * appUrl : http://jshdf.qfhwe
     * memo : 123123
     * renew : false
     * updateTime : 1526781573210
     * md5 : 8527a0a942fd9f149e4d8150cbe735e7
     */

    //id
    public int id;

    //版本名称
    public String appName;

    //版本类型［android］
    public String appType;

    //版本号
    public int versionCode;

    //版本号别称
    public String versionName;

    //版本号号链接地址
    public String appUrl;

    //描述
    public String memo;

    //是否强制更新
    public boolean renew;

    //更新时间
    public long updateTime;

    //版本秘钥
    public String md5;
    private  String androidUpdateUrl;

    public String getAndroidUpdateUrl() {
        return androidUpdateUrl;
    }

    public void setAndroidUpdateUrl(String androidUpdateUrl) {
        this.androidUpdateUrl = androidUpdateUrl;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public String getAppType() {
        return appType;
    }

    public void setAppType(String appType) {
        this.appType = appType;
    }

    public int getVersionCode() {
        return versionCode;
    }

    public void setVersionCode(int versionCode) {
        this.versionCode = versionCode;
    }

    public String getVersionName() {
        return versionName;
    }

    public void setVersionName(String versionName) {
        this.versionName = versionName;
    }

    public String getAppUrl() {
        return appUrl;
    }

    public void setAppUrl(String appUrl) {
        this.appUrl = appUrl;
    }

    public String getMemo() {
        return memo;
    }

    public void setMemo(String memo) {
        this.memo = memo;
    }

    public boolean isRenew() {
        return renew;
    }

    public void setRenew(boolean renew) {
        this.renew = renew;
    }

    public long getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(long updateTime) {
        this.updateTime = updateTime;
    }

    public String getMd5() {
        return md5;
    }

    public void setMd5(String md5) {
        this.md5 = md5;
    }
}
