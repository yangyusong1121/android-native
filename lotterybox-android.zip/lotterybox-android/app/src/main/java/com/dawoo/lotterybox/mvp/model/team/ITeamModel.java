package com.dawoo.lotterybox.mvp.model.team;

import com.dawoo.lotterybox.mvp.model.BaseModel;


import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;
import retrofit2.http.Query;


/**
 * Created by alex on 18-4-24.
 *
 * @author alex
 */

public interface ITeamModel {
    Disposable getTeamDataAssets(Observer Observer, String startDate, String endDate);

    Disposable getTeamDataState(Observer Observer, String startDate
            , String endDate, int dateFlag);

    Disposable getTeamDataStateSearch(Observer Observer, String startDate
            , String endDate);


    Disposable getTeamMember(Observer Observer, String startDate
            , String endDate, String playerType
            , String pageSize, String pageNumber);

    Disposable getTeamMember(Observer Observer, String playerType
            , String pageSize, String pageNumber, String name);

    Disposable getTeamReport(Observer Observer, String startDate
            , String endDate, String pageSize
            , String pageNumber);

    Disposable getTeamChanges(Observer Observer, String startDate, String endDate, String way, String type, String item, int pageNumber, int pageSize,String order, String property);

    Disposable getTeamSalary(Observer Observer, String playerId);

    Disposable getTeamParticipation(Observer Observer, String playerId);

    Disposable getTeamHasRatio(Observer Observer);

    Disposable  getSaveTeamSalary(Observer Observer,String jsonStr);

    Disposable  getSaveParticipation(Observer Observer,String jsonStr);

    Disposable  getCheckMemberType(Observer Observer);
    Disposable  saveMemberType(Observer Observer, String id, String status);
}
