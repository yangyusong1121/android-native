package com.dawoo.lotterybox.bean.lottery.lotteryenum;

/**
 * Created by benson on 18-2-12.
 */

public interface ICodeEnum {
    String getCode();

    String getTrans();
}
