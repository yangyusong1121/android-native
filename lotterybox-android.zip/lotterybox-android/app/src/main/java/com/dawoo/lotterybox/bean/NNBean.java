package com.dawoo.lotterybox.bean;

import java.io.Serializable;

public class NNBean implements Serializable {
    private String nums;
    private String playName;
    private String winOrLose;

    public String getNums() {
        return nums;
    }

    public void setNums(String nums) {
        this.nums = nums;
    }

    public String getPlayName() {
        return playName;
    }

    public void setPlayName(String playName) {
        this.playName = playName;
    }

    public String getWinOrLose() {
        return winOrLose;
    }

    public void setWinOrLose(String winOrLose) {
        this.winOrLose = winOrLose;
    }

    /**
     * 判断输赢
     * @return
     */
    public boolean isWin() {
        if (getWinOrLose() != null && getWinOrLose().equalsIgnoreCase("win")) {
            return true;
        } else {
            return false;
        }
    }

}
