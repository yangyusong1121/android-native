package com.dawoo.lotterybox.mvp.presenter;

import android.content.Context;

import com.dawoo.lotterybox.bean.SettingBean;
import com.dawoo.lotterybox.bean.TeamAssetsBean;
import com.dawoo.lotterybox.bean.TeamBillBean;
import com.dawoo.lotterybox.bean.TeamMemberBean;
import com.dawoo.lotterybox.bean.TeamParticipationBean;
import com.dawoo.lotterybox.bean.TeamReportBean;
import com.dawoo.lotterybox.bean.TeamSalaryBean;
import com.dawoo.lotterybox.bean.TeamStateBean;
import com.dawoo.lotterybox.bean.TeamhasRatioBean;
import com.dawoo.lotterybox.mvp.model.team.ITeamModel;
import com.dawoo.lotterybox.mvp.model.team.TeamModel;
import com.dawoo.lotterybox.mvp.view.IBaseView;
import com.dawoo.lotterybox.mvp.view.ICheckMemberType;
import com.dawoo.lotterybox.mvp.view.ISaveMemberType;
import com.dawoo.lotterybox.mvp.view.ITeamAssetsView;
import com.dawoo.lotterybox.mvp.view.ITeamChangesView;
import com.dawoo.lotterybox.mvp.view.ITeamMemberView;
import com.dawoo.lotterybox.mvp.view.ITeamParticipationView;
import com.dawoo.lotterybox.mvp.view.ITeamReportView;
import com.dawoo.lotterybox.mvp.view.ITeamSalaryView;
import com.dawoo.lotterybox.mvp.view.ITeamStateView;
import com.dawoo.lotterybox.net.rx.DefaultCallback;
import com.dawoo.lotterybox.net.rx.DefaultSubscriber;
import com.dawoo.lotterybox.net.rx.ProgressSubscriber;

import java.util.List;

import io.reactivex.disposables.Disposable;


/**
 * Created by alex on 18-4-24.
 *
 * @author alex
 */

public class TeamPresserter<T extends IBaseView> extends BasePresenter {
    private Context mContext;
    private T mView;
    private final ITeamModel mModel;
    private int pageNumber = 0;
    private int pageSize = 10;

    public TeamPresserter(Context mContext, T view) {
        super(mContext, view);
        this.mContext = mContext;
        this.mView = view;
        mModel = new TeamModel();
    }

    public void getTeamDataAssets(String startDate, String endDate) {
        Disposable Disposable = mModel.getTeamDataAssets(new ProgressSubscriber(o -> ((ITeamAssetsView) mView).onTeamAssetsResult((TeamAssetsBean) o), mContext, false), startDate, endDate);
        subList.add(Disposable);
    }

    public void getTeamDataState(String startDate
            , String endDate, int dateFlag) {
        Disposable Disposable = mModel.getTeamDataState(new ProgressSubscriber(o -> ((ITeamStateView) mView).onTeamStateResult((TeamStateBean) o), mContext), startDate, endDate, dateFlag);
        subList.add(Disposable);
    }

    public void getTeamDataState(String startDate
            , String endDate) {
        Disposable Disposable = mModel.getTeamDataStateSearch(new ProgressSubscriber(o -> ((ITeamStateView) mView).onTeamStateResult((TeamStateBean) o), mContext), startDate+" 00:00:00", endDate+" 23:59:59");
        subList.add(Disposable);
    }


    public void getTeamMember(String startDate
            , String endDate, String playerType
            , String pageSize, String pageNumber, String name) {
        Disposable Disposable = mModel.getTeamMember(new ProgressSubscriber(o -> ((ITeamMemberView) mView).onRefreshResult((List<TeamMemberBean>) o), mContext), playerType, pageSize, pageNumber, name);
        subList.add(Disposable);
    }

    public void getTeamMemberRefresh(DefaultCallback defaultCallback, String startDate
            , String endDate, String playerType, String name) {
        pageNumber = 1;
        Disposable Disposable = mModel.getTeamMember(new DefaultSubscriber<>(o -> ((ITeamMemberView) mView).onRefreshResult((List<TeamMemberBean>) o), defaultCallback), playerType, String.valueOf(pageSize), String.valueOf(pageNumber), name);
        subList.add(Disposable);
    }

    public void getTeamMemberLoadMore(DefaultCallback defaultCallback, String startDate
            , String endDate, String playerType, String name) {
        pageNumber++;
        Disposable Disposable = mModel.getTeamMember(new DefaultSubscriber<>(o -> ((ITeamMemberView) mView).onLoaderMoreResult((List<TeamMemberBean>) o), defaultCallback), playerType, String.valueOf(pageSize), String.valueOf(pageNumber), name);
        subList.add(Disposable);
    }

    public void getTeamReport(String startDate
            , String endDate, String pageSize
            , String pageNumber) {
        Disposable Disposable = mModel.getTeamReport(new ProgressSubscriber(o -> ((ITeamReportView) mView).onRefreshResult((TeamReportBean) o), mContext, false), startDate, endDate,
                pageSize, pageNumber);
        subList.add(Disposable);
    }


    public void getTeamReportRefresh(String startDate, String endDate, DefaultCallback defaultCallback) {
        pageNumber = 1;
        Disposable Disposable = mModel.getTeamReport(new DefaultSubscriber<>(o -> ((ITeamReportView) mView).onRefreshResult((TeamReportBean) o), defaultCallback), startDate, endDate,
                String.valueOf(pageSize), String.valueOf(pageNumber));
        subList.add(Disposable);
    }

    public void getTeamReportLoaderMore(String startDate, String endDate, DefaultCallback defaultCallback) {
        pageNumber++;
        Disposable Disposable = mModel.getTeamReport(new DefaultSubscriber<>(o -> ((ITeamReportView) mView).onLoadMoreResult((TeamReportBean) o), defaultCallback), startDate, endDate,
                String.valueOf(pageSize), String.valueOf(pageNumber));
        subList.add(Disposable);
    }

    public void getTeamChanges(String startDate, String endDate, String way, String type, String item, String order, String property) {
        Disposable Disposable = mModel.getTeamChanges(new ProgressSubscriber(o -> ((ITeamChangesView) mView).onTeamChangrsResult((List<TeamBillBean>) o), mContext), startDate, endDate, way, type, item, 1, 10, order, property);
        subList.add(Disposable);
    }

    public void getTeamChangesRefresh(String startDate, String endDate, String way, String type, String item, int pageNumber, int pageSize, DefaultCallback defaultCallback, String order, String property) {
        Disposable Disposable = mModel.getTeamChanges(new DefaultSubscriber<>(o -> ((ITeamChangesView) mView).onTeamChangrsResult((List<TeamBillBean>) o), defaultCallback), startDate, endDate, way, type, item, pageNumber, pageSize, order, property);
        subList.add(Disposable);
    }

    public void getTeamSalary(String playerId) {
        Disposable Disposable = mModel.getTeamSalary(new ProgressSubscriber(o -> ((ITeamSalaryView) mView).onSalaryResult((TeamSalaryBean) o), mContext), playerId);
        subList.add(Disposable);
    }

    public void getTeamParticipation(String playerId) {
        Disposable Disposable = mModel.getTeamParticipation(new ProgressSubscriber(o -> ((ITeamParticipationView) mView).onParticipationResult((TeamParticipationBean) o), mContext), playerId);
        subList.add(Disposable);
    }

    public void getTeamHasRatio() {
        Disposable Disposable = mModel.getTeamHasRatio(new ProgressSubscriber(o -> ((ITeamMemberView) mView).onHasRatioResult((TeamhasRatioBean) o), mContext, false));
        subList.add(Disposable);
    }

    public void getSaveTeamSalary(String jsonStr) {
        Disposable Disposable = mModel.getSaveTeamSalary(new ProgressSubscriber(o -> ((ITeamSalaryView) mView).onSaveTeamSalaryResult((Boolean) o), mContext), jsonStr);
        subList.add(Disposable);
    }

    public void getSaveParticipation(String jsonStr) {
        Disposable Disposable = mModel.getSaveParticipation(new ProgressSubscriber(o -> ((ITeamParticipationView) mView).onSaveTeamParticipationResult((Boolean) o), mContext), jsonStr);
        subList.add(Disposable);
    }

    public void getCheckMemberType() {
        Disposable Disposable = mModel.getCheckMemberType(new ProgressSubscriber(o -> ((ICheckMemberType) mView).checkMemberTypeResult(o), mContext, false));
        subList.add(Disposable);
    }

    public void saveMemberType(String id, String status) {
        Disposable Disposable = mModel.saveMemberType(new ProgressSubscriber(o -> ((ICheckMemberType) mView).saveMemberTypeResult(o), mContext), id, status);
        subList.add(Disposable);
    }
}
