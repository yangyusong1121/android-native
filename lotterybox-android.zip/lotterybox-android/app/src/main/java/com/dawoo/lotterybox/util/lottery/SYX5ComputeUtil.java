package com.dawoo.lotterybox.util.lottery;

import android.graphics.drawable.AnimationDrawable;
import android.widget.TextView;

import com.dawoo.lotterybox.BoxApplication;
import com.dawoo.lotterybox.R;
import com.dawoo.lotterybox.bean.lottery.Handicap;
import com.dawoo.lotterybox.bean.playtype.PlayTypeBean;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * Created by rain on 18-6-5.
 */

public class SYX5ComputeUtil {
    private List<Handicap> mHandicapList;
    private PlayTypeBean.PlayBean mPlayBean;

    public void setData(List<Handicap> mHandicapList) {
        this.mHandicapList = mHandicapList;
    }

    public void setPlayTypeBean(PlayTypeBean.PlayBean mPlayBean) {
        this.mPlayBean = mPlayBean;
    }


    /**
     * @param type true:冷热  false: 遗漏
     */
    public void compute(boolean type) {
        if (mHandicapList == null || mPlayBean == null)
            return;
        int[] positions = getPosition();
        String playTypeName = mPlayBean.getPlayTypeName();
        String mainTypeName = mPlayBean.getMainType();
        List<PlayTypeBean.PlayBean.LayoutBean> layoutBeans = mPlayBean.getLayoutBeans();
        for (PlayTypeBean.PlayBean.LayoutBean layoutBean : layoutBeans) {
            for (PlayTypeBean.PlayBean.LayoutBean.ChildLayoutBean childLayoutBean : layoutBean.getChildLayoutBeans()) {
                childLayoutBean.setNumberRelevant(0); //清理之前的数据
            }
        }

        if ("直选复式".equals(playTypeName) || "定胆位".equals(playTypeName)) {

            for (int i = 0; i < mHandicapList.size(); i++) {
                String openCode = mHandicapList.get(i).getOpenCode();
                String[] strCodes = openCode.split(",");
                int[] codes = {Integer.valueOf(strCodes[0]), Integer.valueOf(strCodes[1]), Integer.valueOf(strCodes[2]), Integer.valueOf(strCodes[3]), Integer.valueOf(strCodes[4])};
                for (int j = positions[0]; j < positions[1] + 1; j++) {
                    int code = codes[j];
                    if (type) {
                        PlayTypeBean.PlayBean.LayoutBean.ChildLayoutBean childLayoutBean = layoutBeans.get(j - positions[0]).getChildLayoutBeans().get(code-1);  //获取相对应的球实体
                        childLayoutBean.setNumberRelevant(childLayoutBean.getNumberRelevant() + 1);
                    } else {
                        List<PlayTypeBean.PlayBean.LayoutBean.ChildLayoutBean> childLayoutBeans = layoutBeans.get(j - positions[0]).getChildLayoutBeans();
                        setOmit(childLayoutBeans, code);
                    }
                }
            }

        } else if ("组选复式".equalsIgnoreCase(playTypeName) || "任选复试".equalsIgnoreCase(mainTypeName) || "不定位".equalsIgnoreCase(playTypeName)) {
            for (int i = 0; i < mHandicapList.size(); i++) {
                String openCode = mHandicapList.get(i).getOpenCode();
                String[] strCodes = openCode.split(",");
                int[] codes = {Integer.valueOf(strCodes[0]), Integer.valueOf(strCodes[1]), Integer.valueOf(strCodes[2]), Integer.valueOf(strCodes[3]), Integer.valueOf(strCodes[4])};
                for (int j = positions[0]; j < positions[1] + 1; j++) {
                    int code = codes[j];
                    if (type) {
                        PlayTypeBean.PlayBean.LayoutBean.ChildLayoutBean childLayoutBean = layoutBeans.get(0).getChildLayoutBeans().get(code - 1);  //获取相对应的球实体
                        childLayoutBean.setNumberRelevant(childLayoutBean.getNumberRelevant() + 1);
                    } else {
                        List<PlayTypeBean.PlayBean.LayoutBean.ChildLayoutBean> childLayoutBeans = layoutBeans.get(0).getChildLayoutBeans();
                        setOmit(childLayoutBeans, code );
                    }
                }
            }
        } else if (playTypeName.contains("胆拖") || mainTypeName.equals("任选胆拖")) {
            for (int i = 0; i < mHandicapList.size(); i++) {
                String openCode = mHandicapList.get(i).getOpenCode();
                String[] strCodes = openCode.split(",");
                int[] codes = {Integer.valueOf(strCodes[0]), Integer.valueOf(strCodes[1]), Integer.valueOf(strCodes[2]), Integer.valueOf(strCodes[3]), Integer.valueOf(strCodes[4])};
                for (int j = positions[0]; j < positions[1] + 1; j++) {
                    int code = codes[j];
                    if (type) {
                        PlayTypeBean.PlayBean.LayoutBean.ChildLayoutBean childLayoutBean = layoutBeans.get(0).getChildLayoutBeans().get(code - 1);  //获取相对应的球实体
                        childLayoutBean.setNumberRelevant(childLayoutBean.getNumberRelevant() + 1);
                        PlayTypeBean.PlayBean.LayoutBean.ChildLayoutBean childLayoutBean0 = layoutBeans.get(1).getChildLayoutBeans().get(code - 1);  //获取相对应的球实体
                        childLayoutBean0.setNumberRelevant(childLayoutBean0.getNumberRelevant() + 1);
                    } else {
                        List<PlayTypeBean.PlayBean.LayoutBean.ChildLayoutBean> childLayoutBeans = layoutBeans.get(0).getChildLayoutBeans();
                        setOmit(childLayoutBeans, code);
                        PlayTypeBean.PlayBean.LayoutBean.ChildLayoutBean childLayoutBean0 = layoutBeans.get(1).getChildLayoutBeans().get(code - 1);  //获取相对应的球实体
                        childLayoutBean0.setNumberRelevant(childLayoutBean0.getNumberRelevant() + 1);
                    }
                }
            }
        }else if (mainTypeName.equals("任选")){
            for (int i = 0; i < mHandicapList.size(); i++) {
                String openCode = mHandicapList.get(i).getOpenCode();
                String[] strCodes = openCode.split(",");
                int[] codes = {Integer.valueOf(strCodes[0]), Integer.valueOf(strCodes[1]), Integer.valueOf(strCodes[2]), Integer.valueOf(strCodes[3]), Integer.valueOf(strCodes[4])};
                for (int j = positions[0]; j < positions[1] + 1; j++) {
                    int code = codes[j];
                    if (type){
                        PlayTypeBean.PlayBean.LayoutBean.ChildLayoutBean childLayoutBean = layoutBeans.get(0).getChildLayoutBeans().get(code - 1);  //获取相对应的球实体
                        childLayoutBean.setNumberRelevant(childLayoutBean.getNumberRelevant() + 1);
                    }else {
                        List<PlayTypeBean.PlayBean.LayoutBean.ChildLayoutBean> childLayoutBeans = layoutBeans.get(0).getChildLayoutBeans();
                        setOmit(childLayoutBeans, code);
                    }
                }
            }
        }
    }

    //设置遗漏

    private void setOmit(List<PlayTypeBean.PlayBean.LayoutBean.ChildLayoutBean> childLayoutBeans, int index) {
        for (int k = 0; k < childLayoutBeans.size(); k++) {
            PlayTypeBean.PlayBean.LayoutBean.ChildLayoutBean childLayoutBean = childLayoutBeans.get(k);
            if (k == (index - 1)) {
                if (childLayoutBean.getNumberRelevant() < 1000)
                    childLayoutBean.setNumberRelevant(childLayoutBean.getNumberRelevant() + 1000); //1000用作判断该球已出现，无需再叠加计算遗漏
            } else {
                if (childLayoutBean.getNumberRelevant() < 1000) {
                    childLayoutBean.setNumberRelevant(childLayoutBean.getNumberRelevant() + 1);
                }
            }
        }
    }

    private int[] getPosition() {
        int[] positions = new int[2];
        String mainType = mPlayBean.getMainType();
        if ("定胆位".equals(mainType) || "任选".equalsIgnoreCase(mPlayBean.getMainType())) {
            positions[0] = 0;
            positions[1] = 4;
        } else if ("后三".equals(mainType)) {
            positions[0] = 2;
            positions[1] = 4;
        } else if ("前三".equals(mainType)) {
            positions[0] = 0;
            positions[1] = 2;
        } else if ("中三".equals(mainType)) {
            positions[0] = 1;
            positions[1] = 3;
        } else if ("任选".equals(mainType)) {
            positions[0] = 1;
            positions[1] = 4;
        } else if ("后二".equals(mainType)) {
            positions[0] = 3;
            positions[1] = 4;
        } else if ("前二".equals(mainType)) {
            positions[0] = 0;
            positions[1] = 1;
        }
        return positions;
    }

    /**
     * 获取和值
     * @param openCodes
     * @return
     */
    public static int getCount(String openCodes) {
        List<String> numbers = Arrays.asList(openCodes.split(","));
        Collections.sort(numbers);
        int count = 0;
        if (numbers.size() == 5) {   //接口没做好，包含有3个号的结果
            for (String s : numbers) {
                if (!s.isEmpty()) {
                    count += Integer.parseInt(s);
                }
            }
        }
        return count;
    }

    /**
     * 获取跨度
     * @param openCodes
     * @return
     */
    public static int getMantissa(String openCodes) {
        List<String> numbers = Arrays.asList(openCodes.split(","));
        if (numbers.size() != 5) {
            return 0;
        }
        Collections.sort(numbers);
        return Math.abs(Integer.parseInt(numbers.get(0)) - Integer.parseInt(numbers.get(4)));
    }


    /**
     * 十一选五 背景切换和 结果
     *
     * @param number
     * @param view
     */
    public static void getImageResourceFormNumber(String number, TextView view) {
        view.setBackgroundResource(R.drawable.ssc_ball_bg);
        view.setTextColor(BoxApplication.getContext().getResources().getColor(R.color.white));
        if ("0".equals(number)) {
            view.setText("0");
        } else if ("1".equals(number)) {
            view.setText("1");
        } else if ("2".equals(number)) {
            view.setText("2");
        } else if ("3".equals(number)) {
            view.setText("3");
        } else if ("4".equals(number)) {
            view.setText("4");
        } else if ("5".equals(number)) {
            view.setText("5");
        } else if ("6".equals(number)) {
            view.setText("6");
        } else if ("7".equals(number)) {
            view.setText("7");
        } else if ("8".equals(number)) {
            view.setText("8");
        } else if ("9".equals(number)) {
            view.setText("9");
        }

    }

    /**
     * 十一选五  动画
     *
     * @param view
     */
    public static void setSYXWAnimation(TextView view) {
        view.setBackgroundResource(R.drawable.anim_blue_ball_result);
        view.setText("");
        ((AnimationDrawable) view.getBackground()).start();
    }

    /**
     * 十一选五  距离封盘时间 倒计时结束回调
     *
     * @param view
     */
    public static void setSYXWSyntony(TextView view) {
        view.setBackgroundResource(R.drawable.ssc_ball_bg);
        view.setText("");
    }
}
