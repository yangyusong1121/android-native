package com.dawoo.lotterybox.util.lottery;

import android.graphics.drawable.AnimationDrawable;
import android.widget.TextView;

import com.dawoo.lotterybox.BoxApplication;
import com.dawoo.lotterybox.R;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * 时时彩工具类
 * Created by benson on 18-2-13.
 */

public class SSCUtil {

    /**
     * 和值
     *
     * @param arr
     * @return
     */
    public static int getHeZhi(String[] arr) {
        int sum = 0;
        for (int i = 0; i < arr.length; i++) {
            sum += Integer.parseInt(arr[i]);
        }
        return sum;
    }

    public static String getZuLiuOrZUSan(int code3, int code4, int code5) {
        if (code3 != code4 && code3 != code5 && code4 != code5) {
            return "组六";
        } else if (code3 == code4 && code4 == code5) {
            return "豹子";
        }
        return "组三";
    }

    /**
     * 组六 或者 组三
     *
     * @return
     */
    public static String getZuLiuOrZUSan2(int code3, int code4, int code5) {
        if (code3 != code4 && code3 != code5 && code4 != code5) {
            return "六";
        } else if (code3 == code4 && code4 == code5) {
            return "豹子";
        }
        return "三";
    }

    /**
     * 获取时时彩大小单双
     *
     * @return
     */
    public static String getDaXiaoDanShuang(int x) {
        //  大小
        if (x < 5 && x >= 0) {
            // 小
            if (x % 2 == 0) {
                return "小双";
            } else {
                return "小单";
            }
        } else if (x < 10 && x >= 5) {
            // 小
            if (x % 2 == 0) {
                return "大双";
            } else {
                return "大单";
            }
        }

        return "";
    }

    /**
     * 跨度
     *
     * @param arr
     * @return
     */
    public static int getSpan(String[] arr) {
        List<String> strings = Arrays.asList(arr);
        List<String> m = new ArrayList<>();
        m.addAll(strings);
        Collections.sort(m);
        return Math.abs(Integer.parseInt(m.get(0)) - Integer.parseInt(m.get(4)));
    }

    /**
     * 获取官方玩法（A盘）时时彩的 和数 跨度 位数
     *
     * @param numbers
     * @return
     */
    public static String getSSC_A_Result(String[] numbers) {
        if (numbers.length == 5) {   //接口没做好，包含有3个号的结果
            int heZhi = SSCUtil.getHeZhi(numbers);
            int span = SSCUtil.getSpan(numbers);
            String ZuLiuOrZUSan = SSCUtil.getZuLiuOrZUSan(Integer.parseInt(numbers[2]), Integer.parseInt(numbers[3]), Integer.parseInt(numbers[4]));
            return heZhi + " " + span + " " + ZuLiuOrZUSan;
        } else
            return "";
    }

    /**
     * 时时彩 背景切换和 结果
     *
     * @param number
     * @param view
     */
    public static void getImageResourceFormNumber(String number, TextView view) {
        view.setBackgroundResource(R.drawable.ssc_ball_bg);
        view.setTextColor(BoxApplication.getContext().getResources().getColor(R.color.white));
        if ("0".equals(number)) {
            view.setText("0");
        } else if ("1".equals(number)) {
            view.setText("1");
        } else if ("2".equals(number)) {
            view.setText("2");
        } else if ("3".equals(number)) {
            view.setText("3");
        } else if ("4".equals(number)) {
            view.setText("4");
        } else if ("5".equals(number)) {
            view.setText("5");
        } else if ("6".equals(number)) {
            view.setText("6");
        } else if ("7".equals(number)) {
            view.setText("7");
        } else if ("8".equals(number)) {
            view.setText("8");
        } else if ("9".equals(number)) {
            view.setText("9");
        }

    }

    /**
     * 时时彩 动画
     *
     * @param view
     */
    public static void setSSCAnimation(TextView view) {
        view.setBackgroundResource(R.drawable.anim_blue_ball_result);
        view.setText("");
        ((AnimationDrawable) view.getBackground()).start();
    }

    /**
     * 时时彩 距离封盘时间 倒计时结束回调
     *
     * @param view
     */
    public static void setSSCSyntony(TextView view) {
        view.setBackgroundResource(R.drawable.ssc_ball_bg);
        view.setText("");
    }

}
