package com.dawoo.lotterybox.mvp.presenter;

import android.content.Context;

import com.dawoo.lotterybox.bean.Bank;
import com.dawoo.lotterybox.bean.EasyHttpResult;
import com.dawoo.lotterybox.bean.WithDrawBean;
import com.dawoo.lotterybox.bean.WithDrawsAduitBean;
import com.dawoo.lotterybox.bean.WithDrawsDetailBean;
import com.dawoo.lotterybox.bean.WithDrawsFeeBean;
import com.dawoo.lotterybox.mvp.model.common.CommonModel;
import com.dawoo.lotterybox.mvp.model.withdraws.IWithDrawsModel;
import com.dawoo.lotterybox.mvp.model.withdraws.WithDrawsModel;
import com.dawoo.lotterybox.mvp.view.IBandCardListIView;
import com.dawoo.lotterybox.mvp.view.IBankListView;
import com.dawoo.lotterybox.mvp.view.IBaseView;
import com.dawoo.lotterybox.mvp.view.IBindBankCardView;
import com.dawoo.lotterybox.mvp.view.IDepositView;
import com.dawoo.lotterybox.mvp.view.IMCenterFragmentView;
import com.dawoo.lotterybox.mvp.view.IWithDAView;
import com.dawoo.lotterybox.mvp.view.IWithDrawView;
import com.dawoo.lotterybox.mvp.view.IWithDrawsDetailView;
import com.dawoo.lotterybox.net.rx.DefaultCallback;
import com.dawoo.lotterybox.net.rx.DefaultSubscriber;
import com.dawoo.lotterybox.net.rx.ProgressSubscriber;

import java.util.List;

import io.reactivex.disposables.Disposable;


/**
 * Created by alex on 18-4-5.
 * @author alex
 */

public class WithDrawsPresenter<T extends IBaseView> extends BasePresenter {
    private final Context mContext;
    private final CommonModel mCommonModel;
    private T mView;
    private final IWithDrawsModel mModel;

    public WithDrawsPresenter(Context context, T mView) {
        super(context, mView);
        mContext = context;
        this.mView = mView;
        mModel = new WithDrawsModel();
        mCommonModel = new CommonModel();
    }


    /**
     * 计算可以提出的额度
     */
    public void getWithDrawsFee(String money,DefaultCallback defaultCallback) {
        Disposable Disposable = mModel.getWithDrawsFee(new DefaultSubscriber<>(o -> ((IWithDrawView) mView).onFeeResult((WithDrawsFeeBean)o),defaultCallback), money);
        subList.add(Disposable);
    }

    /**
     * 区块界面初始化
     */
    public void withDrawInit() {
        Disposable Disposable = mModel.withDrawsInit(new ProgressSubscriber(o -> ((IWithDrawView) mView).onInitResult((WithDrawBean) o), mContext));
        subList.add(Disposable);
    }

    /**
     * 提交取现
     */
    public void applyWithDraws(String money ,String token) {
        Disposable Disposable = mModel.applyWithDraws(new ProgressSubscriber(o -> ((IWithDrawView) mView).onApplyResult((EasyHttpResult)o), mContext),money,token);
        subList.add(Disposable);
    }
    /**
     * 稽核列表
     */
    public void withDrawsAuidtList(DefaultCallback defaultCallback) {
        Disposable Disposable = mModel.withDrawsAudit(new DefaultSubscriber<>(o -> ((IWithDAView) mView).IWithDrawsAduitResult((List<WithDrawsAduitBean>) o), defaultCallback));
        subList.add(Disposable);
    }
    /**
     * 稽核详情
     */
    public void withDrawsAuidDeatail(String id) {
        Disposable Disposable = mModel.withDrawsAuditDetail(new ProgressSubscriber(o -> ((IWithDrawsDetailView) mView).resultDetail((WithDrawsDetailBean) o), mContext),id);
        subList.add(Disposable);
    }
    /**
     * 获取防重token
     */
    public void getLtToken() {
        Disposable Disposable = mCommonModel.getLtToken(new ProgressSubscriber<>(o ->
                ((IWithDrawView) mView).onLtToken((String) o), mContext,false)
        );
        subList.add(Disposable);
    }



//    /**
//     * 银行卡列表
//     */
//
//    public void bankCardList() {
//        Disposable Disposable = mModel.bankcardList(new ProgressSubscriber(o -> ((IBandCardListIView) mView).bandCardList(o), mContext));
//        subList.add(Disposable);
//    }
//
//    /**
//     * 获取银行卡列表
//     */
//
//    public void getBankList() {
//        Disposable Disposable = mModel.getBanks(new ProgressSubscriber(o -> ((IBankListView) mView).onResultDate((List<Bank>) o), mContext));
//        subList.add(Disposable);
//    }
//
//    /**
//     * 绑定银行卡
//     */
//
//    public void bingBankCard(String bankCode, String bankName, String cardNumber, String masterName) {
//        Disposable Disposable = mModel.bindBankCard(new ProgressSubscriber(o -> ((IBindBankCardView) mView).onResult(o), mContext), bankCode, bankName, cardNumber, masterName);
//        subList.add(Disposable);
//    }


}
