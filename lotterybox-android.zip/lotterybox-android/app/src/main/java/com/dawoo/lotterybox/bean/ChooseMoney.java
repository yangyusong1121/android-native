package com.dawoo.lotterybox.bean;

/**
 * Created by archar on 18-3-5.
 */

public class ChooseMoney {
    private int count;
    private String drawableId;


    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public String getDrawableId() {
        return drawableId;
    }

    public void setDrawableId(String drawableId) {
        this.drawableId = drawableId;
    }
}
