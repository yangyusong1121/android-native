package com.dawoo.lotterybox.mvp.view;

/**
 * Created by b on 18-3-7.
 */

public interface LotteryBView extends IBaseLotteryView{


}
