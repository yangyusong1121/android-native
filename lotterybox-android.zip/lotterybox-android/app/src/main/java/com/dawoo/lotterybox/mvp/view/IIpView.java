package com.dawoo.lotterybox.mvp.view;

import com.dawoo.lotterybox.bean.IpBean;

import java.util.List;

public interface IIpView extends IBaseView {
    void onResult(List<IpBean>datas);
}
