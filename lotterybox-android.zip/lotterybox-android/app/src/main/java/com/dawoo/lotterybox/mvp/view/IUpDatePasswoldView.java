package com.dawoo.lotterybox.mvp.view;

import com.dawoo.lotterybox.net.BaseHttpResult;

/**
 * Created by jack on 18-2-11.
 */

public interface IUpDatePasswoldView extends IBaseView {
    void onResult(BaseHttpResult o);

    void onLoginOutResult(Object o);
}
