package com.dawoo.lotterybox.bean;

/**
 * @author alex
 * pk10用于投注显示的bean
 */
public class Pk10BetBean {
    //闲几

    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }

    private int position;
    //代表平倍翻倍
    private String betLev;
    //投注的倍率
    private String betRate;
    //投注的金额
    private String betNumber;
    //冻结的金额
    private String frezzNumber;

    public String getBetLev() {
        return betLev;
    }

    public void setBetLev(String betLev) {
        this.betLev = betLev;
    }

    public String getBetRate() {
        return betRate;
    }

    public void setBetRate(String betRate) {
        this.betRate = betRate;
    }

    public String getBetNumber() {
        return betNumber;
    }

    public void setBetNumber(String betNumber) {
        this.betNumber = betNumber;
    }

    public String getFrezzNumber() {
        return frezzNumber;
    }

    public void setFrezzNumber(String frezzNumber) {
        this.frezzNumber = frezzNumber;
    }
}
