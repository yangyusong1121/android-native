package com.dawoo.lotterybox.adapter;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.view.PagerAdapter;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.blankj.utilcode.util.AppUtils;
import com.blankj.utilcode.util.DeviceUtils;
import com.dawoo.lotterybox.R;
import com.dawoo.lotterybox.bean.playtype.PlayTypeBean;
import com.dawoo.lotterybox.view.fragment.HeadSelectFragment;
import com.google.common.collect.Lists;

import java.util.ArrayList;
import java.util.List;

/**
 * @author alex
 */
public class LotteryHeadPullAdapter extends PagerAdapter {
    private List<PlayTypeBean> datas = Lists.newArrayList();
    private TypeSelectCallback typeSelectCallback;
    public LotteryHeadPullAdapter(List<PlayTypeBean> datas,TypeSelectCallback typeSelectCallback) {
        this.datas = datas;
        this.typeSelectCallback=typeSelectCallback;
    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        return datas.get(position).getType();
    }

    @Override
    public int getCount() {
        return datas.size();
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view == object;
    }

    public void setNewData(List<PlayTypeBean> datas){
        this.datas=datas;
        notifyDataSetChanged();
    }

    @Override
    public int getItemPosition(@NonNull Object object) {
        return POSITION_NONE;
    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, int position) {
        View view = LayoutInflater.from(container.getContext()).inflate(R.layout.fragment_lottery_base_top_selecting, container, false);
        RecyclerView rvRoot = view.findViewById(R.id.rv_root);
        HeadSelectFragment headSelectFragment = new HeadSelectFragment(datas, container.getContext(), rvRoot,position);
        headSelectFragment.initView();
        headSelectFragment.initData(childPosition -> typeSelectCallback.onSelect(LotteryHeadPullAdapter.this,position,childPosition));
        container.addView(view);
        return view;
    }

    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
        container.removeView((View) object);
    }
    public interface TypeSelectCallback{
        void onSelect(LotteryHeadPullAdapter adapter,int position,int childPosition);
    }
}
