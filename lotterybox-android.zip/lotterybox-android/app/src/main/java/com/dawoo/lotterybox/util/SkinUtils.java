package com.dawoo.lotterybox.util;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.support.annotation.ColorInt;
import android.support.annotation.DrawableRes;

import com.dawoo.lotterybox.BoxApplication;
import com.dawoo.lotterybox.R;
import com.dawoo.lotterybox.net.rx.DefaultCallback;

import java.util.Objects;

/**
 * 框架存在缺陷，少部分无法替换通过代码动态替换
 *
 * @author alex
 */
public class SkinUtils {

    public static String getSkinName(Context context) {
        int DEFAULT = context.getResources().getColor(R.color.default_skin);
        int BLUE_SKIN = context.getResources().getColor(R.color.blue_skin);
        int RED_SKIN = context.getResources().getColor(R.color.red_skin);
        int GREEN_SKIN = context.getResources().getColor(R.color.green_skin);
        int skin = context.getResources().getColor(R.color.colorPrimary);
        if (Objects.equals(skin, DEFAULT)) {
            return "";
        }
        if (Objects.equals(skin, BLUE_SKIN)) {
            return "blue.skin";
        }
        if (Objects.equals(skin, RED_SKIN)) {
            return "red.skin";
        }
        if (Objects.equals(skin, GREEN_SKIN)) {
            return "green.skin";
        }
        return "";

    }


    public static @ColorInt
    int getChangeColor(Context context) {
        return context.getResources().getColor(R.color.colorPrimary);
    }


}
