package com.dawoo.lotterybox.adapter.hall.parent;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v4.app.FragmentActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.bumptech.glide.request.RequestOptions;
import com.dawoo.lotterybox.BoxApplication;
import com.dawoo.lotterybox.R;
import com.dawoo.lotterybox.adapter.hall.child.BaseViewHolder;
import com.dawoo.lotterybox.bean.BannerBean;
import com.dawoo.lotterybox.bean.Bulletin;
import com.dawoo.lotterybox.bean.lottery.hall.HotLotteryBean;
import com.dawoo.lotterybox.bean.lottery.hall.LotteryBean;
import com.dawoo.lotterybox.view.view.SegmentTabLayout.OnTabSelectListener;
import com.dawoo.lotterybox.view.view.SkinSegmentTabLayout;

import java.util.ArrayList;
import java.util.List;


/**
 * Created by b on 18-4-12.
 */

public class ParentRecyclerAdapter extends RecyclerView.Adapter<BaseViewHolder> {
    private RequestOptions hallOptions;
    private Context mContext;
    private List<BannerBean> bannerBeans = new ArrayList<>(); //轮播图数据
    private List<Bulletin> bulletins = new ArrayList<>();    //公告数据
    private List<LotteryBean> mLottery = new ArrayList<>(); //彩种类型数据
    private HotLotteryBean mHotLotteryBean;  //热门彩种数据
    private int mPosition;

    public ParentRecyclerAdapter(Context context) {
        mContext = context;
        if (context instanceof FragmentActivity) {
            hallOptions = ((BoxApplication) ((FragmentActivity) context).getApplication()).getHallOptions();
        }
    }

    @NonNull
    @Override
    public BaseViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = null;
        switch (viewType) {
            case 0:
                view = LayoutInflater.from(mContext).inflate(R.layout.item_hall_banner, parent, false);
                return new BannerViewHolder(mContext, view);
            case 1:
                view = LayoutInflater.from(mContext).inflate(R.layout.item_hall_marquee_text, parent, false);
                return new MarqueeTextViewHolder(mContext, view);
            case 2:
                view = LayoutInflater.from(mContext).inflate(R.layout.item_hall_shortcut_icon, parent, false);
                return new ShortcutViewHolder(mContext, view);
            case 3:
                view = LayoutInflater.from(mContext).inflate(R.layout.item_hall_lotterys, parent, false);
                return new TabHolder(view);
            default:
                view = LayoutInflater.from(mContext).inflate(R.layout.item_hall_lottery, parent, false);
                return new LotteryViewHolder(mContext, view);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull BaseViewHolder holder, int position) {
        if (holder instanceof BannerViewHolder)
            ((BannerViewHolder) holder).bindView(bannerBeans);
        else if (holder instanceof MarqueeTextViewHolder)
            ((MarqueeTextViewHolder) holder).bindView(bulletins);
        else if (holder instanceof TabHolder) {
            ((TabHolder) holder).bind();
        } else if (holder instanceof LotteryViewHolder) {
            ((LotteryViewHolder) holder).setOptions(hallOptions);
            ((LotteryViewHolder) holder).bindView(mLottery.get(position - 4));
        }
    }

    public void setBannerBeans(List<BannerBean> bannerBeans) {
        this.bannerBeans = bannerBeans;
        notifyItemChanged(0);
    }

    public void setBulletins(List<Bulletin> bulletins) {
        this.bulletins = bulletins;
        notifyItemChanged(1);
    }

    public void setTab() {
        notifyItemChanged(3);
    }

    /**
     * 设置热门彩种数据
     */
    public void setHotLottery(HotLotteryBean hotLottery) {
        if (hotLottery == null) {
            return;
        }
        if (hotLottery.getTradition() != null && !hotLottery.getTradition().isEmpty() && !hotLottery.getTradition().get(hotLottery.getTradition().size() - 1).getModel().equalsIgnoreCase("more")) {
            LotteryBean bean0 = new LotteryBean();
            bean0.setModel("more");
            bean0.setType("0");
            hotLottery.getTradition().add(bean0);
        }
        if (hotLottery.getOfficial() != null && !hotLottery.getOfficial().isEmpty() && !hotLottery.getOfficial().get(hotLottery.getOfficial().size() - 1).getModel().equalsIgnoreCase("more")) {
            LotteryBean bean1 = new LotteryBean();
            bean1.setModel("more");
            bean1.setType("1");
            hotLottery.getOfficial().add(bean1);
        }
        this.mHotLotteryBean = hotLottery;
        mLottery = hotLottery.getTradition();
        notifyItemRangeChanged(3, mLottery.size());
    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }

    @Override
    public int getItemCount() {
        return 4 + mLottery.size();
    }

    @Override
    public void onAttachedToRecyclerView(RecyclerView recyclerView) {
        super.onAttachedToRecyclerView(recyclerView);

        RecyclerView.LayoutManager manager = recyclerView.getLayoutManager();
        if (manager instanceof GridLayoutManager) {
            final GridLayoutManager gridManager = ((GridLayoutManager) manager);
            gridManager.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
                @Override
                public int getSpanSize(int position) {
                    int type = getItemViewType(position);
                    switch (type) {
                        case 0:
                        case 1:
                        case 2:
                        case 3:
                            return 3;
                        default:
                            return 1;
                    }
                }
            });
        }
    }

    class TabHolder extends BaseViewHolder {
        private String[] mTitles_2 = {"传统玩法", "官方玩法"};
        private SkinSegmentTabLayout mSegmentTabLayout;

        public TabHolder(View itemView) {
            super(itemView);
            mSegmentTabLayout = itemView.findViewById(R.id.tab_layout);

        }

        public void bind() {
            mSegmentTabLayout.setTabData(mTitles_2);
            mSegmentTabLayout.setOnTabSelectListener(new OnTabSelectListener() {
                @Override
                public void onTabSelect(int position) {
                    mPosition = position;
                    if (position == 0) {
                        if (mHotLotteryBean != null) {
                            mLottery = mHotLotteryBean.getTradition();
                        } else {
                            mLottery.clear();
                        }
                    } else {
                        if (mHotLotteryBean == null) {
                            mLottery.clear();
                        } else {
                            mLottery = mHotLotteryBean.getOfficial();
                        }

                    }
                    notifyDataSetChanged();
                }

                @Override
                public void onTabReselect(int position) {

                }
            });
        }
    }
}
