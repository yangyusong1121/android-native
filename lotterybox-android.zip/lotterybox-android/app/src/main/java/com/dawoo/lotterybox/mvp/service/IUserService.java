package com.dawoo.lotterybox.mvp.service;

import com.dawoo.lotterybox.bean.CheckAccountBean;
import com.dawoo.lotterybox.bean.InfoMation;
import com.dawoo.lotterybox.bean.IpBean;
import com.dawoo.lotterybox.bean.LoginBean;
import com.dawoo.lotterybox.bean.OALinkBean;
import com.dawoo.lotterybox.bean.User;
import com.dawoo.lotterybox.bean.help.HelpBaseBean;
import com.dawoo.lotterybox.net.BaseHttpResult;
import com.dawoo.lotterybox.net.HttpResult;

import java.util.List;

import io.reactivex.Observable;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;

/**
 * 用户相关的接口
 *
 * @author benson
 * @date 17-12-21
 */

public interface IUserService {

    /**
     * 登录
     *
     * @return
     */
    @FormUrlEncoded
    @POST("hall/passport/login.html")
    Observable<HttpResult<LoginBean>> login(
            @Field("username") String username,
            @Field("password") String password,
            @Field("appKey") String appKey,
            @Field("appSecret") String appSecret,
            @Field("serialNo") String serialNo);

    /**
     * 注册
     *
     * @return
     */
    @FormUrlEncoded
    @POST("hall/mobile/register.html")
    Observable<HttpResult<Boolean>> register(
            @Field("username") String username,
            @Field("password") String password,
            @Field("confirmPassword") String confirmPassword,
            @Field("createChannel") String createChannel,
            @Field("playerType") String playerType,
            @Field("mode") String mode,
            @Field("promoCodeTwo") String promoCodeTwo);

    /**
     * 申请代理
     *
     * @return
     */
    @FormUrlEncoded
    @POST("hall/mobile/team/add-player.html")
    Observable<HttpResult<Boolean>> createAccount(
            @Field("username") String username,
            @Field("password") String password,
            @Field("createChannel") String createChannel,
            @Field("playerType") String playerType,
            @Field("mode") String mode);

    /**
     * 获取玩家信息
     *
     * @return
     */
    @GET("hall/mobile/account/get-user-info.html")
    Observable<HttpResult<User>> getUserInfo();

    /**
     * 用戶登出
     *
     * @return
     */
    @GET("hall/mobile/account/logout.html")
    Observable<HttpResult<Boolean>> signOut();

    @FormUrlEncoded
    @POST("hall/mobile/account/update-password.html")
    Observable<BaseHttpResult> upDatePasswold(
            @Field("oldPwd") String oldPwd,
            @Field("newPwd") String newPwd);
//account/update-nickname

    /**
     * 修改玩家昵称
     *
     * @param nickName
     * @return
     */
    @FormUrlEncoded
    @POST("hall/mobile/account/update-nickname.html")
    Observable<BaseHttpResult> upDateNickName(
            @Field("nickName") String nickName);

    /**
     * 修改玩家真实姓名
     */
    @FormUrlEncoded
    @POST("hall/mobile/account/update-real-name.html")
    Observable<BaseHttpResult> upDateRealName(
            @Field("realName") String nickName);

    /**
     * 修改安全密碼
     */
    @FormUrlEncoded
    @POST("hall/mobile/account/update-permission-password.html")
    Observable<BaseHttpResult> upDatePermissionPassword(
            @Field("permissionPwd") String permissionPwd);

    /**
     * 教研安全密码
     */
    @FormUrlEncoded
    @POST("hall/mobile/account/query-permission-password.html")
    Observable<BaseHttpResult> queryPermissionPassword(
            @Field("permissionPwd") String permissionPwd);


    @GET("hall/mobile/account/create-link-account.html")
    Observable<HttpResult<OALinkBean>> getCreateAccocuntLink();

    /**
     * 转栈姓名校验
     *
     * @param username
     * @return
     */
    @FormUrlEncoded
    @POST("hall/mobile/account/check-login-name.html")
    Observable<HttpResult<CheckAccountBean>> checkLoginName(
            @Field("username") String username);


    /**
     * 转栈真实姓名校验
     *
     * @param username
     * @return
     */
    @FormUrlEncoded
    @POST("hall/mobile/account/check-login-bankcard.html")
    Observable<HttpResult> checkAccount(
            @Field("username") String username,
            @Field("realName") String realName,
            @Field("bankCardNumber") String bankCardNumber);

    /**
     * 转栈设置登录密码
     *
     * @param username
     * @return
     */
    @FormUrlEncoded
    @POST("hall/mobile/account/do-login.html")
    Observable<HttpResult> accountPassword(
            @Field("username") String username,
            @Field("password") String password);



    /**
     * 会员申请代理
     */
    @POST("hall/mobile/account/apply-agent.html")
    Observable<BaseHttpResult> applyAgent();

    /**
     * 试玩
     * @return
     */
    @FormUrlEncoded
    @POST("hall/mobile/demo-regidt.html")
    Observable<HttpResult<LoginBean>> testAccountlogin(
            @Field("appKey") String appKey,
            @Field("appSecret") String appSecret,
            @Field("serialNo") String serialNo);

    /**
     * 帮助中心
     *
     * @return
     */
    @GET("hall/mobile/help/get-help.html")
    Observable<HelpBaseBean> getHelp();
}
