package com.dawoo.lotterybox;

import android.app.Application;
import android.content.Context;
import android.support.annotation.NonNull;

import com.blankj.utilcode.util.Utils;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.dawoo.coretool.util.packageref.PackageInfoUtil;
import com.dawoo.lotterybox.bean.DataCenter;
import com.dawoo.lotterybox.util.CrashHandler;
import com.dawoo.lotterybox.util.SkinUtils;
import com.dawoo.lotterybox.util.SoundUtil;

import com.dawoo.lotterybox.util.lottery.initdata.CQSSCGFWanFaUtil;
import com.dawoo.lotterybox.view.view.error.Error401Callback;
import com.dawoo.lotterybox.view.view.error.Error403Callback;
import com.dawoo.lotterybox.view.view.error.Error404Callback;
import com.dawoo.lotterybox.view.view.error.Error603Callback;
import com.dawoo.lotterybox.view.view.error.Error604Callback;
import com.dawoo.lotterybox.view.view.error.Error605Callback;
import com.dawoo.lotterybox.view.view.error.Error607Callback;
import com.dawoo.lotterybox.view.view.error.ErrorBusyCallback;
import com.dawoo.lotterybox.view.view.error.ErrorNetWorkCallback;
import com.dawoo.lotterybox.view.view.error.ErrorNoDataCallback;
import com.dawoo.lotterybox.view.view.swipetoloadlayout.SmartRefreshHeader;
import com.example.pushsdk.client.WebSocketClient;
import com.kingja.loadsir.callback.SuccessCallback;
import com.kingja.loadsir.core.LoadSir;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.DefaultRefreshFooterCreator;
import com.scwang.smartrefresh.layout.api.DefaultRefreshHeaderCreator;
import com.scwang.smartrefresh.layout.api.RefreshFooter;
import com.scwang.smartrefresh.layout.api.RefreshHeader;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.footer.ClassicsFooter;
import com.squareup.leakcanary.LeakCanary;

import skin.support.SkinCompatManager;
import skin.support.app.SkinCardViewInflater;
import skin.support.constraint.app.SkinConstraintViewInflater;
import skin.support.design.app.SkinMaterialViewInflater;

/**
 * Created by benson on 17-12-27.
 */

public class BoxApplication extends Application {
    private static Context context;
    public static int HttpStateCode = 0;

    public RequestOptions hallOptions;//Glide加载彩种图片，默认配置项

    public RequestOptions getHallOptions() {
        return hallOptions;
    }


    //static 代码段可以防止内存泄露
    static {
        //设置全局的Header构建器
        SmartRefreshLayout.setDefaultRefreshHeaderCreator(new DefaultRefreshHeaderCreator() {
            @NonNull
            @Override
            public RefreshHeader createRefreshHeader(@NonNull Context context, @NonNull RefreshLayout layout) {
                layout.setPrimaryColorsId(R.color.bgColor);
                return new SmartRefreshHeader(context);
            }
        });
        //设置全局的Footer构建器
        SmartRefreshLayout.setDefaultRefreshFooterCreator(new DefaultRefreshFooterCreator() {
            @Override
            public RefreshFooter createRefreshFooter(Context context, RefreshLayout layout) {
                //指定为经典Footer，默认是 BallPulseFooter
                return new ClassicsFooter(context).setDrawableSize(20);
            }
        });

    }

    @Override
    public void onCreate() {
        super.onCreate();
        Utils.init(this);
        context = getApplicationContext();
        LoadSir.beginBuilder()
                .addCallback(new Error401Callback())
                .addCallback(new Error403Callback())
                .addCallback(new Error404Callback())
                .addCallback(new Error603Callback())
                .addCallback(new Error604Callback())
                .addCallback(new Error605Callback())
                .addCallback(new Error607Callback())
                .addCallback(new ErrorBusyCallback())
                .addCallback(new ErrorNetWorkCallback())
                .addCallback(new ErrorNoDataCallback())
                .setDefaultCallback(SuccessCallback.class)
                .commit();
        SkinCompatManager.withoutActivity(this)
                .addInflater(new SkinMaterialViewInflater())
                .addInflater(new SkinConstraintViewInflater())
                .addInflater(new SkinCardViewInflater())
                .loadSkin();
        SkinCompatManager.getInstance().loadSkin(SkinUtils.getSkinName(this),
                SkinCompatManager.SKIN_LOADER_STRATEGY_ASSETS);

        if (BuildConfig.DEBUG) {
            if (LeakCanary.isInAnalyzerProcess(this)) {
                // This process is dedicated to LeakCanary for heap analysis.
                // You should not init your app in this process.
                return;
            }
            LeakCanary.install(this);
        }

        //  DataCenter.getInstance().setDomain(BuildConfig.HOST_URL).setImgDomain(BuildConfig.HOST_IMG_URL);
        DataCenter.getInstance().getSysInfo().initSysInfo(
                PackageInfoUtil.getVersionName(context),
                PackageInfoUtil.getVersionCode(context),
                PackageInfoUtil.getUniqueId(context));
        CrashHandler.getInstance().init(); // 错误日志处理
        SoundUtil.getInstance().load(ConstantValue.VOICE_ON_CLICK, R.raw.anjian);

        //彩种占位图配置
        hallOptions = new RequestOptions()
                .placeholder(R.mipmap.ic_default_hall)    //加载成功之前占位图
                .error(R.mipmap.ic_default_hall)    //加载错误之后的错误图
                .fitCenter()
                .circleCrop()//指定图片的缩放类型为centerCrop （圆形）
                .skipMemoryCache(false)
                .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)    //根据图片资源智能地选择使用哪一种缓存策略（默认选项）
        ;
        WebSocketClient.getInstance().init(this);
    }




    /**
     * 获取全局上下文
     */
    public static Context getContext() {
        return context;
    }

}
