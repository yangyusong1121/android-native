package com.dawoo.lotterybox.util;

import com.dawoo.coretool.util.math.BigDemicalUtil;

import org.apache.http.util.TextUtils;

import java.math.RoundingMode;
import java.text.DecimalFormat;

/**
 * Created by rain on 18-5-10.
 */

public class BalanceUtils {
    static DecimalFormat df = new DecimalFormat("0.000");

    /**
     * 获取double金额
     *
     * @param inBalance
     * @return
     */
    public static double getDouble(String inBalance) {

        double outBalance = 0.00;
        if (!TextUtils.isEmpty(inBalance)) {
            outBalance = Double.parseDouble(inBalance.replaceAll(",", ""));
        }
        return BigDemicalUtil.round(outBalance, 3);
    }

    /**
     * 获取规则String
     *
     * @param inBalance
     * @return
     */
    public static String getScalsBalance(String inBalance) {
        if (TextUtils.isEmpty(inBalance)) {
            return "0.000";
        }
        double d = Double.parseDouble(inBalance.replaceAll(",", ""));
        df.setRoundingMode(RoundingMode.DOWN);
        df.setGroupingSize(3);
        df.setGroupingUsed(true);
        return df.format(d);
    }

    public static String getScalsBalance(double inBalance) {
        df.setRoundingMode(RoundingMode.DOWN);
        df.setGroupingUsed(true);
        df.setGroupingSize(3);
        if (inBalance == 0) {
            return "--";
        }
        return df.format(inBalance);
    }

    /**
     * 保留3位小数
     *
     * @param inBalance
     * @return
     */
    public static String getThreeBalance(String inBalance) {
        if (TextUtils.isEmpty(inBalance)) {
            return "0.000";
        }
        return new DecimalFormat("###,##0.000").format(Double.parseDouble(inBalance.replaceAll(",", "")));
    }

    public static String getThreeBalance(double inBalance) {

        return new DecimalFormat("###,##0.000").format(inBalance);
    }
}
