package com.dawoo.lotterybox.view.activity.chart.k3;

import android.support.annotation.Nullable;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.ViewPager;

import com.dawoo.lotterybox.ConstantValue;
import com.dawoo.lotterybox.R;
import com.dawoo.lotterybox.bean.lottery.Handicap;
import com.dawoo.lotterybox.util.lottery.LotteryUtil;
import com.dawoo.lotterybox.view.activity.chart.BaseChartActivity;
import com.dawoo.lotterybox.view.fragment.BaseFragment;

import com.dawoo.lotterybox.view.view.HeaderView;
import com.hwangjr.rxbus.RxBus;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;


/**
 * Created by b on 18-4-24.
 * k3走势图
 */

public class K3TrendChartActivity extends BaseChartActivity {
    @BindView(R.id.head_view)
    HeaderView mHeadView;
    @BindView(R.id.tab_layout)
    TabLayout mTabLayout;
    @BindView(R.id.view_pager)
    ViewPager mViewPager;

    List<BaseFragment> fragments = new ArrayList<>();


    @Override
    protected void createLayoutView() {
        setContentView(R.layout.activity_k3_trend_chart);
    }

    @Override
    protected void initViews() {

    }

    @Override
    protected void initData() {
        super.initData();
        mHeadView.setHeader(mLotteryName, true);
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (mRencentList == null||mRencentList.isEmpty()) {
                    mPresenter.getResultByCode();
                    return ;
                }
                List<String> titles = new ArrayList<>();
                titles.add("开奖");
                titles.add("基本走势");
                titles.add("和值走势");
                titles.add("冷热");
                initFragment();
                mViewPager.setOffscreenPageLimit(3);
                ChartViewPagerAdapter chartViewPagerAdapter = new ChartViewPagerAdapter(getSupportFragmentManager(), fragments, titles);
                mViewPager.setAdapter(chartViewPagerAdapter);
                mTabLayout.setupWithViewPager(mViewPager);
                mProgressDialog.dismiss();
            }
        }, 50);
    }

    @Override
    public void refreshViews() {
        super.refreshViews();
        RxBus.get().post(ConstantValue.EVENT_TYPE_OPENING_LOTTERY, "opened");
    }

    public ArrayList<Handicap> getmRencentList() {
        return mRencentList;
    }


    private void initFragment() {
        K3OpenFragment k3OpenFragment = K3OpenFragment.newInstance(mRencentList);
        fragments.add(k3OpenFragment);
        K3BasicTrendFragment k3BasicTrendFragment = K3BasicTrendFragment.newInstance(mRencentList);
        fragments.add(k3BasicTrendFragment);
        K3SumTrendFragment k3SumTrendFragment = K3SumTrendFragment.newInstance(mRencentList);
        fragments.add(k3SumTrendFragment);
        K3ColdHotFragment k3ColdHotFragment = K3ColdHotFragment.newInstance(mRencentList);
        fragments.add(k3ColdHotFragment);
    }



    class ChartViewPagerAdapter extends FragmentStatePagerAdapter {
        List<BaseFragment> fragments;
        List<String> titles;

        public ChartViewPagerAdapter(FragmentManager fm, List<BaseFragment> fragments, List<String> titles) {
            super(fm);
            this.fragments = fragments;
            this.titles = titles;
        }


        @Override
        public Fragment getItem(int position) {
            return fragments.get(position);
        }

        @Override
        public int getCount() {
            return fragments.size();
        }

        @Nullable
        @Override
        public CharSequence getPageTitle(int position) {
            return titles.get(position);
        }
    }
}
