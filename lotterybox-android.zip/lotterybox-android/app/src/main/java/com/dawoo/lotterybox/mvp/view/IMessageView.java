package com.dawoo.lotterybox.mvp.view;


/**
 * Created by benson on 17-12-21.
 */

public interface IMessageView extends IMessageBaseView {

    void onDeleteMsg(Object o);

}

