package com.dawoo.lotterybox.util;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.net.SSLCertificateSocketFactory;
import android.os.Build;
import android.text.TextUtils;
import android.util.Log;

import com.blankj.utilcode.util.LogUtils;
import com.blankj.utilcode.util.NetworkUtils;
import com.blankj.utilcode.util.SPUtils;
import com.dawoo.lotterybox.BuildConfig;
import com.dawoo.lotterybox.R;
import com.dawoo.lotterybox.bean.DataCenter;
import com.dawoo.lotterybox.bean.IpBean;
import com.dawoo.lotterybox.mvp.presenter.UserPresenter;
import com.dawoo.lotterybox.mvp.view.IIpView;
import com.dawoo.lotterybox.net.rx.DefaultCallback;
import com.google.gson.Gson;

import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.security.cert.CertificateException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLPeerUnverifiedException;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * @author alex
 */
public class IpConnectHelper {
    private IpConnectCallback ipConnectCallback;
    private String mAppHost = "";
    private OkHttpClient okHttpClient;
    public static final String HTTP = "http://";
    public static final String HTTPS = "https://";
    private static final String CHECK = "__check";
    private static final String IMG = "fserver/files";
    private static final String OK = "OK";
    private static final String HTTP_PORT = ":8383";
    public static final String HTTPS_PORT = ":8585";
    public int i = -1;
    private OkHttpClient.Builder builder;

    public void startConnect(Activity context) {
        if (context instanceof IpConnectCallback) {
            this.ipConnectCallback = (IpConnectCallback) context;
        }
        String host = SPUtils.getInstance().getString(SPConfig.HSOT);
        String domain = SPUtils.getInstance().getString(SPConfig.Domain);
        if (Objects.equals("",host)||Objects.equals("",domain)) {
            ipConnectCallback.startConnecting();
            getLine(context);
        } else {
            i = -1;
            List<String> hosts = new ArrayList<>();
            hosts.add(host + CHECK);
            List<String> doamins = new ArrayList<>();
            doamins.add(domain);
            checkIpOrDomain(hosts, doamins);
        }


    }

    public void getLine(Activity context) {
        if (!NetworkUtils.isConnected()) {
            ipConnectCallback.failureConnected("网络未链接请检查后重试");
            return;
        }
        i = -1;
        if (okHttpClient == null) {
            okHttpClient = getUnsafeOkHttpClient();
        }
        String url = BuildConfig.BASE_URL + "/app/line.html?key=" + context.getResources().getString(R.string.app_sid) + "&code=" + context.getResources().getString(R.string.app_code);
        LogUtils.e("url:" + url);
        Request request = new Request.Builder()
                .get()
                .url(url)
                .build();
        okHttpClient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                ipConnectCallback.failureConnected("获取线路返回错误");
                LogUtils.e("失败" + e.getMessage());
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String responseString = response.body().string();
                if (responseString == null || "".equals(responseString)) {
                    ipConnectCallback.failureConnected("服务器返回为空");
                } else {
                    //有东西，json解析
                    IpBean ipBean = GsonUtil.GsonToBean(responseString, IpBean.class);
                    if (ipBean == null || ipBean.getData() == null) {
                        ipConnectCallback.failureConnected("无可用线路列表");
                        return;
                    }
                    List<IpBean.DataBean> datas = ipBean.getData();
                    if (ipBean.getData().size() == 0) {
                        //没有返回线路
                        ipConnectCallback.failureConnected("线路列表为空");
                    } else {
                        //返回线路进行check操作
                        if (isUseIp(context)) {
                            //用ip
                            useIp(datas);
                        } else {
                            //用域名
                            useDomain(datas);
                        }

                    }
                }
            }
        });
    }


    private void useIp(List<IpBean.DataBean> datas) {
        //字符串拼接check
        List<String> ips = new ArrayList<>();
        List<String> demands = new ArrayList<>();
        for (int i = 0; i < datas.size(); i++) {
            String ip = datas.get(i).getIp();
            String domain = datas.get(i).getDomain();
            //http加端口
            String host_http = HTTP + ip + HTTP_PORT + "/" + CHECK;
            //https加端口
            String host_https = HTTPS + ip + HTTPS_PORT + "/" + CHECK;
            //http不加端口
            String host_http_no_port = HTTP + ip + "/" + CHECK;
            //https不加端口
            String hosts_no_port = HTTPS + ip + "/" + CHECK;
            demands.add(domain);
            demands.add(domain);
            demands.add(domain);
            demands.add(domain);
            ips.add(host_http);
            ips.add(host_https);
            ips.add(host_http_no_port);
            ips.add(hosts_no_port);
        }
        //test code
//        ips.add(HTTP + "1.32.208.63" + HTTP_PORT + "/" + CHECK);
//        demands.add("love017.com");
//        LogUtils.e("check_ip_test:" + ips.get(1));
//        LogUtils.e("trying_ip_test:" + demands.get(1));
        checkIpOrDomain(ips, demands);


    }

    private void useDomain(List<IpBean.DataBean> datas) {
        ArrayList<String> domains = new ArrayList<>();
        List<String> doaminss = new ArrayList<>();
        for (int i = 0; i < datas.size(); i++) {
            String domain = datas.get(i).getDomain();
            //http加端口
            String host_http = HTTP + domain + HTTP_PORT + "/" + CHECK;
            //https加端口
            String host_https = HTTPS + domain + HTTPS_PORT + "/" + CHECK;
            //http不加端口
            String host_http_no_port = HTTP + domain + "/" + CHECK;
            //https不加端口
            String hosts_no_port = HTTPS + domain + "/" + CHECK;
            domains.add(host_http);
            domains.add(host_https);
            domains.add(host_http_no_port);
            domains.add(hosts_no_port);
            doaminss.add(domain);
            doaminss.add(domain);
            doaminss.add(domain);
            doaminss.add(domain);
        }
        checkIpOrDomain(domains, doaminss);
    }


    public interface IpConnectCallback {
        /**
         * 开始链接的回调
         */
        void startConnecting();

        /**
         * 链接成功的回调
         */
        void succeedConnected();

        /**
         * 失败的回调
         *
         * @param message 　返回错误信息
         */
        void failureConnected(String message);
    }

    /**
     * 不安全的链接，用通用的SSL也无法验证，先跳过验证。
     */
    private static OkHttpClient getUnsafeOkHttpClient() {
        try {
            final TrustManager[] trustAllCerts = new TrustManager[]{
                    new X509TrustManager() {
                        @SuppressLint("TrustAllX509TrustManager")
                        @Override
                        public void checkClientTrusted(java.security.cert.X509Certificate[] chain, String authType) {
                        }

                        @SuppressLint("TrustAllX509TrustManager")
                        @Override
                        public void checkServerTrusted(java.security.cert.X509Certificate[] chain, String authType) {
                        }

                        @Override
                        public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                            return new java.security.cert.X509Certificate[0];
                        }
                    }
            };

            final SSLContext sslContext = SSLContext.getInstance("SSL");
            sslContext.init(null, trustAllCerts, new java.security.SecureRandom());
            final SSLSocketFactory sslSocketFactory = sslContext.getSocketFactory();
            HostnameVerifier verifier = (hostname, session) -> true;
            return new OkHttpClient.Builder()
                    .sslSocketFactory(sslSocketFactory)
                    .hostnameVerifier(verifier)
                    .build();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    public static boolean isUseIp(Context context) {
        return "ip".equals(context.getString(R.string.connect_type));
    }

    /**
     * 串型进行校验,该方法是控制器，如果有多种情况，请先将数据整理传入。
     *
     * @param ips check的线路，domain就是对应的域名，如果是域名直接，直接传入域名
     */
    private void checkIpOrDomain(List<String> ips, List<String> domains) {
        i++;
        if (i == domains.size()) {
            ipConnectCallback.failureConnected("检测线路不通过");
            return;
        }
        if (i == ips.size()) {
            ipConnectCallback.failureConnected("检测线路不通过");
            return;
        }
        if (ips.get(i) == null||ips.get(i).isEmpty()) {
            checkIpOrDomain(ips, domains);
            return;
        }
        if (builder == null) {
            builder = new OkHttpClient.Builder();
        }
        LogUtils.e("Head_Host:" + domains.get(i));
        Request request = new Request.Builder().url(ips.get(i)).addHeader("Host", domains.get(i) == null ? "" : domains.get(i)).get().build();
        Call call = builder.build().newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                //失败，就换一条
                checkIpOrDomain(ips, domains);
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String responsedString = response.body().string();
                if (responsedString == null || "".equals(responsedString)) {
                    //失败
                    checkIpOrDomain(ips, domains);
                } else {
                    if (responsedString.contains(OK)) {
                        //成功
                        mAppHost = ips.get(i);
                        String domain = domains.get(i);
                        mAppHost = mAppHost.replace(CHECK, "");
                        SPUtils.getInstance().put(SPConfig.HSOT, mAppHost);
                        SPUtils.getInstance().put(SPConfig.Domain, domain);
                        DataCenter.getInstance().setDomain(domain).setImgDomain(mAppHost + IMG);
                        DataCenter.getInstance().setHost(mAppHost);
                        ipConnectCallback.succeedConnected();
                    } else {
                        //失败　换一条
                        checkIpOrDomain(ips, domains);
                    }
                }
                }
        });
    }


}
