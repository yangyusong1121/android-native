package com.dawoo.lotterybox.view.activity;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.dawoo.lotterybox.R;
import com.dawoo.lotterybox.util.MSPropties;
import com.dawoo.lotterybox.view.view.HeaderView;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * @author jack
 * @date 18-2-9
 * 分享礼金
 */

public class ShareGiftsActivity extends BaseActivity implements OnRefreshListener, OnLoadMoreListener {
    @BindView(R.id.head_view)
    HeaderView headView;
    @BindView(R.id.textView3)
    TextView textView3;
    @BindView(R.id.textView4)
    TextView textView4;
    @BindView(R.id.imageView)
    ImageView imageView;
    @BindView(R.id.textView5)
    TextView textView5;
    @BindView(R.id.textView7)
    TextView textView7;
    @BindView(R.id.next_day)
    TextView nextDay;
    @BindView(R.id.next_money)
    TextView nextMoney;
    @BindView(R.id.swipe_target)
    RecyclerView swipeTarget;
    private Context context;
    @BindView(R.id.srl_root)
    SmartRefreshLayout srlRefresh;

    private ShareGigtAdapter shareGiftsAdapter;


    @Override
    protected void createLayoutView() {
        setContentView(R.layout.activity_sharegifts);
    }

    @Override
    protected void initViews() {
        headView.setHeader(getResources().getString(R.string.sharegifs_title), true);
        context = this;
    }

    @Override
    protected void initData() {
        swipeTarget.setLayoutManager(new LinearLayoutManager(context));
        shareGiftsAdapter = new ShareGigtAdapter(R.layout.item_sharegifts_activity);
        shareGiftsAdapter.setEmptyView(LayoutInflater.from(this).inflate(R.layout.empty_view, null));
        swipeTarget.setAdapter(shareGiftsAdapter);
        srlRefresh.setOnRefreshListener(this);
        srlRefresh.setOnLoadMoreListener(this);
        //  MSPropties.setSwipeToLoadLayout(context, swipeToLoadLayout);
    }


    @OnClick({R.id.head_view, R.id.textView3, R.id.textView4, R.id.imageView, R.id.textView5, R.id.textView7})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.head_view:
                break;
            case R.id.textView3:
                break;
            case R.id.textView4:
                break;
            case R.id.imageView:
                break;
            case R.id.textView5:
                break;
            case R.id.textView7:
                break;
            default:
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }


    @Override
    public void onLoadMore(@NonNull RefreshLayout refreshLayout) {

    }

    @Override
    public void onRefresh(@NonNull RefreshLayout refreshLayout) {

    }


    class ShareGigtAdapter extends BaseQuickAdapter {

        public ShareGigtAdapter(int layoutResId) {
            super(layoutResId);
        }

        @Override
        protected void convert(BaseViewHolder helper, Object item) {

        }

        @Override
        public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {

        }
    }
}
