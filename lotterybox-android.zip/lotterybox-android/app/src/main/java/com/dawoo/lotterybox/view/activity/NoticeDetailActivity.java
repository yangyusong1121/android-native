package com.dawoo.lotterybox.view.activity;

import com.dawoo.lotterybox.R;

/**
 * Created by b on 18-4-22.
 * 公告详情
 */

public class NoticeDetailActivity extends BaseActivity {
    @Override
    protected void createLayoutView() {
        setContentView(R.layout.activity_notice_detail);
    }

    @Override
    protected void initViews() {

    }

    @Override
    protected void initData() {

    }
}
