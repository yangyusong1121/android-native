package com.dawoo.lotterybox.bean.message;

public class SubirdinateNumberBean {

    /**
     * error : 0
     * data : {"agent":2,"member":1}
     */

    private int error;
    private DataBean data;

    public int getError() {
        return error;
    }

    public void setError(int error) {
        this.error = error;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public static class DataBean {
        /**
         * agent : 2
         * member : 1
         */

        private int agent; //下级代理数量
        private int member; //下级会员数量

        public int getAgent() {
            return agent;
        }

        public void setAgent(int agent) {
            this.agent = agent;
        }

        public int getMember() {
            return member;
        }

        public void setMember(int member) {
            this.member = member;
        }
    }
}
