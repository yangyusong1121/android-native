package com.dawoo.lotterybox.adapter.lhc;

import android.os.Build;
import android.support.annotation.RequiresApi;
import android.view.View;
import android.widget.TextView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.dawoo.lotterybox.BoxApplication;
import com.dawoo.lotterybox.R;
import com.dawoo.lotterybox.bean.playtype.PlayChooseBean;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 *
 * @author rain
 * @date 18-3-8
 */

public class LHCTopTypeAdapter extends BaseQuickAdapter<PlayChooseBean,LHCTopTypeAdapter.LHZHolder>{
    public LHCTopTypeAdapter(int layoutResId) {
        super(layoutResId);
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void convert(LHZHolder helper, PlayChooseBean item) {
        helper.itemView.setSelected(item.isSelected());
        helper.tvType.setText(item.getBetName());
        if(!item.isSelected()){
            helper.tvType.setTextColor(BoxApplication.getContext().getResources().getColor(R.color.color_gray_666666));
        }else{
            helper.tvType.setTextColor(BoxApplication.getContext().getResources().getColor(R.color.white));
        }
    }

    class LHZHolder extends BaseViewHolder{
        @BindView(R.id.tv_top_type)
        TextView tvType;
        public LHZHolder(View view) {
            super(view);
            ButterKnife.bind(this,view);
        }
    }
}
