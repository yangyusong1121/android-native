package com.dawoo.lotterybox.bean.record;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;
import java.util.List;

public class BillItemPrentBean implements Parcelable {

    /**
     * error : 0
     * data : [{"completionTime":1530512687961,"item":"game_bet","balance":9882,"money":-50,"type":"game_expend","way":"game"},{"completionTime":1530512652059,"item":"game_bet","balance":9932,"money":-10,"type":"game_expend","way":"game"},{"completionTime":1530512637201,"item":"game_bet","balance":9942,"money":-2,"type":"game_expend","way":"game"},{"completionTime":1530512629695,"item":"game_bet","balance":9944,"money":-2,"type":"game_expend","way":"game"},{"completionTime":1530512391203,"item":"game_bet","balance":9946,"money":-14,"type":"game_expend","way":"game"},{"completionTime":1530512373472,"item":"game_bet","balance":9960,"money":-4,"type":"game_expend","way":"game"},{"completionTime":1530510343914,"item":"game_bet","balance":9964,"money":-4,"type":"game_expend","way":"game"}]
     * extend : {"totalCount":7}
     */

    private int error;
    private ExtendBean extend;
    private List<BillItemBean> data;

    public int getError() {
        return error;
    }

    public void setError(int error) {
        this.error = error;
    }

    public ExtendBean getExtend() {
        return extend;
    }

    public void setExtend(ExtendBean extend) {
        this.extend = extend;
    }

    public List<BillItemBean> getData() {
        return data;
    }

    public void setData(List<BillItemBean> data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "BillItemPrentBean{" +
                "error=" + error +
                ", extend=" + extend +
                ", data=" + data +
                '}';
    }

    public static class ExtendBean implements  Parcelable{
        /**
         * totalCount : 7
         */

        private int totalCount;

        public int getTotalCount() {
            return totalCount;
        }

        public void setTotalCount(int totalCount) {
            this.totalCount = totalCount;
        }

        @Override
        public int describeContents() {
            return 0;
        }

        @Override
        public void writeToParcel(Parcel dest, int flags) {
            dest.writeInt(this.totalCount);
        }

        public ExtendBean() {
        }

        protected ExtendBean(Parcel in) {
            this.totalCount = in.readInt();
        }

        public static final Creator<ExtendBean> CREATOR = new Creator<ExtendBean>() {
            @Override
            public ExtendBean createFromParcel(Parcel source) {
                return new ExtendBean(source);
            }

            @Override
            public ExtendBean[] newArray(int size) {
                return new ExtendBean[size];
            }
        };

        @Override
        public String toString() {
            return "ExtendBean{" +
                    "totalCount=" + totalCount +
                    '}';
        }
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(this.error);
        dest.writeParcelable(this.extend, flags);
        dest.writeList(this.data);
    }

    public BillItemPrentBean() {
    }

    protected BillItemPrentBean(Parcel in) {
        this.error = in.readInt();
        this.extend = in.readParcelable(ExtendBean.class.getClassLoader());
        this.data = new ArrayList<BillItemBean>();
        in.readList(this.data, BillItemBean.class.getClassLoader());
    }

    public static final Creator<BillItemPrentBean> CREATOR = new Creator<BillItemPrentBean>() {
        @Override
        public BillItemPrentBean createFromParcel(Parcel source) {
            return new BillItemPrentBean(source);
        }

        @Override
        public BillItemPrentBean[] newArray(int size) {
            return new BillItemPrentBean[size];
        }
    };
}
