package com.dawoo.lotterybox.mvp.model.main;

import com.dawoo.lotterybox.bean.UpdateInfo;
import com.dawoo.lotterybox.mvp.model.BaseModel;
import com.dawoo.lotterybox.mvp.service.IMainService;
import com.dawoo.lotterybox.net.RetrofitHelper;

import io.reactivex.Observable;
import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;


/**
 * Created by b on 18-2-16.
 */

public class MainModel extends BaseModel implements IMainModel {

    @Override
    public Disposable getVersionsData(Observer subscriber, int versionCode) {
        Observable<UpdateInfo> observable = RetrofitHelper
                .getService(IMainService.class)
                .getVersionsData(versionCode)
                .map(new BaseModel.HttpResultFunc<>());
        return toSubscribe(observable, subscriber);
    }
}
