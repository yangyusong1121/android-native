package com.dawoo.lotterybox.net.rx;

public interface ProgressCancelListener {
    void onCancelProgress();
}
