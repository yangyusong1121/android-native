package com.dawoo.lotterybox.mvp.model.record;


import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;
import retrofit2.http.Query;


/**
 * Created by benson on 17-12-21.
 */

public interface IRecordModel {
    /**
     * 获取投注记录
     */

    Disposable getOrders(Observer Observer, String code, String expect,
                         String status, String queryStartDate, String queryEndDate,
                         String pageSize, String pageNumber, String playModel, String order, String property);

    /**
     * 获取所有彩种
     */

    Disposable getLottery(Observer Observer);

    /**
     * 获取下注总金额，派彩总金额（注单合计）
     */

    Disposable getAssets(Observer Observer, String queryStartDate, String queryEndDate, String status, String code);

    /**
     * 获取30天的盈亏数据
     */
    Disposable getRecentProfit(Observer Observer, String status, String code);

    /**
     * 获取注单详细
     */
    Disposable getOrderDetail(Observer Observer, String id, String orign);

    Disposable getRechargeAmountDisplay(Observer Observer, String type, String item,
                                          String startData, String endData);

    Disposable getWithDrawsAmountDisplay(Observer Observer, String type, String item,
                                           String startData, String endData);

    Disposable getBillchangeChanges(Observer Observer, int pageNum, String startData, String endData,
                                      String way, String type, String item, String order, String property);

    Disposable getBillchangeAssets(Observer Observer, String startData, String endData);


    Disposable getOrderGroup(Observer Observer, String startData, String endData);


    Disposable getRechargeRecords(Observer Observer, String type, String item,
                                    String startData, String endData, String order, String property);


    Disposable getWithDrawsRecords(Observer Observer, String type, String item,
                                     String startData, String endData,String order, String property);

}
