package com.dawoo.lotterybox.mvp.view;

import com.dawoo.lotterybox.bean.lottery.OrderInfo;
import com.dawoo.lotterybox.bean.record.NoteRecordHisData;


/**
 * Created by b on 18-4-18.
 */

public interface IOrderView extends IBaseView {
    void onOrderResult(OrderInfo o);

    void onRecords(NoteRecordHisData recordHis);

    void onCustomers(Object o);
}
