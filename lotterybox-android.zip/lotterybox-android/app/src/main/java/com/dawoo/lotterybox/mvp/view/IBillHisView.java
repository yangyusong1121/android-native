package com.dawoo.lotterybox.mvp.view;

import com.dawoo.lotterybox.bean.BillAmountBean;
import com.dawoo.lotterybox.bean.record.AssetsBean;
import com.dawoo.lotterybox.bean.record.BillCommonBean;
import com.dawoo.lotterybox.bean.record.BillItemBean;
import com.dawoo.lotterybox.bean.record.BillItemPrentBean;

import java.util.List;

/**
 * Created by rain on 18-4-19.
 */

public interface  IBillHisView extends IBaseView {
    void getBillsData(BillItemPrentBean mDatas);
    void getBillCount(BillCommonBean o);
    void getBillAmount(BillAmountBean o);
}
