package com.dawoo.lotterybox.bean;

import android.os.Parcel;
import android.os.Parcelable;

public class CheckMemberTypeBean implements Parcelable {
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    private int id;
    /**
     * 创建时间
     */
    private long createTime;

    public long getApplyTime() {
        return applyTime;
    }

    public void setApplyTime(long applyTime) {
        this.applyTime = applyTime;
    }

    /**
     * 申请审核时间
     */
    private long applyTime;
    /**
     * 余额
     */

    private String balance;

    /**
     * 名称
     */
    private String username;

    public long getCreateTime() {
        return createTime;
    }

    public void setCreateTime(long createTime) {
        this.createTime = createTime;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getBalance() {
        return balance;
    }

    public void setBalance(String balance) {
        this.balance = balance;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(this.id);
        dest.writeLong(this.createTime);
        dest.writeLong(this.applyTime);
        dest.writeString(this.username);
        dest.writeString(this.balance);
    }

    protected CheckMemberTypeBean(Parcel in) {
        this.id = in.readInt();
        this.createTime = in.readLong();
        this.applyTime = in.readLong();
        this.username = in.readString();
        this.balance = in.readString();
    }

    public static final Creator<CheckMemberTypeBean> CREATOR = new Creator<CheckMemberTypeBean>() {
        @Override
        public CheckMemberTypeBean createFromParcel(Parcel source) {
            return new CheckMemberTypeBean(source);
        }

        @Override
        public CheckMemberTypeBean[] newArray(int size) {
            return new CheckMemberTypeBean[size];
        }
    };

    @Override
    public String toString() {
        return "CheckMemberTypeBean{" +
                "id=" + id +
                ", createTime='" + createTime + '\'' +
                ", applyTime=" + applyTime +
                ", balance='" + balance + '\'' +
                ", username='" + username + '\'' +
                '}';
    }
}
