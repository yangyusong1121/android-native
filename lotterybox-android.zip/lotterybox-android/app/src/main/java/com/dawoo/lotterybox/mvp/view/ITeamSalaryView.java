package com.dawoo.lotterybox.mvp.view;

import com.dawoo.lotterybox.bean.TeamSalaryBean;

/**
 * Created by alex on 18-4-24.
 */

public interface ITeamSalaryView extends IBaseView {
    void onSalaryResult(TeamSalaryBean o);

    void onSaveTeamSalaryResult(Boolean o);
}
