package com.dawoo.lotterybox.mvp.model.withdraws;

import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;
import rx.Subscriber;
import rx.Subscription;

/**
 * Created by alex on 18-4-5.
 *
 * @author alex
 */

public interface IWithDrawsModel {


    Disposable bankcardList(Observer subscriber);

    Disposable getBanks(Observer subscriber);

    Disposable bindBankCard(Observer subscriber, String bankCode, String bankName, String cardNumber, String masterName);

    Disposable getWithDrawsFee(Observer subscriber, String money);

    Disposable withDrawsInit(Observer subscriber);

    Disposable withDrawsAudit(Observer subscriber);
    Disposable withDrawsAuditDetail(Observer subscriber,String id);

    Disposable applyWithDraws(Observer subscriber, String withdrawAmount,String token);
}
