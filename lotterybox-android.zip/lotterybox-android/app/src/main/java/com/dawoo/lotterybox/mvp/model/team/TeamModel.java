package com.dawoo.lotterybox.mvp.model.team;

import com.dawoo.lotterybox.bean.CheckMemberTypeBean;
import com.dawoo.lotterybox.bean.SaveMemberTypeBean;
import com.dawoo.lotterybox.bean.TeamAssetsBean;
import com.dawoo.lotterybox.bean.TeamBillBean;
import com.dawoo.lotterybox.bean.TeamMemberBean;
import com.dawoo.lotterybox.bean.TeamParticipationBean;
import com.dawoo.lotterybox.bean.TeamReportBean;
import com.dawoo.lotterybox.bean.TeamSalaryBean;
import com.dawoo.lotterybox.bean.TeamStateBean;
import com.dawoo.lotterybox.bean.TeamhasRatioBean;
import com.dawoo.lotterybox.mvp.model.BaseModel;
import com.dawoo.lotterybox.mvp.service.ITeamService;
import com.dawoo.lotterybox.net.HttpResult;
import com.dawoo.lotterybox.net.RetrofitHelper;

import java.util.List;

import io.reactivex.Observable;
import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;


/**
 * Created by alex on 18-4-24.
 *
 * @author alex
 */

public class TeamModel extends BaseModel implements ITeamModel {
    @Override
    public Disposable getTeamDataAssets(Observer Observer, String startDate, String endDate) {
        Observable<TeamAssetsBean> observable = RetrofitHelper.getService(ITeamService.class).getTeamDataAssets(startDate, endDate).map(new HttpResultFunc<>());
        return toSubscribe(observable, Observer);
    }

    @Override
    public Disposable getTeamDataState(Observer Observer, String startDate, String endDate, int dateFlag) {
        Observable<TeamStateBean> observable = RetrofitHelper.getService(ITeamService.class).getTeamDataState(startDate, endDate, dateFlag).map(new HttpResultFunc<>());
        return toSubscribe(observable, Observer);
    }

    @Override
    public Disposable getTeamDataStateSearch(Observer Observer, String startDate, String endDate) {
        Observable<TeamStateBean> observable = RetrofitHelper.getService(ITeamService.class).getTeamDataStateSearch(startDate, endDate, "-1").map(new HttpResultFunc<>());
        return toSubscribe(observable, Observer);
    }

    @Override
    public Disposable getTeamMember(Observer Observer, String startDate, String endDate, String playerType, String pageSize, String pageNumber) {
        Observable<List<TeamMemberBean>> observable = RetrofitHelper.getService(ITeamService.class).getTeamMember(startDate, endDate, playerType, pageSize, pageNumber).map(new HttpResultFunc<>());
        return toSubscribe(observable, Observer);
    }

    @Override
    public Disposable getTeamMember(Observer Observer, String playerType, String pageSize, String pageNumber, String name) {
        Observable<List<TeamMemberBean>> observable = RetrofitHelper.getService(ITeamService.class).getTeamMember(playerType, pageSize, pageNumber, name).map(new HttpResultFunc<>());
        return toSubscribe(observable, Observer);
    }

    @Override
    public Disposable getTeamReport(Observer Observer, String startDate, String endDate, String pageSize, String pageNumber) {
        Observable<TeamReportBean> observable = RetrofitHelper.getService(ITeamService.class).getTeamReport(startDate + " 00:00:00", endDate + " 23:59:59", pageSize, pageNumber);
        return toSubscribe(observable, Observer);
    }

    @Override
    public Disposable getTeamChanges(Observer Observer, String startDate, String endDate, String way, String type, String item, int pageNumber, int pageSize, String order, String property) {
        Observable<List<TeamBillBean>> observable = RetrofitHelper.getService(ITeamService.class).getTeamChanges(startDate + " 00:00:00", endDate + " 23:59:59", way, type, item, pageNumber, pageSize, order, property).map(new HttpResultFunc<>());
        return toSubscribe(observable, Observer);
    }

    @Override
    public Disposable getTeamSalary(Observer Observer, String playerId) {
        Observable<TeamSalaryBean> observable = RetrofitHelper.getService(ITeamService.class).getTeamSalary(playerId);
        return toSubscribe(observable, Observer);
    }

    @Override
    public Disposable getTeamParticipation(Observer Observer, String playerId) {
        Observable<TeamParticipationBean> observable = RetrofitHelper.getService(ITeamService.class).getTeamParticipation(playerId);
        return toSubscribe(observable, Observer);
    }

    @Override
    public Disposable getTeamHasRatio(Observer Observer) {
        Observable<TeamhasRatioBean> observable = RetrofitHelper.getService(ITeamService.class).getTeamHasRatio().map(new HttpResultFunc<>());
        return toSubscribe(observable, Observer);
    }

    @Override
    public Disposable getSaveTeamSalary(Observer Observer, String jsonStr) {
        Observable<Boolean> observable = RetrofitHelper.getService(ITeamService.class).getSaveTeamSalary(jsonStr).map(new HttpResultFunc<>());
        return toSubscribe(observable, Observer);
    }

    @Override
    public Disposable getSaveParticipation(Observer Observer, String jsonStr) {
        Observable<Boolean> observable = RetrofitHelper.getService(ITeamService.class).getSaveParticipation(jsonStr).map(new HttpResultFunc<>());
        return toSubscribe(observable, Observer);
    }

    @Override
    public Disposable getCheckMemberType(Observer Observer) {
        Observable<HttpResult<List<CheckMemberTypeBean>>> observable = RetrofitHelper.getService(ITeamService.class).getCheckMemberType();
        return toSubscribe(observable, Observer);
    }

    @Override
    public Disposable saveMemberType(Observer Observer, String id, String status) {
        Observable<SaveMemberTypeBean> observable = RetrofitHelper.getService(ITeamService.class).saveMemberType(id, status);
        return toSubscribe(observable, Observer);
    }

}
