package com.dawoo.lotterybox.mvp.model.deposit;

import com.hwangjr.rxbus.annotation.Subscribe;

import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;
import rx.Subscriber;
import rx.Subscription;

/**
 * Created by rain on 18-4-30.
 */

public interface IDepositModel {
    Disposable getPayWay(Observer subscriber, String type);


    Disposable getPayDetail(Observer subscriber,String type,String item);

    Disposable getFee(Observer subscriber, int payAccountId,double money);

    Disposable postOnline(Observer subscriber,int payAccountId,double depositAmount,String token);




    /*
    公司入款
     */
    Disposable getSales(Observer subscriber,String type);

    Disposable getSaleMoney(Observer subscriber,double money,int id);

    Disposable postCompanyPay(Observer subscriber,int payAccountId,double rechargeAmount, int favorableId, String orderNumber, String payerName,String token);

}
