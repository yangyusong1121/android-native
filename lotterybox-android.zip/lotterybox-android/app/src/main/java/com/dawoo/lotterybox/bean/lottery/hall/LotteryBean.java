package com.dawoo.lotterybox.bean.lottery.hall;

/**
 * Created by b on 18-5-30.
 */

public class LotteryBean {

//              "bigCode":"ssc"
//             "name":"重庆时时彩",
//             "code":"cqssc",
//             "detailTitle":"一分钟一期",
//             "isHot":0或1 boolean 是否热门
//            "isNew":0或1  boolean 是否新彩种
//            "model":"office" //传统还是官方
//             imageUrl":"" //icon 地址

    private String type;
    private String name;
    private String code;
    private String memo;
    private String isHot;
    private String isNew;
    private String model;
    private String imageUrl;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMemo() {
        return memo;
    }

    public void setMemo(String memo) {
        this.memo = memo;
    }

    public String getIsHot() {
        if(isHot==null){
            isHot="false";
        }
        return isHot;
    }

    public void setIsHot(String isHot) {
        this.isHot = isHot;
    }

    public String getIsNew() {
        if(isNew==null){
            isNew="false";
        }
        return isNew;
    }

    public void setIsNew(String isNew) {
        this.isNew = isNew;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

}
