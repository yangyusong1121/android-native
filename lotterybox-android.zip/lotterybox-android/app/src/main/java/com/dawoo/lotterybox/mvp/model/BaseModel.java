package com.dawoo.lotterybox.mvp.model;

import android.content.Intent;
import android.provider.Telephony;
import android.support.v4.content.LocalBroadcastManager;

import com.blankj.utilcode.util.Utils;
import com.dawoo.lotterybox.BoxApplication;
import com.dawoo.lotterybox.ConstantValue;
import com.dawoo.lotterybox.net.ApiException;
import com.dawoo.lotterybox.net.HttpResult;
import com.hwangjr.rxbus.RxBus;
import com.trello.rxlifecycle2.android.RxLifecycleAndroid;

import org.reactivestreams.Subscriber;
import org.reactivestreams.Subscription;

import io.reactivex.Flowable;
import io.reactivex.Observable;
import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Action;
import io.reactivex.functions.Consumer;
import io.reactivex.functions.Function;
import io.reactivex.schedulers.Schedulers;
import rx.functions.Func1;
import rx.subscriptions.CompositeSubscription;


/**
 * Created by benson on 17-12-21.
 */

public class BaseModel {
    protected <T> Disposable toSubscribe(Observable<T> o, Observer<? super T> onNext) {
        Disposable subscribe = o.subscribeOn(Schedulers.io())
                .unsubscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(onNext::onNext, onNext::onError, onNext::onComplete, onNext::onSubscribe);

        return subscribe;
    }

    /**
     * 用来统一处理Http的resultCode,并将HttpResult的Data部分剥离出来返回给subscriber
     *
     * @param <T> Subscriber真正需要的数据类型，也就是Data部分的数据类型
     */
    public class HttpResultFunc<T> implements Function<HttpResult<T>, T> {


        @Override
        public T apply(HttpResult<T> httpResult) {
            if (0 != httpResult.getError()) {
                throw new ApiException(httpResult.getCode(), httpResult.getMessage());

            }
            BoxApplication.HttpStateCode = httpResult.getError();

            return httpResult.getData();
        }
    }

    /**
     * 接口返回error不为0，任然返回data数据给回调
     */

    public class HttpResultFunc2<T> implements Function<HttpResult<T>, T> {


        @Override
        public T apply(HttpResult<T> httpResult) {
            if (0 != httpResult.getError()) {
                new ApiException(httpResult.getCode(), httpResult.getMessage());

            }
            BoxApplication.HttpStateCode = httpResult.getError();
            return httpResult.getData();
        }
    }


    public class HttpResultFunc3<T> implements Func1<HttpResult<T>, HttpResult<T>> {

        @Override
        public HttpResult<T> call(HttpResult<T> httpResult) {

            if (0 != httpResult.getError()) {
                throw new ApiException(httpResult.getCode(), httpResult.getMessage());
            }
            BoxApplication.HttpStateCode = httpResult.getError();
            return httpResult;
        }
    }
}
