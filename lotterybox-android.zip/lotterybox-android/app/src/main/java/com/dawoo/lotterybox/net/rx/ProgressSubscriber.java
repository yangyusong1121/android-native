package com.dawoo.lotterybox.net.rx;

import android.content.Context;
import android.widget.Toast;

import com.blankj.utilcode.util.LogUtils;
import com.blankj.utilcode.util.NetworkUtils;
import com.dawoo.lotterybox.BoxApplication;
import com.dawoo.lotterybox.ConstantValue;
import com.dawoo.lotterybox.R;
import com.dawoo.lotterybox.util.SingleToast;
import com.hwangjr.rxbus.RxBus;

import java.net.ConnectException;
import java.net.NoRouteToHostException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.nio.channels.UnresolvedAddressException;

import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;


/**
 * 用于在Http请求开始时，自动显示一个ProgressDialog
 * 在Http请求结束是，关闭ProgressDialog
 * 调用者自己对请求数据进行处理
 */
public  class ProgressSubscriber<T>  implements Observer<T>, ProgressCancelListener {

    private SubscriberOnNextListener mSubscriberOnNextListener;
    private ProgressDialogHandler mProgressDialogHandler;

    private Context context;

    public ProgressSubscriber(SubscriberOnNextListener mSubscriberOnNextListener, Context context) {
        this.mSubscriberOnNextListener = mSubscriberOnNextListener;
        this.context = BoxApplication.getContext();
        mProgressDialogHandler = new ProgressDialogHandler(context, this, false);
    }

    public ProgressSubscriber(SubscriberOnNextListener mSubscriberOnNextListener, Context context, boolean isNeedDialog) {
        this.mSubscriberOnNextListener = mSubscriberOnNextListener;
        this.context = context;
        if (isNeedDialog) {
            mProgressDialogHandler = new ProgressDialogHandler(context, this, false);
        }
    }

    private void showProgressDialog() {
        if (mProgressDialogHandler != null) {
            mProgressDialogHandler.obtainMessage(ProgressDialogHandler.SHOW_PROGRESS_DIALOG).sendToTarget();
        }
    }

    private void dismissProgressDialog() {
        if (mProgressDialogHandler != null) {
            mProgressDialogHandler.obtainMessage(ProgressDialogHandler.DISMISS_PROGRESS_DIALOG).sendToTarget();
            mProgressDialogHandler = null;
        }
    }
  private Disposable d;
    @Override
    public void onSubscribe(Disposable d) {
        this.d=d;
        showProgressDialog();

    }


    @Override
    public void onComplete() {
        dismissProgressDialog();
    }


    /**
     * 对错误进行统一处理
     * 隐藏ProgressDialog
     *
     * @param e
     */
    @Override
    public void onError(Throwable e) {
        if (e instanceof SocketTimeoutException) {
            SingleToast.showMsg(BoxApplication.getContext().getString(R.string.Network_Connection_timeout));
            BoxApplication.HttpStateCode = 999;
        } else if (e instanceof ConnectException) {
            SingleToast.showMsg(BoxApplication.getContext().getString(R.string.no_network));
            BoxApplication.HttpStateCode = 998;
        } else if (e instanceof UnknownHostException) {
            //域名不可用
            if (NetworkUtils.isConnected()) {
                BoxApplication.HttpStateCode = 998;
            } else {
                BoxApplication.HttpStateCode = 404;
            }
        } else {

        }
        dismissProgressDialog();
        if (e instanceof NullPointerException){
            return;
        }
        if (e instanceof NoRouteToHostException){
            return;
        }
        RxBus.get().post(ConstantValue.EVENT_TYPE_NETWORK_EXCEPTION, "" + e.getMessage());
    }

    /**
     * 将onNext方法中的返回结果交给Activity或Fragment自己处理
     *
     * @param t 创建Subscriber时的泛型类型
     */
    @Override
    public void onNext(T t) {
        if (mSubscriberOnNextListener != null) {
            mSubscriberOnNextListener.onNext(t);
        }
    }

    /**
     * 取消ProgressDialog的时候，取消对observable的订阅，同时也取消了http请求
     */
    @Override
    public void onCancelProgress() {
        if (!d.isDisposed()) {
            d.dispose();
        }
    }
}