package com.dawoo.lotterybox.bean;

public class TeamMemberDetailBean {


    /**
     * rebate : 0
     * bonus : 0
     * memberCount : 0
     * payout : 1788.925
     * betaumont : 2060
     * favorable : 50
     * deposittotal : 2650
     * lastlogintime : 1528012413771
     * effectivevolume : 2060
     * wages : 0
     * balance : 2278.925
     * id : 10570
     * withdrawtotal : 100
     * profit : -271.075
     * agentCount : 0
     * username : james004
     */

    private double rebate;
    private double bonus;
    private double memberCount;
    private double payout;
    private double betaumont;
    private double favorable;
    private double deposittotal;
    private long lastlogintime;
    private double effectivevolume;
    private double wages;
    private double balance;
    private double id;
    private double withdrawtotal;
    private double profit;
    private double agentCount;
    private String username;

    public double getRebate() {
        return rebate;
    }

    public void setRebate(double rebate) {
        this.rebate = rebate;
    }

    public double getBonus() {
        return bonus;
    }

    public void setBonus(double bonus) {
        this.bonus = bonus;
    }

    public double getMemberCount() {
        return memberCount;
    }

    public void setMemberCount(double memberCount) {
        this.memberCount = memberCount;
    }

    public double getPayout() {
        return payout;
    }

    public void setPayout(double payout) {
        this.payout = payout;
    }

    public double getBetaumont() {
        return betaumont;
    }

    public void setBetaumont(double betaumont) {
        this.betaumont = betaumont;
    }

    public double getFavorable() {
        return favorable;
    }

    public void setFavorable(double favorable) {
        this.favorable = favorable;
    }

    public double getDeposittotal() {
        return deposittotal;
    }

    public void setDeposittotal(double deposittotal) {
        this.deposittotal = deposittotal;
    }

    public long getLastlogintime() {
        return lastlogintime;
    }

    public void setLastlogintime(long lastlogintime) {
        this.lastlogintime = lastlogintime;
    }

    public double getEffectivevolume() {
        return effectivevolume;
    }

    public void setEffectivevolume(double effectivevolume) {
        this.effectivevolume = effectivevolume;
    }

    public double getWages() {
        return wages;
    }

    public void setWages(double wages) {
        this.wages = wages;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public double getId() {
        return id;
    }

    public void setId(double id) {
        this.id = id;
    }

    public double getWithdrawtotal() {
        return withdrawtotal;
    }

    public void setWithdrawtotal(double withdrawtotal) {
        this.withdrawtotal = withdrawtotal;
    }

    public double getProfit() {
        return profit;
    }

    public void setProfit(double profit) {
        this.profit = profit;
    }

    public double getAgentCount() {
        return agentCount;
    }

    public void setAgentCount(double agentCount) {
        this.agentCount = agentCount;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}
