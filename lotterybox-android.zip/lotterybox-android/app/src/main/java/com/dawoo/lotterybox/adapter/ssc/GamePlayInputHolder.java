package com.dawoo.lotterybox.adapter.ssc;

import android.content.Context;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.dawoo.coretool.util.LogUtils;
import com.dawoo.lotterybox.R;
import com.dawoo.lotterybox.adapter.BaseViewHolder;
import com.dawoo.lotterybox.bean.playtype.PlayTypeBean;
import com.dawoo.lotterybox.view.activity.lottery.BaseLotteryAActivity;
import com.google.common.base.Objects;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by b on 18-2-20.
 */

public class GamePlayInputHolder extends BaseViewHolder {
    private Context mContext;
    @BindView(R.id.et_bet_input)
    EditText mEtBetInput;
    @BindView(R.id.ll_root_rx)
    LinearLayout llTop;
    @BindView(R.id.cb_g)
    CheckBox cbGe;
    @BindView(R.id.cb_s)
    CheckBox cbShi;
    @BindView(R.id.cb_b)
    CheckBox cbBai;
    @BindView(R.id.cb_q)
    CheckBox cbQiang;
    @BindView(R.id.cb_w)
    CheckBox cbWang;
    @BindView(R.id.tv_select_count)
    TextView tvSelectCount;
    @BindView(R.id.tv_plan_count)
    TextView tvPlanCount;
    private int selectCount = 0;
    private int planCount = 0;
    private int A = 0;
    private int B = 0;
    private int C = 0;
    private int D = 0;
    private int E = 0;
    private int mBets=0;
    private String mOutPut="";

    public GamePlayInputHolder(Context context, View itemView) {
        super(itemView);
        this.mContext = context;
        ButterKnife.bind(this, itemView);
    }

    private void processCheckBox(PlayTypeBean.PlayBean playTypeBean) {
        getCheckBoxCount(cbGe, 1, playTypeBean);
        getCheckBoxCount(cbShi, 2, playTypeBean);
        getCheckBoxCount(cbBai, 3, playTypeBean);
        getCheckBoxCount(cbQiang, 4, playTypeBean);
        getCheckBoxCount(cbWang, 5, playTypeBean);
    }

    private void getCheckBoxCount(CheckBox checkBox, int position, PlayTypeBean.PlayBean mPlayTypeBean) {
        checkBox.setOnCheckedChangeListener((CompoundButton buttonView, boolean isChecked) -> {
            selectCount = isChecked ? (selectCount + 1) : (selectCount - 1);
            tvSelectCount.setText("" + selectCount);
            switch (position) {
                case 1:
                    A = isChecked ? 1 : 0;
                    break;
                case 2:
                    B = isChecked ? 1 : 0;
                    break;
                case 3:
                    C = isChecked ? 1 : 0;
                    break;
                case 4:
                    D = isChecked ? 1 : 0;
                    break;
                case 5:
                    E = isChecked ? 1 : 0;
                    break;
                default:
            }
            //计算选择的情况的不同投注方案
            if (Objects.equal("任选二", mPlayTypeBean.getMainType())) {
                //计任选二的方案算法
                planCount = A * (B + C + D + E) + B * (C + D + E) + C * (D + E) + D * E;
            } else if (Objects.equal("任选三", mPlayTypeBean.getMainType())) {
                planCount = A * B * (C + D + E) + (A + B) * (C * D + C * E) + (A + B + C) * D * E;
            }
            if (Objects.equal("任选四", mPlayTypeBean.getMainType())) {
                //任选四
                planCount = A * B * C * (D + E) + D * E * (A * B + A * C + B * C);
            }
            tvPlanCount.setText("" + planCount);
            if (mContext instanceof BaseLotteryAActivity) {
                int a = mBets;
                String out = "";
                if (mPlayTypeBean.getMainType().contains("任选")) {
                    a = a * planCount;
                    List<String> chars = new ArrayList<>();
                    if (E == 1) {
                        chars.add("万");
                    }
                    if (D == 1) {
                        chars.add("千");
                    }
                    if (C == 1) {
                        chars.add("百");
                    }
                    if (B == 1) {
                        chars.add("十");
                    }
                    if (A == 1) {
                        chars.add("个");
                    }
                    String charys = "";
                    for (int i = 0; i < chars.size(); i++) {
                        String body = i == chars.size() - 1 ? chars.get(i) + "|" : chars.get(i) + ",";
                        charys = charys + body;
                    }
                    out = charys + mOutPut.replace("|", ",").replace("万,","")
                            .replace("千,","").replace("百,","").replace("十,","")
                            .replace("个,","");

                }
                ((BaseLotteryAActivity) mContext).computBetInfoByInput(out, a);
            }
        });
    }

    public void onBindView(PlayTypeBean.PlayBean playBean, int position) {
        //状态重置
        cbGe.setChecked(false);
        cbShi.setChecked(false);
        cbBai.setChecked(false);
        cbQiang.setChecked(false);
        cbWang.setChecked(false);
        llTop.setVisibility(playBean.getLayoutBeans().get(position).isShowTop() ? View.VISIBLE : View.GONE);
        processCheckBox(playBean);
        if ("任选二".equals(playBean.getMainType())) {
            cbGe.setChecked(true);
            cbShi.setChecked(true);
        } else if ("任选三".equals(playBean.getMainType())) {
            cbGe.setChecked(true);
            cbShi.setChecked(true);
            cbBai.setChecked(true);
        } else if ("任选四".equals(playBean.getMainType())) {
            cbGe.setChecked(true);
            cbShi.setChecked(true);
            cbBai.setChecked(true);
            cbQiang.setChecked(true);
        }
//        mEtBetInput.setFilters(new InputFilter[]{new InputFilter.LengthFilter(playBean.getLayoutBeans().get(position).getSelectMin())});
        mEtBetInput.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                String betNum = s.toString();
                int bets = 0; //注数
                StringBuffer betString = new StringBuffer();
                StringBuffer testString = new StringBuffer();  //用于检测是否为顺序不一样的重复投注
                if (!TextUtils.isEmpty(betNum)) {
                    String[] nums = betNum.split(";|\\s+|,");
                    for (int i = 0; i < nums.length; i++) {
                        List<String> numStrings = new ArrayList<>(); //用来存放ｎｕｍ倍切割为具体数值的ｌｉｓt
                        String num = nums[i];
                        if (num.length() == playBean.getLayoutBeans().get(position).getSelectMin()) {

                            if (playBean.getPlayTypeCode().startsWith("syx5")) {  //11xuan5
                                if ("组选单式".equals(playBean.getPlayTypeName())) {
                                    try {
                                        boolean isAdd = true;
                                        List<Integer> numbers = new ArrayList<>();
                                        for (int j = 0; j < num.length() / 2; j++) {
                                            String str = num.substring(j * 2, j * 2 + 2);
                                            numStrings.add(str);
                                            int number = Integer.valueOf(str);
                                            if (!numbers.contains(number) && (number > 0 && number <= 11)) {
                                                numbers.add(number);
                                            }
                                        }
                                        if (numbers.size() != playBean.getLayoutBeans().get(position).getSelectMin() / 2) {
                                            isAdd = false;
                                        }
                                        if (!isAdd || isRepeat(numbers, testString))
                                            continue;
                                    } catch (Exception e) {
                                        continue;
                                    }
                                } else if ("直选单式".equals(playBean.getPlayTypeName())) {
                                    try {
                                        boolean isAdd = true;
                                        List<Integer> numbers = new ArrayList<>();
                                        for (int j = 0; j < num.length() / 2; j++) {
                                            String str = num.substring(j * 2, j * 2 + 2);
                                            numStrings.add(str);
                                            int number = Integer.valueOf(str);
                                            if (!numbers.contains(number) && (number > 0 && number <= 11)) {
                                                numbers.add(number);
                                            }
                                        }
                                        if (numbers.size() != playBean.getLayoutBeans().get(position).getSelectMin() / 2) {
                                            isAdd = false;
                                        }
                                        if (!isAdd)
                                            continue;
                                        if (betString.toString().replaceAll(",","").contains(num)) {    //去重
                                            continue;
                                        }
                                    } catch (Exception e) {
                                        continue;
                                    }
                                }

                                StringBuffer replace = new StringBuffer();
                                if (!"直选单式".equals(playBean.getPlayTypeName())) { //直选单式不需要排序
                                    Collections.sort(numStrings);
                                }
                                for (int j = 0; j < numStrings.size(); j++) {
                                    if (j == numStrings.size() - 1) {
                                        replace.append(numStrings.get(j));
                                    } else replace.append(numStrings.get(j) + ",");
                                }
                                num = replace.toString();


                            } else {

                                if ("组三单式".equals(playBean.getPlayTypeName())) {
                                    try {
                                        List<Integer> numbers = new ArrayList<>();
                                        for (int j = 0; j < num.length(); j++) {
                                            String str = num.substring(j, j + 1);
                                            numStrings.add(str);
                                            int number = Integer.valueOf(str);
                                            numbers.add(number);
                                        }
                                        Collections.sort(numbers);
                                        boolean isDuo = false;
                                        int nowNum = 0;
                                        for (int j = 0; j < numbers.size(); j++) {
                                            if (j != 0) {
                                                if (nowNum == numbers.get(j)) {
                                                    if (isDuo)
                                                        isDuo = false;
                                                    else {
                                                        isDuo = true;
                                                    }
                                                }
                                            }
                                            nowNum = numbers.get(j);
                                        }
                                        if (!isDuo || isRepeat(numbers, testString))
                                            continue;
                                    } catch (Exception e) {
                                        continue;
                                    }
                                } else if ("组六单式".equals(playBean.getPlayTypeName())) {
                                    try {
                                        boolean isAdd = true;
                                        List<Integer> numbers = new ArrayList<>();
                                        for (int j = 0; j < num.length(); j++) {
                                            String str = num.substring(j, j + 1);
                                            numStrings.add(str);
                                            int number = Integer.valueOf(str);
                                            if (!numbers.contains(number)) {
                                                numbers.add(number);
                                            }
                                        }
                                        if (numbers.size() != playBean.getLayoutBeans().get(position).getSelectMin()) {
                                            isAdd = false;
                                        }
                                        if (!isAdd || isRepeat(numbers, testString))
                                            continue;
                                    } catch (Exception e) {
                                        continue;
                                    }
                                } else if ("混合组选".equals(playBean.getPlayTypeName())) {
                                    try {
                                        List<Integer> numbers = new ArrayList<>();
                                        for (int j = 0; j < num.length(); j++) {
                                            String str = num.substring(j, j + 1);
                                            numStrings.add(str);
                                            int number = Integer.valueOf(str);
                                            numbers.add(number);
                                        }
                                        boolean isLeopard = true;
                                        int nowNum = 0;
                                        for (int j = 0; j < numbers.size(); j++) {
                                            if (j != 0) {
                                                if (nowNum != numbers.get(j)) {
                                                    isLeopard = false;
                                                }
                                            }
                                            nowNum = numbers.get(j);
                                        }
                                        if (isLeopard || isRepeat(numbers, testString))
                                            continue;
                                    } catch (Exception e) {
                                        continue;
                                    }
                                } else if ("组选单式".equals(playBean.getPlayTypeName())) {
                                    try {
                                        boolean isAdd = true;
                                        List<Integer> numbers = new ArrayList<>();
                                        for (int j = 0; j < num.length() ; j++) {
                                            String str = num.substring(j , j + 1);
                                            numStrings.add(str);
                                            int number = Integer.valueOf(str);
                                            if (!numbers.contains(number)) {
                                                numbers.add(number);
                                            }
                                        }
                                        if (numbers.size() != playBean.getLayoutBeans().get(position).getSelectMin()) {
                                            isAdd = false;
                                        }
                                        if (!isAdd || isRepeat(numbers, testString))
                                            continue;
                                    } catch (Exception e) {
                                        continue;
                                    }
                                } else if ("直选单式".equals(playBean.getPlayTypeName())) {
                                    if (betString.toString().contains(num)) {    //去重
                                        continue;
                                    }
                                }
                                if (!"直选单式".equals(playBean.getPlayTypeName())) {   //直选单式不需要排序
                                    StringBuffer replace = new StringBuffer();
                                    Collections.sort(numStrings);
                                    for (int j = 0; j < numStrings.size(); j++) {
                                        replace.append(numStrings.get(j));
                                    }
                                    num = replace.toString();
                                }

                            }
                            if (TextUtils.isEmpty(betString.toString())) {
                                betString.append(num);
                                bets = 1;
                            } else {
                                betString.append("|");
                                betString.append(num);
                                bets++;
                            }
                        }
                    }
                    mBets = bets;
                    if (mContext instanceof BaseLotteryAActivity) {
                        mOutPut = betString.toString();
                        int a = bets;
                        if (playBean.getMainType().contains("任选")) {
                            a = a * planCount;
                            List<String> chars = new ArrayList<>();
                            if (E == 1) {
                                chars.add("万");
                            }
                            if (D == 1) {
                                chars.add("千");
                            }
                            if (C == 1) {
                                chars.add("百");
                            }
                            if (B == 1) {
                                chars.add("十");
                            }
                            if (A == 1) {
                                chars.add("个");
                            }
                            String charys = "";
                            for (int i = 0; i < chars.size(); i++) {
                                String body = i == chars.size() - 1 ? chars.get(i) + "|" : chars.get(i) + ",";
                                charys = charys + body;
                            }
                            mOutPut = charys + mOutPut.replace("|", ",").replace("万,","")
                            .replace("千,","").replace("百,","").replace("十,","")
                            .replace("个,","");

                        }
                        ((BaseLotteryAActivity) mContext).computBetInfoByInput(mOutPut, a);
                    }
                }
            }

            /**
             * 顺序不同的去重检测（如：１２３　　３２１）
             * */
            private boolean isRepeat(List<Integer> numbers, StringBuffer testString) {
                Collections.sort(numbers);
                StringBuffer test = new StringBuffer();
                for (int h = 0; h < numbers.size(); h++) {
                    test.append(numbers.get(h));
                }
                if (testString.toString().contains(test)) {
                    return true;
                } else {
                    testString.append(test);
                    return false;
                }
            }
        });
    }
}
