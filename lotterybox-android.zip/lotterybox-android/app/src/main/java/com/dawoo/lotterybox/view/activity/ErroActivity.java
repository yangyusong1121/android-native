package com.dawoo.lotterybox.view.activity;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.dawoo.lotterybox.R;
import com.dawoo.lotterybox.view.view.HeaderView;

import butterknife.BindView;

/**
 * Created by rain on 18-6-13.
 */

public class ErroActivity extends BaseActivity {
    @BindView(R.id.head_view)
    HeaderView headerView;
    @BindView(R.id.ero_img)
    ImageView eroImg;
    @BindView(R.id.ero_code)
    TextView eroCode;
    @BindView(R.id.ero_info)
    TextView eroInfo;
    @BindView(R.id.content_tv)
    TextView contentTv;
    int code;

    @Override
    protected void createLayoutView() {
        setContentView(R.layout.activity_ero);
    }

    @Override
    protected void initViews() {
        code = getIntent().getIntExtra("code", 607);
        if (code == 607) {
            headerView.setHeader("系统维护", false);
        } else {
            headerView.setHeader("禁止访问", false);
            eroImg.setImageResource(R.mipmap.ero_605);
            eroInfo.setText("所在地区禁止访问");
            eroCode.setText(code + "");
            contentTv.setText("Access to this IP has been restricted due");
        }
    }

    @Override
    protected void initData() {

    }
}
