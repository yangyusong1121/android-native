package com.dawoo.lotterybox.mvp.model.user;


import android.util.Base64;

import com.blankj.utilcode.util.EncodeUtils;
import com.dawoo.lotterybox.bean.Bank;
import com.dawoo.lotterybox.bean.CheckAccountBean;
import com.dawoo.lotterybox.bean.LoginBean;
import com.dawoo.lotterybox.bean.LoginOutBean;
import com.dawoo.lotterybox.bean.MyBandCard;
import com.dawoo.lotterybox.bean.OALinkBean;
import com.dawoo.lotterybox.bean.SettingBean;
import com.dawoo.lotterybox.bean.User;
import com.dawoo.lotterybox.bean.InfoMation;
import com.dawoo.lotterybox.bean.WithDrawBean;
import com.dawoo.lotterybox.bean.record.MutType;
import com.dawoo.lotterybox.mvp.model.BaseModel;
import com.dawoo.lotterybox.mvp.service.IRecordService;
import com.dawoo.lotterybox.mvp.service.ISettingService;
import com.dawoo.lotterybox.mvp.service.IUserService;
import com.dawoo.lotterybox.mvp.service.IWithDrawsService;
import com.dawoo.lotterybox.net.BaseHttpResult;
import com.dawoo.lotterybox.net.HttpResult;
import com.dawoo.lotterybox.net.RetrofitHelper;

import org.reactivestreams.Subscriber;
import org.reactivestreams.Subscription;

import java.util.HashMap;
import java.util.List;

import io.reactivex.Observable;
import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;


/**
 * Created by benson on 17-12-21.
 */

public class UserModel extends BaseModel implements IUserModel {


    @Override
    public Disposable login(Observer subscriber, String name, String pwd, String appKey, String appSecret, String serialNo) {
        Observable<LoginBean> observable = RetrofitHelper
                .getService(IUserService.class)
                .login(name, Base64.encodeToString(pwd.getBytes(), Base64.DEFAULT), appKey, appSecret, serialNo)
                .map(new HttpResultFunc2<>());
        return toSubscribe(observable, subscriber);
    }

    @Override
    public Disposable register(Observer subscriber, String name, String pwd, String confirmPwd, String createChannel, String playerType, String mode, String promoCode) {
        Observable<Boolean> observable = RetrofitHelper
                .getService(IUserService.class)
                .register(name, Base64.encodeToString(pwd.getBytes(), Base64.DEFAULT), Base64.encodeToString(confirmPwd.getBytes(), Base64.DEFAULT), createChannel, playerType, mode, promoCode)
                .map(new HttpResultFunc<>());
        return toSubscribe(observable, subscriber);
    }

    @Override
    public Disposable createAccount(Observer subscriber, String name, String pwd, String createChannel, String playerType, String parentId) {
        Observable<Boolean> observable = RetrofitHelper
                .getService(IUserService.class)
                .createAccount(name, Base64.encodeToString(pwd.getBytes(), Base64.DEFAULT), createChannel, playerType, parentId)
                .map(new HttpResultFunc<>());
        return toSubscribe(observable, subscriber);
    }

    @Override
    public Disposable getUserInfo(Observer subscriber) {
        Observable<User> observable = RetrofitHelper.getService(IUserService.class).getUserInfo().map(new HttpResultFunc<>());
        return toSubscribe(observable, subscriber);
    }

    /**
     * 用戶登出
     *
     * @param subscriber
     * @return
     */
    @Override
    public Disposable signOut(Observer subscriber) {
        Observable<Boolean> observable = RetrofitHelper.getService(IUserService.class).signOut().map(new HttpResultFunc<>());
        return toSubscribe(observable, subscriber);
    }

    /**
     * 修改玩家密码
     */
    @Override
    public Disposable upDatePasswold(Observer subscriber, String oldPwd, String newPwd) {
        Observable<BaseHttpResult> observable = RetrofitHelper
                .getService(IUserService.class)
                .upDatePasswold(Base64.encodeToString(oldPwd.getBytes(), Base64.DEFAULT), Base64.encodeToString(newPwd.getBytes(), Base64.DEFAULT));
        return toSubscribe(observable, subscriber);
    }

    /**
     * 修改玩家昵称
     *
     * @param subscriber
     * @param
     * @return
     */
    @Override
    public Disposable upDateNickName(Observer subscriber, String nickName) {
        Observable<BaseHttpResult> observable = RetrofitHelper
                .getService(IUserService.class)
                .upDateNickName(nickName);

        return toSubscribe(observable, subscriber);
    }

    @Override
    public Disposable upDateRealName(Observer subscriber, String realName) {
        Observable<BaseHttpResult> observable = RetrofitHelper
                .getService(IUserService.class)
                .upDateRealName(realName);
        return toSubscribe(observable, subscriber);
    }

    /**
     * 修改安全密码
     *
     * @param subscriber
     * @param upDatePermissionPassword
     * @return
     */
    @Override
    public Disposable upDatePermissionPassword(Observer subscriber, String upDatePermissionPassword) {
        Observable<BaseHttpResult> observable = RetrofitHelper
                .getService(IUserService.class)
                .upDatePermissionPassword(Base64.encodeToString(upDatePermissionPassword.getBytes(), Base64.DEFAULT));
        return toSubscribe(observable, subscriber);
    }

    /**
     * 校验安全密码
     *
     * @param subscriber
     * @param qureyPermissionPassword
     * @return
     */
    @Override
    public Disposable quirePermissionPassword(Observer subscriber, String qureyPermissionPassword) {
        Observable<BaseHttpResult> observable = RetrofitHelper
                .getService(IUserService.class)
                .queryPermissionPassword(Base64.encodeToString(qureyPermissionPassword.getBytes(), Base64.DEFAULT));
        return toSubscribe(observable, subscriber);
    }


    @Override
    public Disposable getUserInfoWithSystemSetting(Observer subscriber) {
//        Observable<User> userObservable = RetrofitHelper.getService(IUserService.class).getUserInfo().map(new HttpResultFunc<>());
        Observable<SettingBean> settingBeanObservable = RetrofitHelper.getService(ISettingService.class).getSystemSetting().map(new HttpResultFunc<>());
        Observable<List<MyBandCard>> bankListObservable = RetrofitHelper.getService(IWithDrawsService.class).bankcardList().map(new HttpResultFunc<>());
        Observable<Object> observable = Observable.merge(settingBeanObservable, bankListObservable);
        return toSubscribe(observable, subscriber);
    }

    @Override
    public Disposable getCreateAccocuntLink(Observer subscriber) {
        Observable<OALinkBean> observable = RetrofitHelper.getService(IUserService.class).getCreateAccocuntLink().map(new HttpResultFunc<>());
        return toSubscribe(observable, subscriber);
    }

    @Override
    public Disposable checkLoginName(Observer subscriber, String name) {
        Observable<CheckAccountBean> observable = RetrofitHelper
                .getService(IUserService.class)
                .checkLoginName(name)
                .map(new HttpResultFunc<>());
        return toSubscribe(observable, subscriber);
    }

    @Override
    public Disposable checkAccount(Observer subscriber, String name, String realName, String bankCardNumber) {
        Observable<HttpResult> observable = RetrofitHelper
                .getService(IUserService.class)
                .checkAccount(name, realName, bankCardNumber);
        return toSubscribe(observable, subscriber);
    }

    @Override
    public Disposable accountPassword(Observer subscriber, String name, String password) {
        Observable observable = RetrofitHelper
                .getService(IUserService.class)
                .accountPassword(name, Base64.encodeToString(password.getBytes(), Base64.DEFAULT));
        return toSubscribe(observable, subscriber);
    }

    @Override
    public Disposable testAccountLogin(Observer subscriber, String appkey, String appSecret, String serialNo) {
        Observable<LoginBean> observable = RetrofitHelper
                .getService(IUserService.class)
                .testAccountlogin(appkey, appSecret, serialNo)
                .map(new HttpResultFunc2<>());
        return toSubscribe(observable, subscriber);
    }


    @Override
    public Disposable applyAgent(Observer subscriber) {
        Observable observable = RetrofitHelper.
                getService(IUserService.class)
                .applyAgent();
        return toSubscribe(observable, subscriber);
    }

    @Override
    public Disposable getHelp(Observer subscriber) {
        Observable observable = RetrofitHelper.
                getService(IUserService.class)
                .getHelp();
        return toSubscribe(observable, subscriber);
    }


}
