package com.dawoo.lotterybox.mvp.model.record;


import com.dawoo.lotterybox.ConstantValue;
import com.dawoo.lotterybox.bean.BillAmountBean;
import com.dawoo.lotterybox.bean.lottery.LotterySimpleBean;
import com.dawoo.lotterybox.bean.record.AssetsBean;
import com.dawoo.lotterybox.bean.record.BillCommonBean;
import com.dawoo.lotterybox.bean.record.BillItemBean;
import com.dawoo.lotterybox.bean.record.BillItemPrentBean;
import com.dawoo.lotterybox.bean.record.GameRecordBean;
import com.dawoo.lotterybox.bean.record.NoteRecordHisData;
import com.dawoo.lotterybox.bean.record.NoteRecordHis;
import com.dawoo.lotterybox.bean.record.ProfitBean;
import com.dawoo.lotterybox.mvp.model.BaseModel;
import com.dawoo.lotterybox.mvp.service.IRecordService;
import com.dawoo.lotterybox.net.RetrofitHelper;

import java.util.List;

import io.reactivex.Observable;
import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;


/**
 * Created by benson on 17-12-21.
 */

public class RecordModel extends BaseModel implements IRecordModel {
    @Override
    public Disposable getOrders(Observer Observer, String code, String expect,
                                String status, String queryStartDate, String queryEndDate,
                                String pageSize, String pageNumber, String playMode, String order, String property) {
        Observable<NoteRecordHisData> observable = RetrofitHelper
                .getService(IRecordService.class)
                .getOrders(code, expect, status, queryStartDate, queryEndDate, pageSize, pageNumber, playMode, order, property);
        return toSubscribe(observable, Observer);
    }

    @Override
    public Disposable getLottery(Observer Observer) {
        Observable<List<LotterySimpleBean>> observable = RetrofitHelper
                .getService(IRecordService.class)
                .getLottery()
                .map(new HttpResultFunc<>());
        return toSubscribe(observable, Observer);
    }

    @Override
    public Disposable getAssets(Observer Observer, String queryStartDate, String queryEndDate, String status, String code) {
        Observable<AssetsBean> observable = RetrofitHelper
                .getService(IRecordService.class)
                .getAssets(queryStartDate, queryEndDate, status, code)
                .map(new HttpResultFunc<>());
        return toSubscribe(observable, Observer);
    }

    @Override
    public Disposable getRecentProfit(Observer Observer, String status, String code) {
        Observable<List<ProfitBean>> observable = RetrofitHelper
                .getService(IRecordService.class)
                .getRecentProfit(status, code)
                .map(new HttpResultFunc<>());
        return toSubscribe(observable, Observer);
    }

    @Override
    public Disposable getOrderDetail(Observer Observer, String id, String orign) {
        Observable<NoteRecordHis> observable = RetrofitHelper
                .getService(IRecordService.class)
                .getOrderDetail(id, orign)
                .map(new HttpResultFunc<>());
        return toSubscribe(observable, Observer);
    }

    @Override
    public Disposable getRechargeAmountDisplay(Observer Observer, String type, String item, String startData, String endData) {
        Observable<Object> observable = RetrofitHelper
                .getService(IRecordService.class)
                .getRechargeAmountDisplay(type, item, startData, endData)
                .map(new HttpResultFunc<BillAmountBean>());
        return toSubscribe(observable, Observer);
    }

    @Override
    public Disposable getWithDrawsAmountDisplay(Observer Observer, String type, String item, String startData, String endData) {
        Observable<Object> observable = RetrofitHelper
                .getService(IRecordService.class)
                .getWithDrawsAmountDisplay(type, item, startData, endData)
                .map(new HttpResultFunc<BillAmountBean>());
        return toSubscribe(observable, Observer);
    }

    @Override
    public Disposable getBillchangeChanges(Observer Observer, int pageNum, String startData, String endData, String way, String type, String item, String order, String property) {
        Observable<BillItemPrentBean> observable = RetrofitHelper
                .getService(IRecordService.class)
                .getBillchangeChanges(pageNum, ConstantValue.RECORD_LIST_PAGE_SIZE, startData, endData, way, type, item, order, property);
        return toSubscribe(observable, Observer);
    }

    @Override
    public Disposable getBillchangeAssets(Observer Observer, String startData, String endData) {
        Observable<Object> observable = RetrofitHelper
                .getService(IRecordService.class)
                .getBillchangeAssets(startData, endData)
                .map(new HttpResultFunc<BillCommonBean>());
        return toSubscribe(observable, Observer);
    }

    @Override
    public Disposable getOrderGroup(Observer Observer, String startData, String endData) {
        Observable<List<GameRecordBean>> observable = RetrofitHelper
                .getService(IRecordService.class)
                .getOrderGroup(startData, endData)
                .map(new HttpResultFunc<>());
        return toSubscribe(observable, Observer);
    }

    @Override
    public Disposable getRechargeRecords(Observer Observer, String type, String item, String startData, String endData, String order, String property) {
        Observable<BillItemPrentBean> observable = RetrofitHelper
                .getService(IRecordService.class)
                .getRechargeRecords(type, item, startData, endData, order, property);
        return toSubscribe(observable, Observer);
    }

  /*  @Override
    public Disposable getRecordsType(Observer Observer) {
        Observable<Object> observable = RetrofitHelper
                .getService(IRecordService.class)
                .getRecordsType()
                .map(new HttpResultFunc<>());
        return toSubscribe(observable, Observer);
    }*/

    @Override
    public Disposable getWithDrawsRecords(Observer Observer, String type, String item, String startData, String endData, String order, String property) {
        Observable<BillItemPrentBean> observable = RetrofitHelper
                .getService(IRecordService.class)
                .getWithDrawsRecords(type, item, startData, endData, order, property);
        return toSubscribe(observable, Observer);
    }


}
