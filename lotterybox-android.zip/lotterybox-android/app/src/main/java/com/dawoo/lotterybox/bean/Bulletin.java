package com.dawoo.lotterybox.bean;

/**
 * Created by b on 18-2-16.
 * 公告
 */

public class Bulletin {

    /**
     * title : 公告标题一
     * content : 公告内容公告内容
     */

    private String title;
    private String content;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
