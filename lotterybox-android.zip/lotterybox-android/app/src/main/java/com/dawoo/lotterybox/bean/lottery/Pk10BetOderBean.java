package com.dawoo.lotterybox.bean.lottery;

import java.util.List;

public class Pk10BetOderBean {

    /**
     * code : pk10nn
     * expect : 697788
     * quantity : 2
     * totalMoney : 200
     * playModel : tradition
     * betOrders : [{"betNum":"nn_xian_san","betCode":"nn_xian_jia","playCode":"nn_multiple","betAmount":20,"freezAmount":80},{"betNum":"nn_xian_si","betCode":"nn_xian_jia","playCode":"nn_multiple","betAmount":20,"freezAmount":80}]
     */

    private String code;
    private String expect;
    private int quantity;
    private int totalMoney;
    private String playModel;
    private List<BetOrdersBean> betOrders;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getExpect() {
        return expect;
    }

    public void setExpect(String expect) {
        this.expect = expect;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public int getTotalMoney() {
        return totalMoney;
    }

    public void setTotalMoney(int totalMoney) {
        this.totalMoney = totalMoney;
    }

    public String getPlayModel() {
        return playModel;
    }

    public void setPlayModel(String playModel) {
        this.playModel = playModel;
    }

    public List<BetOrdersBean> getBetOrders() {
        return betOrders;
    }

    public void setBetOrders(List<BetOrdersBean> betOrders) {
        this.betOrders = betOrders;
    }

    public static class BetOrdersBean {
        /**
         * betNum : nn_xian_san
         * betCode : nn_xian_jia
         * playCode : nn_multiple
         * betAmount : 20
         * freezAmount : 80
         */

        private String betNum;
        private String betCode;
        private String playCode;
        private int betAmount;
        private int freezAmount;

        public String getBetNum() {
            return betNum;
        }

        public void setBetNum(String betNum) {
            this.betNum = betNum;
        }

        public String getBetCode() {
            return betCode;
        }

        public void setBetCode(String betCode) {
            this.betCode = betCode;
        }

        public String getPlayCode() {
            return playCode;
        }

        public void setPlayCode(String playCode) {
            this.playCode = playCode;
        }

        public int getBetAmount() {
            return betAmount;
        }

        public void setBetAmount(int betAmount) {
            this.betAmount = betAmount;
        }

        public int getFreezAmount() {
            return freezAmount;
        }

        public void setFreezAmount(int freezAmount) {
            this.freezAmount = freezAmount;
        }
    }
}
