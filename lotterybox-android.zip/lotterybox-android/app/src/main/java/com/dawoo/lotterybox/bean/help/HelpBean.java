package com.dawoo.lotterybox.bean.help;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.List;

public class HelpBean implements Parcelable {
    private String title;
    private String content;
    private List<HelpTwoBean> two;

    public List<HelpTwoBean> getTwo() {
        return two;
    }

    public void setTwo(List<HelpTwoBean> two) {
        this.two = two;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public HelpBean() {
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.title);
        dest.writeString(this.content);
        dest.writeTypedList(this.two);
    }

    protected HelpBean(Parcel in) {
        this.title = in.readString();
        this.content = in.readString();
        this.two = in.createTypedArrayList(HelpTwoBean.CREATOR);
    }

    public static final Creator<HelpBean> CREATOR = new Creator<HelpBean>() {
        @Override
        public HelpBean createFromParcel(Parcel source) {
            return new HelpBean(source);
        }

        @Override
        public HelpBean[] newArray(int size) {
            return new HelpBean[size];
        }
    };
}
