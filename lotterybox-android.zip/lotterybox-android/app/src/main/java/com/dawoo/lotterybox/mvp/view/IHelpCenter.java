package com.dawoo.lotterybox.mvp.view;

import com.dawoo.lotterybox.bean.help.HelpBaseBean;

/**
 * - @Description: 用户申请代理
 * - @Author:  bella
 * - @Time:  18-7-18 上午10:04
 */

public interface IHelpCenter extends IBaseView {
    void helpCenter(HelpBaseBean o);
}
