package com.dawoo.lotterybox.mvp.view;

public interface ICheckMemberType extends IBaseView {
    void checkMemberTypeResult(Object o);

    void saveMemberTypeResult(Object o);

}
