package com.dawoo.lotterybox.mvp.view;

/**
 * Created by alex on 18-4-5.
 */

public interface IUpdateSettingView  extends IBaseView{
    void onUpdate(Object o);
}
