package com.dawoo.lotterybox.view.activity;

import android.support.annotation.NonNull;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.dawoo.coretool.util.LogUtils;
import com.dawoo.lotterybox.ConstantValue;
import com.dawoo.lotterybox.R;
import com.dawoo.lotterybox.adapter.AllLotteryAdapter;
import com.dawoo.lotterybox.bean.AllMode;
import com.dawoo.lotterybox.bean.BannerBean;
import com.dawoo.lotterybox.bean.Bulletin;
import com.dawoo.lotterybox.bean.DataCenter;
import com.dawoo.lotterybox.bean.lottery.hall.AllLotteryBean;
import com.dawoo.lotterybox.bean.lottery.hall.HotLotteryBean;
import com.dawoo.lotterybox.bean.lottery.hall.LotteryBean;
import com.dawoo.lotterybox.bean.lottery.lotteryenum.BaseLotteryEnum;
import com.dawoo.lotterybox.mvp.presenter.HallPresenter;
import com.dawoo.lotterybox.mvp.view.IHallView;
import com.dawoo.lotterybox.util.ActivityUtil;
import com.dawoo.lotterybox.view.activity.lottery.k3.K3AActivity;
import com.dawoo.lotterybox.view.activity.lottery.k3.K3BActivity;
import com.dawoo.lotterybox.view.activity.lottery.keno.BJKL8Activity;
import com.dawoo.lotterybox.view.activity.lottery.keno.XY28Activity;
import com.dawoo.lotterybox.view.activity.lottery.lhc.HKSMActivity;
import com.dawoo.lotterybox.view.activity.lottery.pk10.BasePk10BetRoomActivity;
import com.dawoo.lotterybox.view.activity.lottery.pk10.PK10AActivity;
import com.dawoo.lotterybox.view.activity.lottery.pk10.PK10BActivity;
import com.dawoo.lotterybox.view.activity.lottery.pk10.PK10BaccaratActivity;
import com.dawoo.lotterybox.view.activity.lottery.pk10.PK10CattleActivity;
import com.dawoo.lotterybox.view.activity.lottery.qt.QTAActivity;
import com.dawoo.lotterybox.view.activity.lottery.qt.QTBActivity;
import com.dawoo.lotterybox.view.activity.lottery.select5.GDSelectAActivity;
import com.dawoo.lotterybox.view.activity.lottery.sfc.CqxyncActivity;
import com.dawoo.lotterybox.view.activity.lottery.ssc.SSCAActivity;
import com.dawoo.lotterybox.view.activity.lottery.ssc.SSCBActivity;
import com.dawoo.lotterybox.view.view.HeaderView;
import com.dawoo.lotterybox.view.view.SegmentTabLayout.OnTabSelectListener;
import com.dawoo.lotterybox.view.view.SkinSegmentTabLayout;
import com.hwangjr.rxbus.annotation.Subscribe;
import com.hwangjr.rxbus.annotation.Tag;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;

import static com.dawoo.lotterybox.ConstantValue.MODE_OFFICIAL_PLAY;

/**
 * Created by b on 18-5-30.
 * 更多彩种
 */

public class AllLotteryActivity extends BaseActivity implements OnRefreshListener, IHallView {
    @BindView(R.id.head_view)
    HeaderView mHeadView;
    @BindView(R.id.tab_layout)
    SkinSegmentTabLayout mTabLayout;
    @BindView(R.id.swipe_target)
    RecyclerView mRlvLottery;
    @BindView(R.id.srl_root)
    SmartRefreshLayout srlRefresh;
    private String[] mTitles_2 = {"传统玩法", "官方玩法"};
    List<LotteryBean> mOfficeLotteryBeans = new ArrayList<>();  //官方数据
    List<LotteryBean> mTraditionLotteryBeans = new ArrayList<>();  //传统数据
    HallPresenter presenter;
    AllLotteryAdapter mAdapter;
    int position = 0;

    @Override
    protected void createLayoutView() {
        setContentView(R.layout.activity_all_lottery);
    }

    @Override
    protected void initViews() {
        mHeadView.setHeader("更多彩种", true);
        srlRefresh.setEnableLoadMore(false);
        srlRefresh.setOnRefreshListener(this);
        position = getIntent().getIntExtra("position", 0);
    }

    @Override
    protected void initData() {
        mTabLayout.setTabData(mTitles_2);
        mAdapter = new AllLotteryAdapter(this);
        mRlvLottery.setLayoutManager(new GridLayoutManager(this, 4));
        mRlvLottery.setAdapter(mAdapter);
        mTabLayout.setOnTabSelectListener(new OnTabSelectListener() {
            @Override
            public void onTabSelect(int index) {
                position = index;
                if (position == 0)
                    mAdapter.setmDatas(mTraditionLotteryBeans);
                else mAdapter.setmDatas(mOfficeLotteryBeans);
            }

            @Override
            public void onTabReselect(int position) {

            }
        });
        mAdapter.setOnItemClickLintener(new AllLotteryAdapter.OnItemClickLintener() {
            @Override
            public void onItemClickLinter(int position) {
                gotoLotteryActivity(mAdapter.getmDatas().get(position));
            }
        });
        onRefresh();
    }

    public void onRefresh() {
        if (presenter == null) {
            presenter = new HallPresenter(this, this);
        }
        presenter.getAllLottery();
    }

    @Override
    public void onBanner(List<BannerBean> bannerBeans) {

    }

    @Override
    public void onBulletin(List<Bulletin> bulletins) {

    }

    @Override
    public void onAllDatas(AllMode allMode) {
        mOfficeLotteryBeans.clear();
        //此2为maplist
        List<LotteryBean> officeList = new ArrayList<>();
        List<LotteryBean> tranditions = new ArrayList<>();
        for (AllLotteryBean bean : allMode.getOfficial()) {
            if (bean.getLotterys() != null && !bean.getLotterys().isEmpty()) {
                LotteryBean lotteryBean = new LotteryBean();
                lotteryBean.setModel("-1");
                lotteryBean.setName(bean.getName());
                lotteryBean.setImageUrl(bean.getSmallImageUrl());
                mOfficeLotteryBeans.add(lotteryBean);
                mOfficeLotteryBeans.addAll(bean.getLotterys());
                officeList.addAll(bean.getLotterys());
            }
        }
        mTraditionLotteryBeans.clear();
        for (AllLotteryBean bean : allMode.getTradition()) {
            if (bean.getLotterys() != null && !bean.getLotterys().isEmpty()) {
                LotteryBean lotteryBean = new LotteryBean();
                lotteryBean.setModel("-1");
                lotteryBean.setName(bean.getName());
                lotteryBean.setImageUrl(bean.getSmallImageUrl());
                mTraditionLotteryBeans.add(lotteryBean);
                mTraditionLotteryBeans.addAll(bean.getLotterys());
                tranditions.addAll(bean.getLotterys());
            }
        }
        mTabLayout.setCurrentTab(position);
        if (position == 0) {
            mAdapter.setmDatas(mTraditionLotteryBeans);
        } else {
            mAdapter.setmDatas(mOfficeLotteryBeans);
        }
        closeFresh();


        for (LotteryBean bean : tranditions) {
            DataCenter.getInstance().getmLotteryType().put(bean.getCode(), bean.getModel());
        }
        for (LotteryBean bean : officeList) {
            DataCenter.getInstance().getmLotteryType().put(bean.getCode(), bean.getModel());
        }
        tranditions.clear();
        officeList.clear();
    }

    @Override
    public void onHomeLottery(HotLotteryBean hotLotteryBean) {

    }

    private void closeFresh() {
        srlRefresh.finishRefresh();
    }


    /**
     * 根据点击彩种进行分发
     * A盘的彩种进入A盘投注界面
     * B盘的彩种进入B盘投注界面
     *
     * @param dataBean
     */

    void gotoLotteryActivity(LotteryBean dataBean) {
        if (dataBean == null) {
            return;
        }
        String type = dataBean.getType();

        // 根据彩种类型进入彩票的彩种投注界面
        if (BaseLotteryEnum.K3.getType().equals(type)) {
            // k3
            if (dataBean.getModel().equals(MODE_OFFICIAL_PLAY)) {
                startActivity(K3AActivity.class, dataBean);
            } else {
                startActivity(K3BActivity.class, dataBean);
            }
        } else if (BaseLotteryEnum.LHC.getType().equals(type)) {
            // lhc
            startActivity(HKSMActivity.class, dataBean);
        } else if (BaseLotteryEnum.SSC.getType().equals(type)) {
            // ssc
            if (dataBean.getModel().equals(MODE_OFFICIAL_PLAY)) {
                startActivity(SSCAActivity.class, dataBean);
            } else {
                startActivity(SSCBActivity.class, dataBean);
            }
        } else if (BaseLotteryEnum.PK10.getType().equals(type)) {
            // pk10
            if (dataBean.getModel().equals(MODE_OFFICIAL_PLAY)) {
                startActivity(PK10AActivity.class, dataBean);
            } else {
                startActivity(PK10BActivity.class, dataBean);
            }
        } else if (BaseLotteryEnum.SFC.getType().equals(type)) {
            // sfc 重庆幸运农场 广东快乐十分
            startActivity(CqxyncActivity.class, dataBean);
        } else if (BaseLotteryEnum.KENO.getType().equals(type)) {
            // keno 北京快乐8
            startActivity(BJKL8Activity.class, dataBean);
        } else if (BaseLotteryEnum.XY28.getType().equals(type)) {
            // xy28 幸运28
            startActivity(XY28Activity.class, dataBean);

        } else if (BaseLotteryEnum.PL3.getType().equals(type)) {
            // pl3
            if (dataBean.getModel().equals(MODE_OFFICIAL_PLAY)) {
                startActivity(QTAActivity.class, dataBean);
            } else {
                startActivity(QTBActivity.class, dataBean);
            }
        } else if (BaseLotteryEnum.SYXW.getType().equalsIgnoreCase(type)) {
            startActivity(GDSelectAActivity.class, dataBean);
        } else if (BaseLotteryEnum.NN.getType().equalsIgnoreCase(type)) {
            startActivity(PK10CattleActivity.class, dataBean);
        } else if (BaseLotteryEnum.BJL.getType().equalsIgnoreCase(type)) {
            startActivity(PK10BaccaratActivity.class, dataBean);
        }
    }

    /**
     * 进入投注activity
     *
     * @param clazz
     * @param dataBean
     */
    public void startActivity(Class clazz, LotteryBean dataBean) {
        String name = dataBean.getName();
        String code = dataBean.getCode();
        ActivityUtil.startNoteActivity(clazz, name, code, dataBean.getType());
    }

    @Subscribe(tags = {@Tag(ConstantValue.EVENT_TYPE_NETWORK_EXCEPTION)})
    public void shrinkRefreshView(String s) {
        LogUtils.d(s);
        //  收起刷新
        closeFresh();

    }

    @Override
    public void onRefresh(@NonNull RefreshLayout refreshLayout) {
        onRefresh();
    }
}
