package com.dawoo.lotterybox.adapter;

import android.content.Context;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.dawoo.lotterybox.R;
import com.dawoo.lotterybox.adapter.lhc.LHCBaseAdapter;
import com.dawoo.lotterybox.bean.Deposit.SaleBean;
import com.dawoo.lotterybox.util.SkinUtils;

import java.util.ArrayList;
import java.util.List;

import skin.support.widget.SkinCompatCheckBox;

/**
 * Created by rain on 18-5-4.
 */

public class SaleAdapter extends RecyclerView.Adapter<SaleAdapter.SaleHolder> {
    private List<SaleBean> mDatas = new ArrayList<>();
    private int selectedIndex = 0;
    private OnItemClickLinstener onItemClickLInstener;
    private Context context;

    public SaleAdapter(Context context) {
        this.context = context;
    }

    public void setSelectedIndex(int selectedIndex) {
        if (this.selectedIndex == selectedIndex) {
            return;
        }
        this.selectedIndex = selectedIndex;
        notifyDataSetChanged();
    }

    /**
     * 获取选中的saleID
     * @return
     */
    public int getSaleId() {
        if(mDatas.isEmpty()){
            return 0;
        }
        return mDatas.get(selectedIndex).getId();
    }
    public double getSaleMIn() {
        if(mDatas.isEmpty()){
            return 0;
        }
        return mDatas.get(selectedIndex).getMoney();
    }
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @NonNull
    @Override
    public SaleHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new SaleHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_sale_layout, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull SaleHolder holder, int position) {
        holder.itemView.setTag(position);
        if (position == 0) {
            holder.topLine.setVisibility(View.GONE);
        } else {
            holder.topLine.setVisibility(View.VISIBLE);
        }
        if (selectedIndex == position) {
            holder.selectIV.setChecked(true);
        } else {
            holder.selectIV.setChecked(false);
        }
        String content = mDatas.get(position).getActivityName();
        if(mDatas.get(position).getMoney()>0){
            content += "（最低"+mDatas.get(position).getMoney()+"）";
        }
        holder.saleName.setText(content);

    }


    @Override
    public int getItemCount() {
        return mDatas.size();
    }

    public void setmDatas(List<SaleBean> mDatas) {
        this.mDatas = mDatas;
        selectedIndex =0;
        notifyDataSetChanged();
    }
    public void clear(){
        this.mDatas.clear();
        notifyDataSetChanged();
    }
    class SaleHolder extends RecyclerView.ViewHolder {
        SkinCompatCheckBox selectIV;
        TextView saleName;
        View topLine;

        @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
        public SaleHolder(View itemView) {
            super(itemView);
            selectIV = itemView.findViewById(R.id.select_iv);
            saleName = itemView.findViewById(R.id.sale_name);
            topLine = itemView.findViewById(R.id.top_line);
            selectIV.setFocusable(false);
            selectIV.setFocusableInTouchMode(false);
            selectIV.setClickable(false);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (onItemClickLInstener != null)
                        onItemClickLInstener.onItemClick((Integer) v.getTag());
                }
            });
        }
    }

    public interface OnItemClickLinstener {
        void onItemClick(int position);
    }

    public void setOnItemClickLInstener(OnItemClickLinstener onItemClickLInstener) {
        this.onItemClickLInstener = onItemClickLInstener;
    }
}
