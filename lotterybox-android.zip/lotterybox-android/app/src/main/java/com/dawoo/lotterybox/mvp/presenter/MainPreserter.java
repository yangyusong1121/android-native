package com.dawoo.lotterybox.mvp.presenter;

import android.content.Context;

import com.dawoo.lotterybox.bean.BannerBean;
import com.dawoo.lotterybox.bean.UpdateInfo;
import com.dawoo.lotterybox.mvp.model.main.IMainModel;
import com.dawoo.lotterybox.mvp.model.main.MainModel;
import com.dawoo.lotterybox.mvp.view.IBaseView;
import com.dawoo.lotterybox.mvp.view.IHallView;
import com.dawoo.lotterybox.mvp.view.IMainView;
import com.dawoo.lotterybox.net.rx.ProgressSubscriber;

import io.reactivex.disposables.Disposable;


public class MainPreserter<T extends IBaseView> extends BasePresenter {

    private final Context mContext;
    private T mView;
    private final IMainModel mModel;

    public MainPreserter(Context context, T view) {
        super(context, view);
        mContext = context;
        this.mView = view;
        mModel = new MainModel();
    }


    public void getVersionsData(int versionCode){
        Disposable Disposable = mModel.getVersionsData(new ProgressSubscriber(o ->
                ((IMainView) mView).onVersions((UpdateInfo) o), mContext,false),versionCode);
        subList.add(Disposable);
    }

}
