package com.dawoo.lotterybox.bean;

import java.util.List;

/**
 * Created by alex on 18-4-26.
 */

public class TeamReportBean {

    /**
     * error : 0
     * data : [{"playertype":"agent","wages":0,"rebate":0,"bonus":0,"rakeback":0,"payout":0,"id":10489,"playername":"ronnie401","withdrawtotal":0,"favorable":1000,"deposittotal":11000,"effectivevolume":0},{"playertype":"agent","wages":0,"rebate":0,"bonus":0,"rakeback":0,"payout":0,"id":10490,"playername":"ronnie402","withdrawtotal":0,"favorable":1000,"deposittotal":11000,"effectivevolume":0}]
     * extend : {"loss":"0.000","wages":"0.000","bonus":"0.000","payout":"0.000","withdrawtotal":"0.000","totalCount":0,"deposittotal":"22000.000","effectivevolume":"0.000"}
     */

    private int error;
    private ExtendBean extend;
    private List<DataBean> data;

    public int getError() {
        return error;
    }

    public void setError(int error) {
        this.error = error;
    }

    public ExtendBean getExtend() {
        return extend;
    }

    public void setExtend(ExtendBean extend) {
        this.extend = extend;
    }

    public List<DataBean> getData() {
        return data;
    }

    public void setData(List<DataBean> data) {
        this.data = data;
    }

    public static class ExtendBean {
        /**
         * loss : 0.000
         * wages : 0.000
         * bonus : 0.000
         * payout : 0.000
         * withdrawtotal : 0.000
         * totalCount : 0
         * deposittotal : 22000.000
         * effectivevolume : 0.000
         */

        private String loss;
        private String wages;
        private String bonus;
        private String payout;
        private String withdrawtotal;
        private int totalCount;
        private String deposittotal;
        private String effectivevolume;

        public String getLoss() {
            return loss;
        }

        public void setLoss(String loss) {
            this.loss = loss;
        }

        public String getWages() {
            return wages;
        }

        public void setWages(String wages) {
            this.wages = wages;
        }

        public String getBonus() {
            return bonus;
        }

        public void setBonus(String bonus) {
            this.bonus = bonus;
        }

        public String getPayout() {
            return payout;
        }

        public void setPayout(String payout) {
            this.payout = payout;
        }

        public String getWithdrawtotal() {
            return withdrawtotal;
        }

        public void setWithdrawtotal(String withdrawtotal) {
            this.withdrawtotal = withdrawtotal;
        }

        public int getTotalCount() {
            return totalCount;
        }

        public void setTotalCount(int totalCount) {
            this.totalCount = totalCount;
        }

        public String getDeposittotal() {
            return deposittotal;
        }

        public void setDeposittotal(String deposittotal) {
            this.deposittotal = deposittotal;
        }

        public String getEffectivevolume() {
            return effectivevolume;
        }

        public void setEffectivevolume(String effectivevolume) {
            this.effectivevolume = effectivevolume;
        }
    }

    public static class DataBean {
        /**
         * playertype : agent
         * wages : 0.0
         * rebate : 0.0
         * bonus : 0.0
         * rakeback : 0.0
         * payout : 0.0
         * id : 10489
         * playername : ronnie401
         * withdrawtotal : 0.0
         * favorable : 1000.0
         * deposittotal : 11000.0
         * effectivevolume : 0.0
         */

        private String playertype;
        private double wages;
        private double rebate;
        private double bonus;
        private double rakeback;
        private double payout;
        private int id;
        private String playername;
        private double withdrawtotal;
        private double favorable;
        private double deposittotal;
        private double effectivevolume;

        public String getPlayertype() {
            return playertype;
        }

        public void setPlayertype(String playertype) {
            this.playertype = playertype;
        }

        public double getWages() {
            return wages;
        }

        public void setWages(double wages) {
            this.wages = wages;
        }

        public double getRebate() {
            return rebate;
        }

        public void setRebate(double rebate) {
            this.rebate = rebate;
        }

        public double getBonus() {
            return bonus;
        }

        public void setBonus(double bonus) {
            this.bonus = bonus;
        }

        public double getRakeback() {
            return rakeback;
        }

        public void setRakeback(double rakeback) {
            this.rakeback = rakeback;
        }

        public double getPayout() {
            return payout;
        }

        public void setPayout(double payout) {
            this.payout = payout;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getPlayername() {
            return playername;
        }

        public void setPlayername(String playername) {
            this.playername = playername;
        }

        public double getWithdrawtotal() {
            return withdrawtotal;
        }

        public void setWithdrawtotal(double withdrawtotal) {
            this.withdrawtotal = withdrawtotal;
        }

        public double getFavorable() {
            return favorable;
        }

        public void setFavorable(double favorable) {
            this.favorable = favorable;
        }

        public double getDeposittotal() {
            return deposittotal;
        }

        public void setDeposittotal(double deposittotal) {
            this.deposittotal = deposittotal;
        }

        public double getEffectivevolume() {
            return effectivevolume;
        }

        public void setEffectivevolume(double effectivevolume) {
            this.effectivevolume = effectivevolume;
        }
    }
}
