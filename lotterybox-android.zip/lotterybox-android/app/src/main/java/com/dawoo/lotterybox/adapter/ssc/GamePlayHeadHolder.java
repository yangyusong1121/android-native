package com.dawoo.lotterybox.adapter.ssc;

import android.content.Context;
import android.view.View;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.dawoo.lotterybox.ConstantValue;
import com.dawoo.lotterybox.R;
import com.dawoo.lotterybox.adapter.BaseViewHolder;
import com.dawoo.lotterybox.bean.DataCenter;
import com.dawoo.lotterybox.bean.playtype.PlayTypeBean;
import com.dawoo.lotterybox.view.activity.lottery.BaseLotteryAActivity;
import com.dawoo.lotterybox.view.view.TimeTextView;
import com.hwangjr.rxbus.RxBus;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by b on 18-2-11.
 */

public class GamePlayHeadHolder extends BaseViewHolder {
    private Context mContext;
    @BindView(R.id.tv_balance)
    TextView mTvBalance;
    @BindView(R.id.hot_and_cold_name)
    TextView mHotAndColdName;
    @BindView(R.id.hot_and_cold_layout)
    LinearLayout mHotAndColdLayout;
    @BindView(R.id.cb_omit_name)
    TextView mCbOmitName;
    @BindView(R.id.cb_omit_layout)
    LinearLayout mCbOmitLayout;
    @BindView(R.id.iv_random)
    ImageView mIvRandom;
    @BindView(R.id.tv_how_play)
    TextView mTvHowPlay;


    public GamePlayHeadHolder(Context context, View itemView) {
        super(itemView);
        ButterKnife.bind(this, itemView);
        this.mContext = context;
    }


    public void onBindView(PlayTypeBean.PlayBean mPlayTypeBean, GamePlayAdapter gamePlayAdapter/*,String nowState,String countdownTime*/) {
        if (DataCenter.getInstance().isLogin()) {
            mTvBalance.setText(DataCenter.getInstance().getUser().getBalance());
        }
        mTvHowPlay.setText(mPlayTypeBean.getSingleExplain());
        if (mPlayTypeBean.getMainType().contains("任选")||mPlayTypeBean.getPlayTypeName().contains("单式")){
            mHotAndColdLayout.setVisibility(View.GONE);
            mCbOmitLayout.setVisibility(View.GONE);
        }else {
            mHotAndColdLayout.setVisibility(View.VISIBLE);
            mCbOmitLayout.setVisibility(View.VISIBLE);
        }


        if (gamePlayAdapter.type == 0) {
            mHotAndColdLayout.setSelected(true);
            mCbOmitLayout.setSelected(false);
        } else if (gamePlayAdapter.type == 1) {
            mHotAndColdLayout.setSelected(false);
            mCbOmitLayout.setSelected(true);
        }
        mIvRandom.setOnClickListener(v -> {
            //先清状态
            ((BaseLotteryAActivity) mContext).clearSelect();
            ((BaseLotteryAActivity) mContext).doComputerSelect();
        });
        mTvHowPlay.setOnClickListener(v -> {
            if (mContext instanceof BaseLotteryAActivity) {
                ((BaseLotteryAActivity) mContext).showHowPlayDialog();
            }
        });

        mHotAndColdLayout.setOnClickListener(v -> {
            if (gamePlayAdapter.type == -1 || gamePlayAdapter.type == 1) {
                gamePlayAdapter.type = 0;
                mHotAndColdLayout.setSelected(true);
                mCbOmitLayout.setSelected(false);
                mHotAndColdName.setSelected(true);
                mCbOmitName.setSelected(false);
                 ((BaseLotteryAActivity) mContext).openHotColdOrOmit(0);
            } else {
                mHotAndColdLayout.setSelected(false);
                mHotAndColdName.setSelected(false);
                gamePlayAdapter.type = -1;
                ((BaseLotteryAActivity) mContext).openHotColdOrOmit(-1);
            }
        });

        mCbOmitLayout.setOnClickListener(v -> {
            if (gamePlayAdapter.type == -1 || gamePlayAdapter.type == 0) {
                gamePlayAdapter.type = 1;
                mHotAndColdLayout.setSelected(false);
                mCbOmitLayout.setSelected(true);
                mHotAndColdName.setSelected(false);
                mCbOmitName.setSelected(true);
                ((BaseLotteryAActivity) mContext).openHotColdOrOmit(1);
            } else {
                mCbOmitLayout.setSelected(false);
                mCbOmitName.setSelected(false);
                gamePlayAdapter.type = -1;
                ((BaseLotteryAActivity) mContext).openHotColdOrOmit(-1);
            }
        });
    }
}
