package com.dawoo.lotterybox.mvp.presenter;

import android.content.Context;
import android.util.Log;

import com.dawoo.lotterybox.bean.BillAmountBean;
import com.dawoo.lotterybox.bean.record.AssetsBean;
import com.dawoo.lotterybox.bean.record.BillCommonBean;
import com.dawoo.lotterybox.bean.record.BillItemBean;
import com.dawoo.lotterybox.bean.record.BillItemPrentBean;
import com.dawoo.lotterybox.mvp.model.record.IRecordModel;
import com.dawoo.lotterybox.mvp.model.record.RecordModel;
import com.dawoo.lotterybox.mvp.view.IBaseView;
import com.dawoo.lotterybox.mvp.view.IBillHisView;
import com.dawoo.lotterybox.net.rx.ProgressSubscriber;

import java.util.List;

import io.reactivex.disposables.Disposable;


/**
 * Created by rain on 18-4-19.
 */

public class BillPresenter<T extends IBaseView> extends BasePresenter {
    private static final String TAG = "BillPresenter";
    private final Context mContext;
    private T mView;
    private final IRecordModel mModel;

    public BillPresenter(Context mContext, T view) {
        super(mContext, view);
        this.mContext = mContext;
        this.mView = view;
        mModel = new RecordModel();
    }

    /**
     * 玩家资金历史报表
     */
    public void getBills(int pageNum, String startData, String endData, String way, String type, String item, String order, String property) {
        if (way.equalsIgnoreCase("all")) {
            way = "";
        }
        if (type.equalsIgnoreCase("all")) {
            type = "";
        }
        if (item.equalsIgnoreCase("all")) {
            item = "";
        }
        Log.d(TAG, "getBills: order===" + order + ",===property===" + property+",pageNum==="+pageNum);
        Disposable Disposable = mModel.getBillchangeChanges(new ProgressSubscriber(o ->
                        ((IBillHisView) mView).getBillsData((BillItemPrentBean) o), mContext, false),
                pageNum,
                startData + " 00:00:00",
                endData + " 23:59:59",
                way, type, item, order, property);
        subList.add(Disposable);
    }

    /**
     * 玩家资金历史报表
     */
    public void getBillCount(String startData, String endData) {
        Disposable Disposable = mModel.getBillchangeAssets(new ProgressSubscriber(o ->
                        ((IBillHisView) mView).getBillCount((BillCommonBean) o), mContext, false),
                startData + " 00:00:00",
                endData + " 23:59:59");
        subList.add(Disposable);
    }

    /**
     * 玩家存取记录
     */
    public void getBillsrecharge(String startData, String endData, String type, String item, String order, String property) {

        if (type.equalsIgnoreCase("all")) {
            type = "";
        }
        if (item.equalsIgnoreCase("all")) {
            item = "";
        }
        Log.d(TAG, "getBillsrecharge: item=" + item + ",order==" + order + ",property==" + property);
        if (type.equalsIgnoreCase("deposit")) {//存
            Disposable Disposable = mModel.getRechargeRecords(new ProgressSubscriber(o ->
                            ((IBillHisView) mView).getBillsData((BillItemPrentBean) o), mContext, false),
                    "", item, startData + " 00:00:00",
                    endData + " 23:59:59",
                    order, property);
            subList.add(Disposable);
        } else {
            //取
            Disposable Disposable = mModel.getWithDrawsRecords(new ProgressSubscriber(o ->
                            ((IBillHisView) mView).getBillsData((BillItemPrentBean) o), mContext, false),
                    "", item, startData + " 00:00:00",
                    endData + " 23:59:59", order, property);
            subList.add(Disposable);
        }

    }

    /**
     * 获取近30天盈亏记录
     */
    public void getEachDayBills() {
       /* Disposable Disposable = mModel.getRechargeRecords(new ProgressSubscriber(o ->
                        ((IBillHisView) mView).getBillsData((List<BillItemBean>) o), mContext),
                "", item, startData + " 00:00:00",
                endData + " 23:59:59");
        subList.add(Disposable);*/
    }

    /**
     * 获取充值或者提现记录
     *
     * @param startData
     * @param endData
     * @param type
     * @param item
     */
    public void getBillAssert(String startData, String endData, String type, String item) {
        if (type.equalsIgnoreCase("all")) {
            type = "";
        }
        if (item.equalsIgnoreCase("all")) {
            item = "";
        }
        if (type.equalsIgnoreCase("deposit")) {
            Disposable Disposable = mModel.getRechargeAmountDisplay(new ProgressSubscriber(o ->
                            ((IBillHisView) mView).getBillAmount((BillAmountBean) o), mContext, false),
                    "", item, startData + " 00:00:00",
                    endData + " 23:59:59");
            subList.add(Disposable);
        } else {
            Disposable Disposable = mModel.getWithDrawsAmountDisplay(new ProgressSubscriber(o ->
                            ((IBillHisView) mView).getBillAmount((BillAmountBean) o), mContext, false),
                    "", item, startData + " 00:00:00",
                    endData + " 23:59:59");
            subList.add(Disposable);
        }
    }
}
