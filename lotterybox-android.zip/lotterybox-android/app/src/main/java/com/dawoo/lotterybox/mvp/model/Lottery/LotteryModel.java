package com.dawoo.lotterybox.mvp.model.Lottery;

import com.dawoo.lotterybox.bean.AllMode;
import com.dawoo.lotterybox.bean.BannerBean;
import com.dawoo.lotterybox.bean.BetOrderABean;
import com.dawoo.lotterybox.bean.BetOrderBean;
import com.dawoo.lotterybox.bean.BetOrdersListBean;
import com.dawoo.lotterybox.bean.Bulletin;
import com.dawoo.lotterybox.bean.TypeAndLotteryBean;
import com.dawoo.lotterybox.bean.lottery.BaseHandicap;
import com.dawoo.lotterybox.bean.lottery.Handicap;
import com.dawoo.lotterybox.bean.lottery.HandicapWithOpening;
import com.dawoo.lotterybox.bean.lottery.LotteryLastOpenAndOpening;
import com.dawoo.lotterybox.bean.lottery.LotteryOddBean;
import com.dawoo.lotterybox.bean.lottery.LotteryType;
import com.dawoo.lotterybox.bean.lottery.OrderInfo;
import com.dawoo.lotterybox.bean.lottery.SaveOrderResult;
import com.dawoo.lotterybox.bean.lottery.hall.AllLotteryBean;
import com.dawoo.lotterybox.bean.lottery.hall.HotLotteryBean;
import com.dawoo.lotterybox.mvp.model.BaseModel;
import com.dawoo.lotterybox.mvp.service.IActivityService;
import com.dawoo.lotterybox.mvp.service.ILotteryService;
import com.dawoo.lotterybox.net.RetrofitHelper;
import java.util.List;
import java.util.Map;

import io.reactivex.Observable;
import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;



/**
 * Created by benson on 18-2-8.
 */

public class LotteryModel extends BaseModel implements ILotteryModel {

    @Override
    public Disposable getResultByCode(Observer Observer, String code, String pageSize, String pageNumber) {
        Observable<List<Handicap>> observable = RetrofitHelper
                .getService(ILotteryService.class)
                .getResultByCode(code, pageSize, pageNumber)
                .map(new HttpResultFunc<>());
        return toSubscribe(observable, Observer);
    }

    @Override
    public Disposable getRecentRecords(Observer Observer, String code, String pageSize) {
        Observable<List<HandicapWithOpening>> observable = RetrofitHelper
                .getService(ILotteryService.class)
                .getRecentRecords(code, pageSize)
                .map(new HttpResultFunc<>());
        return toSubscribe(observable, Observer);
    }

    public Disposable getBanner(Observer Observer) {
        Observable<List<BannerBean>> observable = RetrofitHelper
                .getService(IActivityService.class)
                .getBanner()
                .map(new HttpResultFunc<List<BannerBean>>());
        return toSubscribe(observable, Observer);
    }


    public Disposable getBulletin(Observer Observer) {
        Observable<List<Bulletin>> observable = RetrofitHelper
                .getService(IActivityService.class)
                .getBulletin()
                .map(new HttpResultFunc<List<Bulletin>>());
        return toSubscribe(observable, Observer);
    }

    @Override
    public Disposable getHallPageData(Observer Observer) {
        Observable<List<BannerBean>> banner = RetrofitHelper
                .getService(IActivityService.class)
                .getBanner()
                .map(new HttpResultFunc<List<BannerBean>>());

        Observable<List<Bulletin>> bulletin = RetrofitHelper
                .getService(IActivityService.class)
                .getBulletin()
                .map(new HttpResultFunc<List<Bulletin>>());

        Observable<HotLotteryBean> home = RetrofitHelper
                .getService(ILotteryService.class)
                .getHomeLottery()
                .map(new HttpResultFunc<>());

        Observable<AllMode> all = RetrofitHelper
                .getService(ILotteryService.class)
                .getAllLottery()
                .map(new HttpResultFunc<>());

        Observable<Object> merge = Observable.mergeDelayError(banner, bulletin, home, all);

        return toSubscribe(merge, Observer);
    }

    /**
     * 获取当前玩家列表
     * @param observer
     * @param expect
     * @param code
     * @return
     */
    @Override
    public Disposable getAllCustomerbyCode(Observer observer, String expect, String code) {
        Observable<Object> observable = RetrofitHelper
                .getService(ILotteryService.class)
                .getCustomersbyCode(expect,code)
                .map(new HttpResultFunc<Object>());
        return toSubscribe(observable, observer);
    }

    @Override
    public Disposable getLotteryExpect(Observer Observer, String code) {
        Observable<BaseHandicap> observable = RetrofitHelper
                .getService(ILotteryService.class)
                .getLotteryExpect(code)
                .map(new HttpResultFunc<>());
        return toSubscribe(observable, Observer);
    }


    @Override
    public Disposable getRecentCloseExpect(Observer Observer, String code) {
        Observable<Handicap> observable = RetrofitHelper
                .getService(ILotteryService.class)
                .getRecentCloseExpect(code)
                .map(new HttpResultFunc<>());
        return toSubscribe(observable, Observer);
    }

    @Override
    public Disposable getLastOpenedAndOpeningResult(Observer Observer) {
        Observable<List<LotteryLastOpenAndOpening>> observable = RetrofitHelper
                .getService(ILotteryService.class)
                .getLastOpenedAndOpeningResult()
                .map(new HttpResultFunc<>());
        return toSubscribe(observable, Observer);
    }

    @Override
    public Disposable getLotteryOdd(Observer Observer, String code, String betCode) {
        Observable<Map<String, LotteryOddBean>> observable = RetrofitHelper
                .getService(ILotteryService.class)
                .getLotteryOdd(code, betCode)
                .map(new HttpResultFunc<>());
        return toSubscribe(observable, Observer);
    }


    @Override
    public Disposable saveBetOrder(Observer Observer, String token, String betForm) {
        Observable<SaveOrderResult> observable = RetrofitHelper
                .getService(ILotteryService.class)
                .saveBetOrder(token,
                        betForm
                );
        return toSubscribe(observable, Observer);
    }



    @Override
    public Disposable getOrderInfo(Observer Observer, String billNo, String code) {
        Observable<OrderInfo> observable = RetrofitHelper
                .getService(ILotteryService.class)
                .getOrderInfo(billNo,
                        code).map(new HttpResultFunc<>());
        return toSubscribe(observable, Observer);
    }

    @Override
    public Disposable getHomeLottery(Observer Observer) {
        Observable<HotLotteryBean> observable = RetrofitHelper
                .getService(ILotteryService.class)
                .getHomeLottery()
                .map(new HttpResultFunc<>());
        return toSubscribe(observable, Observer);
    }

    @Override
    public Disposable getAllLottery(Observer Observer) {
        Observable<AllMode> observable = RetrofitHelper
                .getService(ILotteryService.class)
                .getAllLottery()
                .map(new HttpResultFunc<>());
        return toSubscribe(observable, Observer);
    }



}
