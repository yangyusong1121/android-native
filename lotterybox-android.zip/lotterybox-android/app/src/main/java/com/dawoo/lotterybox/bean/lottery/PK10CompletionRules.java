package com.dawoo.lotterybox.bean.lottery;

public class PK10CompletionRules {
    private String completionZone;//补牌区
    private int firstSum;//第一次组合点数总和
    private String rules;//补牌规则

    public String getCompletionZone() {
        return completionZone;
    }

    public void setCompletionZone(String completionZone) {
        this.completionZone = completionZone;
    }

    public int getFirstSum() {
        return firstSum;
    }

    public void setFirstSum(int firstSum) {
        this.firstSum = firstSum;
    }

    public String getRules() {
        return rules;
    }

    public void setRules(String rules) {
        this.rules = rules;
    }
}
