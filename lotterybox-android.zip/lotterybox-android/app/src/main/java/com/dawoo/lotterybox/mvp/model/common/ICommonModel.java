package com.dawoo.lotterybox.mvp.model.common;


import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;

/**
 * Created by b on 18-5-24.
 */

public interface ICommonModel {

    Disposable getLtToken(Observer subscriber);

}
