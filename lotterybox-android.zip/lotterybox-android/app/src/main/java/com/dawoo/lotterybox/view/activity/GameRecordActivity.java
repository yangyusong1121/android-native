package com.dawoo.lotterybox.view.activity;

import android.support.annotation.NonNull;
import android.support.design.widget.TabLayout;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.dawoo.coretool.util.LogUtils;
import com.dawoo.coretool.util.date.DateTool;
import com.dawoo.coretool.util.date.DateUtils;
import com.dawoo.lotterybox.ConstantValue;
import com.dawoo.lotterybox.R;
import com.dawoo.lotterybox.bean.CalendarExtraBean;
import com.dawoo.lotterybox.bean.DataCenter;
import com.dawoo.lotterybox.bean.record.AssetsBean;
import com.dawoo.lotterybox.bean.record.GameRecordBean;
import com.dawoo.lotterybox.bean.record.ProfitBean;
import com.dawoo.lotterybox.mvp.presenter.RecordPresenter;
import com.dawoo.lotterybox.mvp.view.INoteRecordHisView;
import com.dawoo.lotterybox.util.ActivityUtil;
import com.dawoo.lotterybox.util.BalanceUtils;
import com.dawoo.lotterybox.util.BottomDialogUtils;
import com.dawoo.lotterybox.util.GameUtil;
import com.dawoo.lotterybox.util.NoteCalendarUtil;
import com.dawoo.lotterybox.util.NumberFormaterUtils;
import com.dawoo.lotterybox.util.SingleToast;
import com.dawoo.lotterybox.view.activity.team.base.OnMultiClickListener;
import com.dawoo.lotterybox.view.view.HeaderView;
import com.hwangjr.rxbus.RxBus;
import com.hwangjr.rxbus.annotation.Subscribe;
import com.hwangjr.rxbus.annotation.Tag;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;
import butterknife.Unbinder;

/**
 * @author jack
 * @date 18-2-15
 * 游戏记录
 */

public class GameRecordActivity extends BaseActivity implements OnRefreshListener, OnLoadMoreListener, INoteRecordHisView {
//    private static final int CHOOSE_CALENDAR_REQUEST_CODE = 001;

    @BindView(R.id.head_view)
    HeaderView mHeaderView;
    @BindView(R.id.status_tabLayOut)
    TabLayout mStatusTabLayOut;
    Unbinder unbinder;
    @BindView(R.id.tv_note_theDayBefore)
    TextView mTvNoteTheDayBefore;
    @BindView(R.id.tv_yinKui_dayBefore)
    TextView mTvYinKuiDayBefore;
    @BindView(R.id.rl_actionTheDayBefore)
    RelativeLayout mRlActionTheDayBefore;
    @BindView(R.id.tv_year)
    TextView mTvYear;
    @BindView(R.id.tv_md)
    TextView mTvMd;
    @BindView(R.id.tv_yinKui_md)
    TextView mTvYinKuiMd;
    @BindView(R.id.rl_ActionCalendar)
    RelativeLayout mRlActionCalendar;
    @BindView(R.id.tv_note_theDayAfter)
    TextView mTvNoteTheDayAfter;
    @BindView(R.id.tv_yinKui_dayAfter)
    TextView mTvYinKuiDayAfter;
    @BindView(R.id.rl_actionTheDayAfter)
    RelativeLayout mRlActionTheDayAfter;
    @BindView(R.id.tv_note_allCode)
    TextView mTvNoteAllCode;

    @BindView(R.id.tv_note_sort)
    TextView mTvNoteSort;

    @BindView(R.id.tv_yinkui_sort)
    TextView mTvYinkuiSort;

    @BindView(R.id.tv_time_sort)
    TextView mTvTimeSort;

    @BindView(R.id.tv_note_sort_down)
    TextView mTvNoteSortDown;
    @BindView(R.id.tv_yinkui_sort_down)
    TextView mTvYinkuiSortDown;
    @BindView(R.id.tv_time_sort_down)
    TextView mTvTimeSortDown;
    @BindView(R.id.swipe_target)
    RecyclerView mSwipeTarget;


    //底部
    @BindView(R.id.account_balance)
    TextView mAccountBalance;
    @BindView(R.id.winning_amount)
    TextView mWinningAmount;
    @BindView(R.id.iv_note_arrow)
    ImageView mIvNoteArrow;

    @BindView(R.id.note_total)
    TextView mNoteTotal;
    @BindView(R.id.yinKui)
    TextView mYinKui;

    @BindView(R.id.note_avail)
    TextView mNoteAvail;
    @BindView(R.id.rebate)
    TextView mRebate;
    @BindView(R.id.bottom_3)
    LinearLayout mBottom3;
    @BindView(R.id.unopen_prize_amount)
    TextView mUnopenPrizeAmount;
    @BindView(R.id.cancel_order)
    TextView mCancelOrder;
    @BindView(R.id.bottom_4)
    LinearLayout mBottom4;
    @BindView(R.id.srl_root)
    SmartRefreshLayout srlRefresh;
    private RecordPresenter mRecordPresenter;
    private NoteRecordAdapter mNoteRecordAdapter;
    private List<GameRecordBean> mHisList = new ArrayList<>();
    private List<CalendarExtraBean> mCalendarExtraBeanList = new ArrayList<>();//要传给日历的数据
    /**
     * 服务器搜索参数
     */
    private String mQueryStartDate;//开始下注时间  默认预加载31的数据
    private String mQueryEndDate;//最后下注时间  默认今天

    /**
     * 本地搜素参数
     */
    private boolean mNoteSort;//是否按投注排序
    private boolean mPlSort; //是否按盈亏排序
    private boolean mTimeSort;//是否按时间排序
    private String mShowStartDate;//开始下注时间  本地搜索时间  "yyyy-MM-dd"
    private String mShowEndDate;//最后下注时间  本地搜索时间  "yyyy-MM-dd"

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mRecordPresenter.onDestory();
        BottomDialogUtils.with(this).destoryTimePick();
    }

    @Override
    protected void createLayoutView() {
        setContentView(R.layout.activity_game_record);

    }
    @Override
    public void onPause() {
        super.onPause();
        BottomDialogUtils.with(this).destoryTimePick();
    }
    @Override
    protected void setErrorHead(LinearLayout llHead) {
        super.setErrorHead(llHead);
        llHead.setVisibility(View.VISIBLE);
    }

    @Override
    protected void setErrorTitleName(TextView tvTitle) {
        super.setErrorTitleName(tvTitle);
        tvTitle.setText("游戏记录");
    }


    @Override
    protected void errorRetry() {
        super.errorRetry();
        initData();
    }

    @Override
    protected void initViews() {
        mHeaderView.setHeader(getString(R.string.game_record), true);
        mStatusTabLayOut.setVisibility(View.GONE);
        mQueryStartDate = DateTool.getTimeFromLong(DateTool.FMT_DATE, DateUtils.getFrontDay(new Date(), 30).getTime());
        mShowStartDate = DateTool.getTimeFromLong(DateTool.FMT_DATE, System.currentTimeMillis());
        mShowEndDate = DateTool.getTimeFromLong(DateTool.FMT_DATE, System.currentTimeMillis());
        mQueryEndDate = DateTool.getTimeFromLong(DateTool.FMT_DATE, System.currentTimeMillis());
        mTvYear.setText(mShowStartDate.substring(0, 4));
        mTvMd.setText(NoteCalendarUtil.reolveDate(mShowStartDate, mShowEndDate));
        initNoteRecordRecyclerView();
        // 设置 下拉刷新，加载更多
        srlRefresh.setOnRefreshListener(this);
        srlRefresh.setOnLoadMoreListener(this);
        setBeforeAndAfterVisbility();
        mTvNoteAllCode.setText(getString(R.string.game_record_species));
        mTvNoteAllCode.setCompoundDrawables(null, null, null, null);
        mTvNoteSort.setText(getString(R.string.game_record_bet_all));
        mTvYinkuiSort.setText(getString(R.string.game_record_win_all));
        mTvTimeSort.setText(getString(R.string.game_record_profit_all));
        mRlActionCalendar.setOnClickListener(new OnMultiClickListener() {
            @Override
            public void onMultiClick(View v) {
                jumpToCalendar();
            }
        });
    }


    private void initNoteRecordRecyclerView() {
        mNoteRecordAdapter = new NoteRecordAdapter(R.layout.adapter_easy_game_record);
        mNoteRecordAdapter.setEmptyView(LayoutInflater.from(this).inflate(R.layout.empty_view, null));
        mSwipeTarget.setLayoutManager(new StaggeredGridLayoutManager(1, StaggeredGridLayoutManager.VERTICAL));
        mNoteRecordAdapter.setNewData(mHisList);
        mSwipeTarget.setAdapter(mNoteRecordAdapter);
    }

    @Override
    protected void initData() {
        checkNetWork();
        if (mRecordPresenter == null) {
            mRecordPresenter = new RecordPresenter(this, this);
        }
        mRecordPresenter.getRecentProfit("", "");
        onRefresh();
    }


    @OnClick({R.id.rl_actionTheDayBefore, R.id.rl_ActionCalendar, R.id.rl_actionTheDayAfter, R.id.rl_action_note_sort, R.id.rl_action_yinkui_sort, R.id.rl_action_time_sort})
    public void onViewClicked(View view) {
        if (view.getId() == R.id.rl_action_note_sort) {
            setNoteSort();
            return;
        } else if (view.getId() == R.id.rl_action_yinkui_sort) {
            setPlSort();
            return;

        } else if (view.getId() == R.id.rl_action_time_sort) {
            setTimeSort();
            return;
        }


        if (!DataCenter.getInstance().isLogin()) {
            ActivityUtil.startLoginActivity();
            return;
        }


        switch (view.getId()) {
            case R.id.rl_actionTheDayBefore:
                if (mShowStartDate.equals(mQueryStartDate)) {
                    SingleToast.showMsg("暂时只能为您展示30天内记录");
                    return;
                }
                String yesterDay = DateTool.getTimeFromLong(
                        DateTool.FMT_DATE, DateTool.getLongFromTime(DateTool.FMT_DATE, mShowStartDate) - 24 * 60 * 60 * 1000);
                mShowStartDate = yesterDay;
                mTvYear.setText(mShowStartDate.substring(0, 4));
                mTvMd.setText(NoteCalendarUtil.reolveDate(mShowStartDate, mShowEndDate));
                onRefresh();
                break;
//            case R.id.rl_ActionCalendar:
//                jumpToCalendar();
//                break;
            case R.id.rl_actionTheDayAfter:
                if (mShowEndDate.equals(mQueryEndDate)) {
                    return;
                }
                String afterDay = DateTool.getTimeFromLong(
                        DateTool.FMT_DATE, DateTool.getLongFromTime(DateTool.FMT_DATE, mShowEndDate) + 24 * 60 * 60 * 1000);
                mShowEndDate = afterDay;
                mTvYear.setText(mShowStartDate.substring(0, 4));
                mTvMd.setText(NoteCalendarUtil.reolveDate(mShowStartDate, mShowEndDate));
                onRefresh();
                break;
            default:
        }
    }


    @OnClick(R.id.ll_assets)
    public void onBottomViewClicked() {
        if (mBottom3.getVisibility() == View.VISIBLE) {
            mIvNoteArrow.setImageResource(R.mipmap.img_gray_arrow_up);
            mBottom3.setVisibility(View.GONE);
            mBottom4.setVisibility(View.GONE);
        } else {
            mIvNoteArrow.setImageResource(R.mipmap.img_grayarrow_down);
            mBottom3.setVisibility(View.VISIBLE);
            mBottom4.setVisibility(View.VISIBLE);
        }
    }

    //跳转到日历
    private void jumpToCalendar() {
       /* Intent intent = new Intent(this, CalendarActivity.class);
        intent.putParcelableArrayListExtra(CalendarActivity.CALENDAR_EXTRA_LIST, (ArrayList<? extends Parcelable>) mCalendarExtraBeanList);
        intent.putExtra(CalendarActivity.START_TIME, mShowStartDate);
        intent.putExtra(CalendarActivity.END_TIME, mShowEndDate);
        startActivityForResult(intent, CHOOSE_CALENDAR_REQUEST_CODE);*/
        BottomDialogUtils.with(this).showTimePickDialog((startDates, endDates) -> {
            mShowStartDate = startDates;
            mShowEndDate = endDates;
            mTvYear.setText(mShowStartDate.substring(0, 4));
            mTvMd.setText(NoteCalendarUtil.reolveDate(mShowStartDate, mShowEndDate));
            setBeforeAndAfterVisbility();
            srlRefresh.autoRefresh();
        });

    }

  /*  @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == CHOOSE_CALENDAR_REQUEST_CODE) {
            if (resultCode == Activity.RESULT_OK) {
                String[] dataArray = data.getStringArrayExtra(CalendarActivity.RESULT_DATE_ARREY);
                mShowStartDate = dataArray[0];
                mShowEndDate = dataArray[1];
                mTvYear.setText(mShowStartDate.substring(0, 4));
                mTvMd.setText(NoteCalendarUtil.reolveDate(mShowStartDate, mShowEndDate));
                initData();
                setBeforeAndAfterVisbility();
            }
        }
    }*/


    private void setNoteSort() {
        mNoteSort = !mNoteSort;
        if (mNoteSort) {
            mTvNoteSort.setVisibility(View.GONE);
            mTvNoteSortDown.setVisibility(View.VISIBLE);
            mPlSort = false;
            mTimeSort = false;
            mTvYinkuiSort.setVisibility(View.VISIBLE);
            mTvYinkuiSortDown.setVisibility(View.GONE);
            mTvTimeSort.setVisibility(View.VISIBLE);
            mTvTimeSortDown.setVisibility(View.GONE);
        } else {
            mTvNoteSort.setVisibility(View.VISIBLE);
            mTvNoteSortDown.setVisibility(View.GONE);
        }
        GameUtil.sortBet(mNoteSort, mHisList);
        mNoteRecordAdapter.notifyDataSetChanged();
    }

    private void setPlSort() {
        mPlSort = !mPlSort;
        if (mPlSort) {
            mTvYinkuiSort.setVisibility(View.GONE);
            mTvYinkuiSortDown.setVisibility(View.VISIBLE);
            mTimeSort = false;
            mNoteSort = false;
            mTvNoteSort.setVisibility(View.VISIBLE);
            mTvNoteSortDown.setVisibility(View.GONE);
            mTvTimeSort.setVisibility(View.VISIBLE);
            mTvTimeSortDown.setVisibility(View.GONE);
        } else {
            mTvYinkuiSort.setVisibility(View.VISIBLE);
            mTvYinkuiSortDown.setVisibility(View.GONE);
        }
        GameUtil.sortFormWin(mPlSort, mHisList);
        mNoteRecordAdapter.notifyDataSetChanged();
    }

    private void setTimeSort() {
        mTimeSort = !mTimeSort;
        if (mTimeSort) {
            mTvTimeSort.setVisibility(View.GONE);
            mTvTimeSortDown.setVisibility(View.VISIBLE);
            mNoteSort = false;
            mPlSort = false;
            mTvNoteSort.setVisibility(View.VISIBLE);
            mTvNoteSortDown.setVisibility(View.GONE);
            mTvYinkuiSort.setVisibility(View.VISIBLE);
            mTvYinkuiSortDown.setVisibility(View.GONE);
        } else {
            mTvTimeSort.setVisibility(View.VISIBLE);
            mTvTimeSortDown.setVisibility(View.GONE);
        }
        GameUtil.sortFormPri(mTimeSort, mHisList);
        mNoteRecordAdapter.notifyDataSetChanged();
    }


    public void onLoadMore() {

    }


    public void onRefresh() {

        if (!DataCenter.getInstance().isLogin()) {
            return;
        }
        mRecordPresenter.getAssets(mShowStartDate, mShowEndDate, "", "");
        mRecordPresenter.getOrderGroup(mShowStartDate, mShowEndDate);
    }

    @Override
    public void onRefreshResult(Object o) {
        errorRetryResult();
        srlRefresh.finishRefresh();
        srlRefresh.finishLoadMore();
        mHisList.clear();
        List<GameRecordBean> gameRecordBeans = (List<GameRecordBean>) o;
        if (gameRecordBeans != null && !gameRecordBeans.isEmpty()) {
            mHisList.addAll(gameRecordBeans);
        }
        filterData();
    }


    //根据当前的  时间 彩种  状态  过滤数据
    private void filterData() {
        GameUtil.sortData(mNoteSort, mPlSort, mTimeSort, mHisList);
        mNoteRecordAdapter.notifyDataSetChanged();
    }


    @Override
    public void onLoadMoreResult(Object o) {

    }

    @Override
    public void onLotteryDataResult(Object o) {
        errorRetryResult();
    }

    @Override
    public void onAssetsResult(Object o) {
        AssetsBean assetsBean = (AssetsBean) o;

        //底部
        mAccountBalance.setText(NumberFormaterUtils.formaterD2S(assetsBean.getBalance()));
        mWinningAmount.setText(NumberFormaterUtils.formaterD2S(assetsBean.getPayout()));
        mNoteTotal.setText(NumberFormaterUtils.formaterD2S(assetsBean.getBetAmount()));
        mYinKui.setText(NumberFormaterUtils.formaterD2S(assetsBean.getProfit()));
        mNoteAvail.setText(NumberFormaterUtils.formaterD2S(assetsBean.getEffective()));
        mRebate.setText(NumberFormaterUtils.formaterD2S(assetsBean.getRebate()));
        mUnopenPrizeAmount.setText(NumberFormaterUtils.formaterD2S(assetsBean.getUnOpen()));
        mCancelOrder.setText(NumberFormaterUtils.formaterD2S(assetsBean.getRevoke()));

        //上面日历
        mTvYinKuiDayBefore.setText(getString(R.string.account_yinKui, NumberFormaterUtils.formaterD2S(assetsBean.getBeforeProfit())));
        mTvYinKuiDayAfter.setText(getString(R.string.account_yinKui, NumberFormaterUtils.formaterD2S(assetsBean.getAfterProfit())));
        mTvYinKuiMd.setText(getString(R.string.account_yinKui, NumberFormaterUtils.formaterD2S(assetsBean.getProfit())));
        setBeforeAndAfterVisbility();
    }

    //前一天  后一天的  显示和隐藏
    private void setBeforeAndAfterVisbility() {
        if (mShowStartDate.equals(DateTool.getTimeFromLong(DateTool.FMT_DATE, DateUtils.getFrontDay(new Date(), 30).getTime()))) {
            mRlActionTheDayBefore.setClickable(false);
            mTvNoteTheDayBefore.setVisibility(View.GONE);
            mTvYinKuiDayBefore.setVisibility(View.GONE);
        } else {
            mRlActionTheDayBefore.setClickable(true);
            mTvNoteTheDayBefore.setVisibility(View.VISIBLE);
            mTvYinKuiDayBefore.setVisibility(View.VISIBLE);
        }

        if (mShowEndDate.equals(DateTool.getTimeFromLong(DateTool.FMT_DATE, System.currentTimeMillis()))) {
            mRlActionTheDayAfter.setClickable(false);
            mTvYinKuiDayAfter.setVisibility(View.GONE);
            mTvNoteTheDayAfter.setVisibility(View.GONE);
        } else {
            mRlActionTheDayAfter.setClickable(true);
            mTvYinKuiDayAfter.setVisibility(View.VISIBLE);
            mTvNoteTheDayAfter.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void onRecentProfit(Object o) {
        List<ProfitBean> list = (List<ProfitBean>) o;
        setProfitData(list);
    }

    //得到每天的盈亏数据
    private void setProfitData(List<ProfitBean> list) {
        mCalendarExtraBeanList.clear();
        for (ProfitBean profitBean : list) {
            CalendarExtraBean calendarExtraBean = new CalendarExtraBean();
            calendarExtraBean.setValue(profitBean.getProfit());
            calendarExtraBean.setTime(DateTool.getLongFromTime(DateTool.FMT_DATE, profitBean.getTdate()));
            mCalendarExtraBeanList.add(calendarExtraBean);
        }
    }

    @Override
    public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
        onLoadMore();
    }

    @Override
    public void onRefresh(@NonNull RefreshLayout refreshLayout) {
        onRefresh();
    }


    private class NoteRecordAdapter extends BaseQuickAdapter {

        public NoteRecordAdapter(int layoutResId) {
            super(layoutResId);
        }

        @Override
        protected void convert(BaseViewHolder helper, Object item) {
            GameRecordBean recordHis = (GameRecordBean) item;
            helper.setText(R.id.tv_item_codeName, recordHis.getLotteryName());
            helper.setText(R.id.tv_item_betCode, BalanceUtils.getScalsBalance(recordHis.getBetamount()));

            helper.setText(R.id.tv_item_time_yyMMdd, BalanceUtils.getScalsBalance(recordHis.getProfitloss()));
            helper.setText(R.id.tv_item_prize_status, BalanceUtils.getScalsBalance(recordHis.getPayout()));
            if (recordHis.getProfitloss() < 0) {
                helper.setTextColor(R.id.tv_item_time_yyMMdd, getResources().getColor(R.color.history_item_red));
            } else {
                helper.setTextColor(R.id.tv_item_time_yyMMdd, getResources().getColor(R.color.history_item_green));
            }
            helper.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    RxBus.get().post(ConstantValue.EVENT_GAME_RECORD_CODE, recordHis.getCode() + "," + recordHis.getLotteryName());
                    finish();
                }
            });

            if (helper.getAdapterPosition() % 2 == 0) {
                helper.itemView.setBackgroundColor(getResources().getColor(R.color.white));
            } else {
                helper.itemView.setBackgroundColor(getResources().getColor(R.color.bgColor));
            }
        }
    }

    @Subscribe(tags = {@Tag(ConstantValue.EVENT_TYPE_NETWORK_EXCEPTION)})
    public void shrinkRefreshView(String s) {
        returnStateCode();
        LogUtils.d(s);
        //  收起刷新
        srlRefresh.finishRefresh();
        srlRefresh.finishLoadMore();
    }


}