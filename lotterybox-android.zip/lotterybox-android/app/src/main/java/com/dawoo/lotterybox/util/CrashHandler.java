package com.dawoo.lotterybox.util;

import com.dawoo.lotterybox.BoxApplication;
import com.dawoo.lotterybox.R;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.lang.Thread.UncaughtExceptionHandler;

public class CrashHandler implements UncaughtExceptionHandler {
    private static CrashHandler instance;

    public static CrashHandler getInstance() {
        if (instance == null) {
            instance = new CrashHandler();
        }
        return instance;
    }

    public void init() {
        Thread.setDefaultUncaughtExceptionHandler(this);
    }

    @Override
    public void uncaughtException(Thread arg0, Throwable arg1) {
        try {
            arg1.printStackTrace();
            arg1.getStackTrace();
            StringBuffer m = new StringBuffer();
            Writer writer = new StringWriter();
            PrintWriter printWriter = new PrintWriter(writer);
            arg1.printStackTrace(printWriter);
            Throwable cause = arg1.getCause();
            while (cause != null) {
                cause.printStackTrace(printWriter);
                cause = cause.getCause();
            }
            printWriter.close();
            String result = writer.toString();//message
            String currentTime = System.currentTimeMillis() + "";
            String mark = currentTime.substring(currentTime.length() - 6);

            UploadErrorLinesUtil.uploadAppCrashLog(
                    result,
                    BoxApplication.getContext().getString(R.string.app_code),
                    mark,
                    true);

        } catch (Exception e) {
            e.printStackTrace();
        }


        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.exit(0);
    }

}
