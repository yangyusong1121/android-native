package com.dawoo.lotterybox.bean.help;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.List;

public class HelpTwoBean implements Parcelable {
    private String title;
    private String content;
    private List<HelpThreeBean> three;

    public List<HelpThreeBean> getThree() {
        return three;
    }

    public void setThree(List<HelpThreeBean> three) {
        this.three = three;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public HelpTwoBean() {
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.title);
        dest.writeString(this.content);
        dest.writeTypedList(this.three);
    }

    protected HelpTwoBean(Parcel in) {
        this.title = in.readString();
        this.content = in.readString();
        this.three = in.createTypedArrayList(HelpThreeBean.CREATOR);
    }

    public static final Creator<HelpTwoBean> CREATOR = new Creator<HelpTwoBean>() {
        @Override
        public HelpTwoBean createFromParcel(Parcel source) {
            return new HelpTwoBean(source);
        }

        @Override
        public HelpTwoBean[] newArray(int size) {
            return new HelpTwoBean[size];
        }
    };
}
