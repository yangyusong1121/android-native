package com.dawoo.lotterybox.bean;

import java.util.List;

/**
 * Created by alex on 18-4-25.
 */

public class TeamSalaryBean {

    /**
     * error : 0
     * data : [{"gradeId":10111,"effective_player_count":1,"effective_bet_money":2000,"effective_deposit_money":1000,"ratio":1000,"loss_money":100},{"gradeId":10112,"effective_player_count":2,"effective_bet_money":3000,"effective_deposit_money":2000,"ratio":1200,"loss_money":200},{"gradeId":10113,"effective_player_count":3,"effective_bet_money":4000,"effective_deposit_money":3000,"ratio":1500,"loss_money":300}]
     */

    private int error;
    private List<DataBean> data;

    public int getError() {
        return error;
    }

    public void setError(int error) {
        this.error = error;
    }

    public List<DataBean> getData() {
        return data;
    }

    public void setData(List<DataBean> data) {
        this.data = data;
    }

    public static class DataBean {
        /**
         * gradeId : 10111
         * effective_player_count : 1
         * effective_bet_money : 2000.0
         * effective_deposit_money : 1000.0
         * ratio : 1000.0
         * loss_money : 100.0
         */

        private int gradeId;
        private int effective_player_count;
        private double effective_bet_money;
        private double effective_deposit_money;
        private double ratio;
        private double loss_money;

        public int getGradeId() {
            return gradeId;
        }

        public void setGradeId(int gradeId) {
            this.gradeId = gradeId;
        }

        public int getEffective_player_count() {
            return effective_player_count;
        }

        public void setEffective_player_count(int effective_player_count) {
            this.effective_player_count = effective_player_count;
        }

        public double getEffective_bet_money() {
            return effective_bet_money;
        }

        public void setEffective_bet_money(double effective_bet_money) {
            this.effective_bet_money = effective_bet_money;
        }

        public double getEffective_deposit_money() {
            return effective_deposit_money;
        }

        public void setEffective_deposit_money(double effective_deposit_money) {
            this.effective_deposit_money = effective_deposit_money;
        }

        public double getRatio() {
            return ratio;
        }

        public void setRatio(double ratio) {
            this.ratio = ratio;
        }

        public double getLoss_money() {
            return loss_money;
        }

        public void setLoss_money(double loss_money) {
            this.loss_money = loss_money;
        }
    }
}
