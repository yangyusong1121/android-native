package com.dawoo.lotterybox.util;

import android.graphics.Color;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;

import com.dawoo.lotterybox.BoxApplication;
import com.dawoo.lotterybox.view.view.RecycleViewDivider;

public class PlayRecyclerviewUtils {


    /**
     * 增加矩形RecyclerView   上下左右 间隔
     *
     * @param recyclerview
     */
    public static void addHorizontalSpace(RecyclerView recyclerview,int num) {
        int itemDecorationCount = recyclerview.getItemDecorationCount();
        if (itemDecorationCount==0){
            recyclerview.addItemDecoration(new GridItemDecoration(BoxApplication.getContext(), 2,  Color.WHITE) {
                @Override
                public boolean[] getItemSidesIsHaveOffsets(int itemPosition) {
                    //顺序:left, top, right, bottom
                    boolean[] booleans = {true, true, true, true};
//                    switch (itemPosition % 2) {
//                        case 0:
//                            //每一行第一个只显示右边距和下边距
//                            booleans[2] = true;
//                            booleans[3] = true;
//                            break;
//                        case 1:
//                            //每一行第二个只显示左边距和下边距
//                            booleans[0] = true;
//                            booleans[3] = true;
//                            break;
//                    }
                    return booleans;
                }
            });
          //  recyclerview.addItemDecoration(new RecycleViewDivider(BoxApplication.getContext(), LinearLayoutManager.HORIZONTAL, 10, Color.WHITE));
        }
    }


    /**
     * 增加列表 RecyclerView  间隔
     *
     * @param recyclerview
     */
    public static void addVerticalSpace(RecyclerView recyclerview) {
        recyclerview.addItemDecoration(new RecycleViewDivider(BoxApplication.getContext(), LinearLayoutManager.VERTICAL, 10, Color.WHITE));

    }


}
