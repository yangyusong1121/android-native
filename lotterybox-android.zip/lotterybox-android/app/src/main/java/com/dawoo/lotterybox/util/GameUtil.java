package com.dawoo.lotterybox.util;

import android.util.Log;

import com.dawoo.coretool.util.date.DateTool;
import com.dawoo.lotterybox.bean.record.CancelNumRecordHis;
import com.dawoo.lotterybox.bean.record.CancelRecordHisData;
import com.dawoo.lotterybox.bean.record.ChaseNumRecordHis;
import com.dawoo.lotterybox.bean.record.GameRecordBean;
import com.dawoo.lotterybox.bean.record.NoteRecordHis;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import static com.dawoo.lotterybox.view.activity.record.HistoryRepotFormFragment.status;

/**
 * Created by archar on 18-2-18.
 */

public class GameUtil {


    /**
     * 投注记录排序
     *
     * @param isBit
     * @param isWin
     * @param isPri
     * @param hisListShow
     */
    public static void sortData(boolean isBit,
                                boolean isWin,
                                boolean isPri,
                                List<GameRecordBean> hisListShow) {

        if (isBit) {
            sortBet(isBit, hisListShow);
        } else if (isWin) {
            sortFormWin(isWin, hisListShow);
        } else if (isPri) {
            sortFormPri(isPri, hisListShow);
        }


    }


    public static void sortBet(boolean sortAmount, List<GameRecordBean> hisListShow) {

        Collections.sort(hisListShow, new Comparator<GameRecordBean>() {
            @Override
            public int compare(GameRecordBean o1, GameRecordBean o2) {
                if (sortAmount) {
                    if (o1.getBetamount() > o2.getBetamount()) {
                        return -1;
                    }
                    return 0;
                } else {
                    if (o1.getBetamount() < o2.getBetamount()) {
                        return -1;
                    }
                    return 0;
                }
            }
        });
    }


    public static void sortFormWin(boolean sortTime, List<GameRecordBean> hisListShow) {

        Collections.sort(hisListShow, new Comparator<GameRecordBean>() {
            @Override
            public int compare(GameRecordBean o1, GameRecordBean o2) {
                if (sortTime) {
                    if (o1.getPayout() > o2.getPayout()) {
                        return -1;
                    }
                    return 0;
                } else {
                    if (o1.getPayout() < o2.getPayout()) {
                        return -1;
                    }
                    return 0;
                }
            }
        });

    }

    public static void sortFormPri(boolean status, List<GameRecordBean> hisListShow) {

        Collections.sort(hisListShow, new Comparator<GameRecordBean>() {
            @Override
            public int compare(GameRecordBean o1, GameRecordBean o2) {
                if (status) {
                    if (o1.getProfitloss() > o2.getProfitloss()) {
                        return -1;
                    }
                    return 0;
                } else {
                    if (o1.getProfitloss() < o2.getProfitloss()) {
                        return -1;
                    }
                    return 0;
                }
            }
        });
    }


    /**
     * 追号记录排序
     *
     * @param noteSort
     * @param profitSort
     * @param timeSort
     * @param hisListShow
     */
    private static void sortData1(boolean noteSort,
                                  boolean profitSort,
                                  boolean timeSort,
                                  List<ChaseNumRecordHis> hisListShow) {

        if (noteSort) {
            sortFormNote1(hisListShow);
        }
        if (profitSort) {
            sortFormProfit1(hisListShow);
        }
        if (timeSort) {
            sortFormBetTime1(hisListShow);
        }

    }

    private static void sortFormNote1(List<ChaseNumRecordHis> hisListShow) {

        Collections.sort(hisListShow, new Comparator<ChaseNumRecordHis>() {
            @Override
            public int compare(ChaseNumRecordHis o1, ChaseNumRecordHis o2) {
                if (o1.getBetAmount() > o2.getBetAmount()) {
                    return -1;
                }
                return 0;
            }
        });
    }


    private static void sortFormBetTime1(List<ChaseNumRecordHis> hisListShow) {

        Collections.sort(hisListShow, new Comparator<ChaseNumRecordHis>() {
            @Override
            public int compare(ChaseNumRecordHis o1, ChaseNumRecordHis o2) {
                if (o1.getBetTime() > o2.getBetTime()) {
                    return -1;
                }
                return 0;
            }
        });

    }

    private static void sortFormProfit1(List<ChaseNumRecordHis> hisListShow) {

        Collections.sort(hisListShow, new Comparator<ChaseNumRecordHis>() {
            @Override
            public int compare(ChaseNumRecordHis o1, ChaseNumRecordHis o2) {
                if (o1.getProfit() > o2.getProfit()) {
                    return -1;
                }
                return 0;
            }
        });
    }


}
