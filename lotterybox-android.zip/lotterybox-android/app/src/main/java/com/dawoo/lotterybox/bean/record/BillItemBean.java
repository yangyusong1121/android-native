package com.dawoo.lotterybox.bean.record;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by rain on 18-4-19.
 */

public class BillItemBean implements Parcelable {
    private long completionTime=0;
    private String item;
    private String balance;
    private String money;
    private String type;
    private String way;
    private long createTime=0;

    @Override
    public String toString() {
        return "BillItemBean{" +
                "completionTime=" + completionTime +
                ", item='" + item + '\'' +
                ", balance='" + balance + '\'' +
                ", money='" + money + '\'' +
                ", type='" + type + '\'' +
                ", way='" + way + '\'' +
                ", createTime=" + createTime +
                ", status='" + status + '\'' +
                '}';
    }

    private String status;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public long getCreateTime() {
        return createTime;
    }

    public void setCreateTime(long createTime) {
        this.createTime = createTime;
    }

    public long getCompletionTime() {
        return completionTime;
    }

    public void setCompletionTime(long completionTime) {
        this.completionTime = completionTime;
    }

    public String getItem() {
        return item;
    }

    public void setItem(String item) {
        this.item = item;
    }

    public String getBalance() {
        return balance;
    }

    public void setBalance(String balance) {
        this.balance = balance;
    }

    public String getMoney() {
        return money;
    }

    public void setMoney(String money) {
        this.money = money;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getWay() {
        return way;
    }

    public void setWay(String way) {
        this.way = way;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeLong(this.completionTime);
        dest.writeString(this.item);
        dest.writeString(this.balance);
        dest.writeString(this.money);
        dest.writeString(this.type);
        dest.writeString(this.way);
        dest.writeLong(this.createTime);
        dest.writeString(this.status);
    }

    public BillItemBean() {
    }

    protected BillItemBean(Parcel in) {
        this.completionTime = in.readLong();
        this.item = in.readString();
        this.balance = in.readString();
        this.money = in.readString();
        this.type = in.readString();
        this.way = in.readString();
        this.createTime = in.readLong();
        this.status = in.readString();
    }

    public static final Creator<BillItemBean> CREATOR = new Creator<BillItemBean>() {
        @Override
        public BillItemBean createFromParcel(Parcel source) {
            return new BillItemBean(source);
        }

        @Override
        public BillItemBean[] newArray(int size) {
            return new BillItemBean[size];
        }
    };
}
