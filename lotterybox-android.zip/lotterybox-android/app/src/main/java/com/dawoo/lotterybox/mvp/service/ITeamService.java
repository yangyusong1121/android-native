package com.dawoo.lotterybox.mvp.service;

import com.dawoo.lotterybox.bean.CheckMemberTypeBean;
import com.dawoo.lotterybox.bean.SaveMemberTypeBean;
import com.dawoo.lotterybox.bean.TeamAssetsBean;
import com.dawoo.lotterybox.bean.TeamBillBean;
import com.dawoo.lotterybox.bean.TeamMemberBean;
import com.dawoo.lotterybox.bean.TeamParticipationBean;
import com.dawoo.lotterybox.bean.TeamReportBean;
import com.dawoo.lotterybox.bean.TeamSalaryBean;
import com.dawoo.lotterybox.bean.TeamStateBean;
import com.dawoo.lotterybox.bean.TeamhasRatioBean;
import com.dawoo.lotterybox.net.HttpResult;

import java.util.List;

import io.reactivex.Observable;
import io.reactivex.Single;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;

/**
 * Created by alex on 18-4-24.
 *
 * @author alex
 */

public interface ITeamService {

    /**
     * 团队账变统计数据
     *
     * @return
     */
    @GET("hall/mobile/billchange/get-team-assets.html")
    Observable<HttpResult<TeamAssetsBean>> getTeamDataAssets(@Query("search.queryStartDate") String startDate, @Query("search.queryEndDate") String endDate);

    /**
     * 首页统计数据
     *
     * @return
     */
    @GET("hall/mobile/team/data-stats.html")
    Observable<HttpResult<TeamStateBean>> getTeamDataState(@Query("search.startDate") String startDate
            , @Query("search.endDate") String endDate, @Query("dateFlag") int dateFlag);

    /**
     * 首页统计数据搜索
     *
     * @return
     */
    @GET("hall/mobile/team/data-stats.html")
    Observable<HttpResult<TeamStateBean>> getTeamDataStateSearch(@Query("search.startDate") String startDate
            , @Query("search.endDate") String endDate, @Query("dateFlag") String dateFlag);

    /**
     * 成员列表
     */
    @GET("hall/mobile/team/get-members.html")
    Observable<HttpResult<List<TeamMemberBean>>> getTeamMember(@Query("search.startDate") String startDate
            , @Query("search.endDate") String endDate, @Query("search.playerType") String playerType
            , @Query("paging.pageSize") String pageSize, @Query("paging.pageNumber") String pageNumber);

    /**
     * 成员列表
     */
    @GET("hall/mobile/team/get-members.html")
    Observable<HttpResult<List<TeamMemberBean>>> getTeamMember(@Query("search.playerType") String playerType
            , @Query("paging.pageSize") String pageSize, @Query("paging.pageNumber") String pageNumber, @Query("search.playerName") String playerName);

    /**
     * 团队报表
     */
    @GET("hall/mobile/team/get-members-report.html")
    Observable<TeamReportBean> getTeamReport(@Query("search.startDate") String startDate
            , @Query("search.endDate") String endDate, @Query("paging.pageSize") String pageSize
            , @Query("paging.pageNumber") String pageNumber);

    /**
     * 账变明细
     */
    @GET("hall/mobile/billchange/get-team-changes.html")
    Observable<HttpResult<List<TeamBillBean>>> getTeamChanges(@Query("search.queryStartDate") String startDate
            , @Query("search.queryEndDate") String endDate, @Query("search.way") String way
            , @Query("search.type") String type, @Query("search.item") String item, @Query("paging.pageNumber") int pageNumber, @Query("paging.pageSize") int pageSize, @Query("order") String order, @Query("property") String property);

    /**
     * 日工资
     */
    @FormUrlEncoded
    @POST("hall/mobile/team/get-agent-salary.html")
    Observable<TeamSalaryBean> getTeamSalary(@Field("playerId") String playerId);

    /**
     * 分红
     */
    @FormUrlEncoded
    @POST("hall/mobile/team/get-agent-dividen.html")
    Observable<TeamParticipationBean> getTeamParticipation(@Field("playerId") String playerId);

    /**
     * 代理本身是否存在分红日工资方案
     */
    @GET("hall/mobile/team/get-agent-hasRatio.html")
    Observable<HttpResult<TeamhasRatioBean>> getTeamHasRatio();

    /**
     * 保存日工资
     */
    @FormUrlEncoded
    @POST("hall/mobile/team/agent-salary-save.html")
    Observable<HttpResult<Boolean>> getSaveTeamSalary(@Field("jsonStr") String jsonStr);

    /**
     * 保存分红
     */
    @FormUrlEncoded
    @POST("hall/mobile/team/agent-dividen-save.html")
    Observable<HttpResult<Boolean>> getSaveParticipation(@Field("jsonStr") String jsonStr);

    /**
     * 会员申请代理审核列表
     */
    @GET("hall/mobile/team/check-member-type.html")
    Observable<HttpResult<List<CheckMemberTypeBean>>> getCheckMemberType();

    /**
     * 保存代理审核
     *
     * @param id
     * @param status
     * @return
     */
    @FormUrlEncoded
    @POST("hall/mobile/team/save-member-type.html")
    Observable<SaveMemberTypeBean> saveMemberType(@Field("id") String id, @Field("status") String status);

    /**
     * 团队成员详情
     */
    @GET("hall/mobile/team/get-lower-level-info.html")
    Single<HttpResult<Object>>getPlayerDetail(@Query("search.id")String id,@Query("search.playerType")String type);
}
