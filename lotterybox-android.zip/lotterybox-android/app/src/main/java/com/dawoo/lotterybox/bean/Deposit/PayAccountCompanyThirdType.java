package com.dawoo.lotterybox.bean.Deposit;


import com.dawoo.lotterybox.R;
import com.dawoo.lotterybox.bean.lottery.lotteryenum.ICodeEnum;

/**
 * Created by tom on 15-9-6.
 */
public enum PayAccountCompanyThirdType implements ICodeEnum {
    //公司入款第三方支付类型
    WECHAT("wechatpay", "微信支付"),
    ALIPAY("alipay", "支付宝"),
    ONE_CODE_PAY("onecodepay", "一码付"),
    UNIOP_PAY("unionpay", "qq钱包"),
    BD_WWALLET("bdwallet", "百度钱包"),
    JD_WALLET("jdwallet", "京东钱包");
    PayAccountCompanyThirdType(String code, String trans) {
        this.code = code;
        this.trans = trans;
    }

    private String code;
    private String trans;


    @Override
    public String getCode() {
        return code;
    }

    @Override
    public String getTrans() {
        return trans;
    }
}
