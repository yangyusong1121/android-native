package com.dawoo.lotterybox.util;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.text.TextUtils;

import com.blankj.utilcode.util.ActivityUtils;
import com.blankj.utilcode.util.LogUtils;
import com.blankj.utilcode.util.SPUtils;
import com.bumptech.glide.load.model.GlideUrl;
import com.dawoo.coretool.ToastUtil;
import com.dawoo.lotterybox.BoxApplication;
import com.dawoo.lotterybox.ConstantValue;
import com.dawoo.lotterybox.bean.DataCenter;
import com.dawoo.lotterybox.bean.Deposit.PayDetailBean;
import com.dawoo.lotterybox.bean.lottery.Handicap;
import com.dawoo.lotterybox.bean.lottery.lotteryenum.BaseLotteryEnum;
import com.dawoo.lotterybox.view.activity.LoginActivity;
import com.dawoo.lotterybox.view.activity.account.deposit.PostDepositActivity;
import com.dawoo.lotterybox.view.activity.chart.BaseChartActivity;
import com.dawoo.lotterybox.view.activity.chart.lhc.SMRecordActivity;
import com.dawoo.lotterybox.view.activity.chart.select5.Select5TrendChartActivity;
import com.dawoo.lotterybox.view.activity.chart.sfc.NCTrendChatActivity;
import com.dawoo.lotterybox.view.activity.chart.k3.K3TrendChartActivity;
import com.dawoo.lotterybox.view.activity.chart.keno2.Bjkl8TrendChartActivity;
import com.dawoo.lotterybox.view.activity.chart.keno2.Xy28TrendChartActivity;
import com.dawoo.lotterybox.view.activity.chart.pk10.PK10TrendChartActivity;
import com.dawoo.lotterybox.view.activity.chart.ssc.ChartSSCActivity;
import com.dawoo.lotterybox.view.activity.lottery.k3.K3AActivity;
import com.dawoo.lotterybox.view.activity.lottery.k3.K3BActivity;
import com.dawoo.lotterybox.view.activity.lottery.keno.BJKL8Activity;
import com.dawoo.lotterybox.view.activity.lottery.keno.XY28Activity;
import com.dawoo.lotterybox.view.activity.lottery.pk10.PK10AActivity;
import com.dawoo.lotterybox.view.activity.lottery.pk10.PK10BActivity;
import com.dawoo.lotterybox.view.activity.lottery.pk10.PK10BaccaratActivity;
import com.dawoo.lotterybox.view.activity.lottery.pk10.PK10CattleActivity;
import com.dawoo.lotterybox.view.activity.lottery.qt.QTAActivity;
import com.dawoo.lotterybox.view.activity.lottery.qt.QTBActivity;
import com.dawoo.lotterybox.view.activity.lottery.select5.GDSelectAActivity;
import com.dawoo.lotterybox.view.activity.lottery.ssc.SSCBActivity;
import com.dawoo.lotterybox.view.activity.record.RecentOpenRecActivity;
import com.dawoo.lotterybox.view.activity.lottery.sfc.CqxyncActivity;
import com.dawoo.lotterybox.view.activity.lottery.ssc.SSCAActivity;
import com.dawoo.lotterybox.view.activity.lottery.lhc.HKSMActivity;
import com.dawoo.lotterybox.view.activity.webview.WebViewActivity;

import java.util.ArrayList;
import java.util.List;

import static com.dawoo.lotterybox.ConstantValue.LT_CODE;
import static com.dawoo.lotterybox.ConstantValue.LT_NAME;
import static com.dawoo.lotterybox.ConstantValue.LT_TYPE;

/**
 * 一些页面的跳转
 * Created by benson on 18-1-14.
 */

public class ActivityUtil {
    private static Context mContext = BoxApplication.getContext();

    public static void setContext(Context context) {
        mContext = context;
    }

    /**
     * 进入webview
     */
    public static void startWebView(GlideUrl glideUrl, String type) {
        String url = glideUrl.toStringUrl();
        LogUtils.e("web_url:" + url);
        if (TextUtils.isEmpty(url)) {
            SingleToast.showMsg("链接地址为空");
            return;
        }

        if (!url.contains("http")) {
            if (!NetUtil.isURL(url)) {
                if (!url.startsWith("/")) {
                    url = DataCenter.getInstance().getHsot() + "/" + url;
                } else {

                    url = DataCenter.getInstance().getHsot() + url;
                }
            } else {
                if (!url.startsWith("http")) {
                    url = "http://" + url;
                }
            }
        }
        LogUtils.e("web_url:2 " + url);
        Intent intent = new Intent(mContext, WebViewActivity.class);
        intent.putExtra(ConstantValue.WEBVIEW_URL, url);
        intent.putExtra(ConstantValue.WEBVIEW_TYPE, type);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        mContext.startActivity(intent);
    }
    public static void startWebView(String url, String type) {

        LogUtils.e("web_url:" + url);
        if (TextUtils.isEmpty(url)) {
            SingleToast.showMsg("链接地址为空");
            return;
        }

        if (!url.contains("http")) {
            if (!NetUtil.isURL(url)) {
                if (!url.startsWith("/")) {
                    url = DataCenter.getInstance().getHsot() + "/" + url;
                } else {

                    url = DataCenter.getInstance().getHsot() + url;
                }
            } else {
                if (!url.startsWith("http")) {
                    url = "http://" + url;
                }
            }
        }
        LogUtils.e("web_url:2 " + url);
        Intent intent = new Intent(mContext, WebViewActivity.class);
        intent.putExtra(ConstantValue.WEBVIEW_URL, url);
        intent.putExtra(ConstantValue.WEBVIEW_TYPE, type);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        mContext.startActivity(intent);
    }

    /**
     * 去客服
     */
    public static void gotoCustomerService() {
        String csLink = SPUtils.getInstance().getString("cslink", "");
        //startWebView(NetUtil.handleUrl(csLink), ConstantValue.WEBVIEW_TYPE);

        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.setData(Uri.parse(csLink));
        mContext.startActivity(intent);
    }

    public static boolean isLogin() {
        if (DataCenter.getInstance().getUser().isLogin()) {
            return true;
        }
        ActivityUtils.startActivity(LoginActivity.class);
        return false;
    }


    public static void startLoginActivity() {
        Intent intent = new Intent(mContext, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        mContext.startActivity(intent);
    }

    /**
     * 进入最近的开奖记录activity
     *
     * @param lotteryCode
     */
    public static void startRecentOpenRecActivity(String lotteryCode, String lotteryName, String lotteryType) {
        Intent intent = new Intent(mContext, RecentOpenRecActivity.class);
        intent.putExtra(ConstantValue.LT_CODE, lotteryCode);
        intent.putExtra(ConstantValue.LT_NAME, lotteryName);
        intent.putExtra(ConstantValue.LT_TYPE, lotteryType);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        mContext.startActivity(intent);
    }

    /**
     * 进入投注activity
     *
     * @param clazz
     * @param name
     * @param code
     */
    public static void startNoteActivity(Class clazz, String name, String code, String mode) {
        Intent intent = new Intent(mContext, clazz);
        intent.putExtra(LT_TYPE, mode);
        intent.putExtra(LT_NAME, name);
        intent.putExtra(LT_CODE, code);
        mContext.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
    }


    /**
     * 进入趋势图activity
     *
     * @param clazz
     */
    private static void startChartActivity(Class clazz, ArrayList<Handicap> list, String name, String code) {
        Intent intent = new Intent(mContext, clazz);
        intent.putExtra(LT_NAME, name);
        intent.putExtra(LT_CODE, code);
        intent.putParcelableArrayListExtra(ConstantValue.RENCT_DATA, list);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        mContext.startActivity(intent);
    }

    public static void startNoteActivity(String mode, String type, String code, String name) {
        if (BaseLotteryEnum.SSC.getType().equals(type)) {
            startActivityByModel(SSCAActivity.class, SSCBActivity.class, mode, code, name, type);
        } else if (BaseLotteryEnum.PK10.getType().equals(type)) {
            startActivityByModel(PK10AActivity.class, PK10BActivity.class, mode, code, name, type);

        } else if (BaseLotteryEnum.LHC.getType().equals(type)) {
            startNoteActivity(HKSMActivity.class, name, code, type);
        } else if (BaseLotteryEnum.K3.getType().equals(type)) {
            startActivityByModel(K3AActivity.class, K3BActivity.class, mode, code, name, type);

        } else if (BaseLotteryEnum.SFC.getType().equals(type)) {
            startNoteActivity(CqxyncActivity.class, name, code, type);

        } else if (BaseLotteryEnum.KENO.getType().equals(type)) {
            startNoteActivity(BJKL8Activity.class, name, code, type);

        } else if (BaseLotteryEnum.XY28.getType().equals(type)) {
            startNoteActivity(XY28Activity.class, name, code, type);

        } else if (BaseLotteryEnum.PL3.getType().equals(type)) {
            startActivityByModel(QTAActivity.class, QTBActivity.class, mode, code, name, type);

        } else if (BaseLotteryEnum.SYXW.getType().equalsIgnoreCase(type)) {
            startNoteActivity(GDSelectAActivity.class, name, code, type);

        } else if (BaseLotteryEnum.NN.getType().equals(type)) {
            startNoteActivity(PK10CattleActivity.class, name, code, type);
        } else if (BaseLotteryEnum.BJL.getType().equals(type)) {
            startNoteActivity(PK10BaccaratActivity.class, name, code, type);
        }
    }

    /**
     * 根据code进入投注界面
     *
     * @param code
     */
    public static void startNoteActivity(String type, String code, String name) {
        String mode = DataCenter.getInstance().getmLotteryType().get(code);
        if (mode == null || mode.isEmpty()) {
            SingleToast.showMsg("该彩种暂未开放");
            return;
        }
        startNoteActivity(mode, type, code, name);
    }

    public static void startActivityByModel(Class A, Class B, String mode, String code, String name, String type) {
        if (TextUtils.isEmpty(mode))
            startNoteActivity(A, name, code, type);
        else {
            if ("all".equals(mode) || "official".equals(mode))
                startNoteActivity(A, name, code, type);
            else startNoteActivity(B, name, code, type);
        }
    }

    public static void dispatchChartActivity(Context context, Class clazz, List<Handicap> list, String code, String name) {
        if (list == null) {
            ToastUtil.showToastShort(mContext, "获取彩票开奖数据异常");
            return;
        }

        BaseChartActivity.startChartActivity(context, clazz, list, code, name);
    }


    /**
     * 根据code进入趋势图
     *
     * @param context
     * @param list
     * @param code
     */
    public static void startChartActivity(Context context, List<Handicap> list, String type, String code, String name) {
        if (BaseLotteryEnum.SSC.getType().equals(type)) {
            dispatchChartActivity(context, ChartSSCActivity.class, list, code, name);

        } else if (BaseLotteryEnum.PK10.getType().equals(type) || BaseLotteryEnum.BJL.getType().equalsIgnoreCase(type) || BaseLotteryEnum.NN.getType().equalsIgnoreCase(type)) {
            dispatchChartActivity(context, PK10TrendChartActivity.class, list, code, name);

        } else if (BaseLotteryEnum.LHC.getType().equals(type)) {

            dispatchChartActivity(context, SMRecordActivity.class, list, code, name);

        } else if (BaseLotteryEnum.K3.getType().equals(type)) {
            dispatchChartActivity(context, K3TrendChartActivity.class, list, code, name);

        } else if (BaseLotteryEnum.SFC.getType().equals(type)) {
            dispatchChartActivity(context, NCTrendChatActivity.class, list, code, name);

        } else if (BaseLotteryEnum.KENO.getType().equals(type)) {
            dispatchChartActivity(context, Bjkl8TrendChartActivity.class, list, code, name);

        } else if (BaseLotteryEnum.XY28.getType().equals(type)) {
            dispatchChartActivity(context, Xy28TrendChartActivity.class, list, code, name);

        } else if (BaseLotteryEnum.PL3.getType().equals(type)) {
            dispatchChartActivity(context, Xy28TrendChartActivity.class, list, code, name);

        } else if (BaseLotteryEnum.SYXW.getType().equals(type)) {
            dispatchChartActivity(context, Select5TrendChartActivity.class, list, code, name);
        }
    }

    public static void startOtherapp(String packageName) {
        try {
            PackageManager packageManager
                    = BoxApplication.getContext().getPackageManager();
            Intent intent = packageManager.
                    getLaunchIntentForPackage(packageName);
            mContext.startActivity(intent);
        } catch (Exception e) {
            ToastUtil.showToastShort(mContext, "您的手机未安装该应用");
        }
    }

    /**
     * 进入提交申请页面
     */
    public static void startWithdrawActivity(Activity activity, PayDetailBean payDetailBean, double depositAmount, int saleId) {
        Intent intent = new Intent(activity, PostDepositActivity.class);
        intent.putExtra("item", payDetailBean);
        intent.putExtra("depositAmount", depositAmount);
        intent.putExtra("saleId", saleId);
        activity.startActivityForResult(intent, ConstantValue.REQUEST_DEPOSIT);
    }
}
