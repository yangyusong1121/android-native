package com.dawoo.lotterybox.adapter.hall.parent;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.dawoo.lotterybox.R;
import com.dawoo.lotterybox.adapter.hall.child.BaseViewHolder;
import com.dawoo.lotterybox.bean.lottery.hall.LotteryBean;
import com.dawoo.lotterybox.bean.lottery.lotteryenum.BaseLotteryEnum;
import com.dawoo.lotterybox.util.ActivityUtil;
import com.dawoo.lotterybox.util.NetUtil;
import com.dawoo.lotterybox.view.activity.AllLotteryActivity;
import com.dawoo.lotterybox.view.activity.lottery.k3.K3AActivity;
import com.dawoo.lotterybox.view.activity.lottery.k3.K3BActivity;
import com.dawoo.lotterybox.view.activity.lottery.keno.BJKL8Activity;
import com.dawoo.lotterybox.view.activity.lottery.keno.XY28Activity;
import com.dawoo.lotterybox.view.activity.lottery.lhc.HKSMActivity;
import com.dawoo.lotterybox.view.activity.lottery.pk10.PK10AActivity;
import com.dawoo.lotterybox.view.activity.lottery.pk10.PK10BActivity;
import com.dawoo.lotterybox.view.activity.lottery.pk10.PK10BaccaratActivity;
import com.dawoo.lotterybox.view.activity.lottery.pk10.PK10CattleActivity;
import com.dawoo.lotterybox.view.activity.lottery.qt.QTAActivity;
import com.dawoo.lotterybox.view.activity.lottery.qt.QTBActivity;
import com.dawoo.lotterybox.view.activity.lottery.select5.GDSelectAActivity;
import com.dawoo.lotterybox.view.activity.lottery.sfc.CqxyncActivity;
import com.dawoo.lotterybox.view.activity.lottery.ssc.SSCAActivity;
import com.dawoo.lotterybox.view.activity.lottery.ssc.SSCBActivity;

import static com.dawoo.lotterybox.ConstantValue.MODE_OFFICIAL_PLAY;

/**
 * Created by b on 18-5-30.
 */

public class LotteryViewHolder extends BaseViewHolder {
    private final Context mContext;
    private ImageView ivHot, lotteryIcon;
    private TextView lotteryName, memoTv;

    private RequestOptions hallOptions;

    public void setOptions(RequestOptions hallOptions) {
        this.hallOptions = hallOptions;
    }

    public LotteryViewHolder(Context context, View itemView) {
        super(itemView);
        this.mContext = context;
        memoTv = itemView.findViewById(R.id.memo_tv);
        lotteryName = itemView.findViewById(R.id.tv_lottery_name);
        ivHot = itemView.findViewById(R.id.iv_hot);
        lotteryIcon = itemView.findViewById(R.id.iv_lottery_icon);
    }

    public void bindView(LotteryBean lotteryBean) {
        if (lotteryBean.getModel().equals("more")) {
            lotteryIcon.setImageResource(R.mipmap.icon_more);
            lotteryName.setText("更多彩种");
        } else {
            Glide.with(mContext).load(NetUtil.handleUrl(lotteryBean.getImageUrl())).apply(hallOptions)
                    .into(lotteryIcon);

            lotteryName.setText(lotteryBean.getName());
        }
        if (lotteryBean.getIsHot().equalsIgnoreCase("true")) {
            ivHot.setImageResource(R.mipmap.hot_badge);
            ivHot.setVisibility(View.VISIBLE);
        } else if (lotteryBean.getIsNew().equalsIgnoreCase("true")) {
            ivHot.setImageResource(R.mipmap.hot_badge);
            ivHot.setVisibility(View.VISIBLE);
        } else {
            ivHot.setVisibility(View.INVISIBLE);
        }
        if (lotteryBean.getMemo() == null) {
            memoTv.setText("");
        } else {
            memoTv.setText(lotteryBean.getMemo());
        }
        itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (lotteryBean.getModel().equals("more")) {
                    if (lotteryBean.getType().equalsIgnoreCase("0")) {
                        mContext.startActivity(new Intent(mContext, AllLotteryActivity.class).putExtra("position", 0));
                    } else {
                        mContext.startActivity(new Intent(mContext, AllLotteryActivity.class).putExtra("position", 1));
                    }
                    return;
                }
                gotoLotteryActivity(lotteryBean);
            }
        });

    }


    /**
     * 根据点击彩种进行分发
     * A盘的彩种进入A盘投注界面
     * B盘的彩种进入B盘投注界面
     *
     * @param dataBean
     */

    void gotoLotteryActivity(LotteryBean dataBean) {
        if (dataBean == null) {
            return;
        }
        String type = dataBean.getType();

        // 根据彩种类型进入彩票的彩种投注界面
        if (BaseLotteryEnum.K3.getType().equals(type)) {
            // k3
            if (dataBean.getModel().equals(MODE_OFFICIAL_PLAY)) {
                startActivity(K3AActivity.class, dataBean);
            } else {
                startActivity(K3BActivity.class, dataBean);
            }
        } else if (BaseLotteryEnum.LHC.getType().equals(type)) {
            // lhc
            startActivity(HKSMActivity.class, dataBean);
        } else if (BaseLotteryEnum.SSC.getType().equals(type)) {
            // ssc
            if (dataBean.getModel().equals(MODE_OFFICIAL_PLAY)) {
                startActivity(SSCAActivity.class, dataBean);
            } else {
                startActivity(SSCBActivity.class, dataBean);
            }
        } else if (BaseLotteryEnum.PK10.getType().equals(type)) {
            // pk10
            if (dataBean.getModel().equals(MODE_OFFICIAL_PLAY)) {
                startActivity(PK10AActivity.class, dataBean);
            } else {
                startActivity(PK10BActivity.class, dataBean);
            }
        } else if (BaseLotteryEnum.SFC.getType().equals(type)) {
            // sfc 重庆幸运农场 广东快乐十分
            startActivity(CqxyncActivity.class, dataBean);
        } else if (BaseLotteryEnum.KENO.getType().equals(type)) {
            // keno 北京快乐8
            startActivity(BJKL8Activity.class, dataBean);
        } else if (BaseLotteryEnum.XY28.getType().equals(type)) {
            // xy28 幸运28
            startActivity(XY28Activity.class, dataBean);

        } else if (BaseLotteryEnum.PL3.getType().equals(type)) {
            // pl3
            if (dataBean.getModel().equals(MODE_OFFICIAL_PLAY)) {
                startActivity(QTAActivity.class, dataBean);
            } else {
                startActivity(QTBActivity.class, dataBean);
            }
        } else if (BaseLotteryEnum.SYXW.getType().equalsIgnoreCase(type)) {
            startActivity(GDSelectAActivity.class, dataBean);
        } else if(BaseLotteryEnum.NN.getType().equalsIgnoreCase(type)){
            startActivity(PK10CattleActivity.class,dataBean);
        }else if (BaseLotteryEnum.BJL.getType().equalsIgnoreCase(type)){
            startActivity(PK10BaccaratActivity.class,dataBean);
        }
    }

    /**
     * 进入投注activity
     *
     * @param clazz
     * @param dataBean
     */
    public void startActivity(Class clazz, LotteryBean dataBean) {
        String name = dataBean.getName();
        String code = dataBean.getCode();
        ActivityUtil.startNoteActivity(clazz, name, code, dataBean.getType());
    }

}
