package com.dawoo.lotterybox.view.activity.lottery.pk10;


import android.view.View;
import android.widget.LinearLayout;

import com.dawoo.lotterybox.R;
import com.dawoo.lotterybox.view.activity.team.base.SuperBaseActivity;
import com.dawoo.lotterybox.view.fragment.pk10_bet_room.BasePk10Fragment;
import com.dawoo.lotterybox.view.view.BJLItemView;

import java.util.List;

import butterknife.BindView;
import butterknife.BindViews;

public class TestActivity extends SuperBaseActivity {

  /*  @BindView(R.id.v_he)
    BJLItemView v_he;
    @BindView(R.id.v_xian)
    BJLItemView v_xian;
    @BindView(R.id.v_zhuang)
    BJLItemView v_zhuang;
    @BindView(R.id.v_d)
    BJLItemView v_d;
    @BindView(R.id.v_xd)
    BJLItemView v_xd;
    @BindView(R.id.v_zd)
    BJLItemView v_zd;
    @BindView(R.id.v_x)
    BJLItemView v_x;*/

    @BindViews({R.id.v_he, R.id.v_xian, R.id.v_zhuang, R.id.v_d, R.id.v_xd, R.id.v_zd, R.id.v_x})
    List<View> views;

    @Override
    protected void createLayoutView() {
        setContentView(R.layout.fragment_pk10_bjl);
    }


    @Override
    protected void initViews() {
//        v_he.setTitle("和");
//        v_xian.setTitle("闲");
//        v_zhuang.setTitle("庄");
//        v_d.setTitle("大");
//        v_xd.setTitle("闲对");
//        v_zd.setTitle("庄对");
//        v_x.setTitle("小");

        String[] odds = new String[]{"1:8", "1:1", "1:0.95", "1:0.54", "1:8.5", "1:8.5", "1:1.50"};
        String[] titles = getResources().getStringArray(R.array.bjl_play_name);
        for (int i = 0; i < titles.length; i++) {
            ((BJLItemView) views.get(i)).setTitle(titles[i]);
            ((BJLItemView) views.get(i)).setOdds(odds[i]);
        }
    }
}
