package com.dawoo.lotterybox.adapter.pknn;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.dawoo.coretool.util.date.DateTool;
import com.dawoo.lotterybox.BoxApplication;
import com.dawoo.lotterybox.R;
import com.dawoo.lotterybox.adapter.BaseViewHolder;
import com.dawoo.lotterybox.bean.lottery.lotteryenum.BaseLotteryEnum;
import com.dawoo.lotterybox.bean.lottery.lotteryenum.LotteryPlayEnum;
import com.dawoo.lotterybox.bean.record.NoteRecordHis;
import com.dawoo.lotterybox.util.lottery.LotteryUtil;

import java.util.ArrayList;
import java.util.List;

import static com.dawoo.lotterybox.view.activity.record.HistoryRepotFormFragment.nowin;
import static com.dawoo.lotterybox.view.activity.record.HistoryRepotFormFragment.pending;
import static com.dawoo.lotterybox.view.activity.record.HistoryRepotFormFragment.revocation;
import static com.dawoo.lotterybox.view.activity.record.HistoryRepotFormFragment.revoke_self;
import static com.dawoo.lotterybox.view.activity.record.HistoryRepotFormFragment.revoke_sys;
import static com.dawoo.lotterybox.view.activity.record.HistoryRepotFormFragment.wining;

public class OrderResultAdapter extends RecyclerView.Adapter<BaseViewHolder> {
    private List<NoteRecordHis> mDatas = new ArrayList<>();
    public String type;

    public OrderResultAdapter(String type) {
        this.type = type;
    }

    public void setmDatas(List<NoteRecordHis> mDatas) {
        this.mDatas = mDatas;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public BaseViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (type.equalsIgnoreCase(BaseLotteryEnum.NN.getType())) {
            return new NNOrderHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_order_nn_result, parent, false));
        } else {
            return new OrderHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_my_order_result, parent, false));
        }
    }

    @Override
    public void onBindViewHolder(@NonNull BaseViewHolder holder, int position) {
        holder.onBindView(position);
    }

    @Override
    public int getItemCount() {
        return mDatas.size();
    }

    class OrderHolder extends BaseViewHolder {
        TextView expectTv, betNum, betOdd, betAmount,  winningAmount;

        public OrderHolder(View itemView) {
            super(itemView);
            expectTv = itemView.findViewById(R.id.expect_tv);
            betNum = itemView.findViewById(R.id.bet_num);
            betOdd = itemView.findViewById(R.id.bet_odd);
            betAmount = itemView.findViewById(R.id.bet_amount);
            winningAmount = itemView.findViewById(R.id.winning_amount);
        }
        @Override
        public void onBindView(int position) {
            NoteRecordHis his = mDatas.get(position);
            expectTv.setText(his.getExpect());
            betNum.setText(LotteryUtil.getPlayName(his.getBetNum()));
            String oddString;
            if (his.getOdd() == 1) {
                oddString = "一倍";
            } else if (his.getOdd() == 2) {
                oddString = "二倍";
            } else if (his.getOdd() == 3) {
                oddString = "三倍";
            } else if (his.getOdd() == 4) {
                oddString = "四倍";
            } else if (his.getOdd() == 5) {
                oddString = "五倍";
            } else if (his.getOdd() == 6) {
                oddString = "六倍";
            } else {
                oddString = his.getOdd() + "倍";
            }
            betOdd.setText(oddString);
            betAmount.setText(his.getBetAmount() + "");
            if (his.getStatus().equals(pending)) {
                winningAmount.setText("--");
                winningAmount.setTextColor(BoxApplication.getContext().getResources().getColor(R.color.history_item_blue));
            } else if (his.getStatus().equals(wining)) {
                winningAmount.setTextColor(BoxApplication.getContext().getResources().getColor(R.color.history_item_green));
                winningAmount.setText("+" + his.getProfit());
            } else if (his.getStatus().equals(nowin)) {
                winningAmount.setTextColor(BoxApplication.getContext().getResources().getColor(R.color.history_item_red));
                winningAmount.setText(String.valueOf(his.getProfit()));
            } else if (his.getStatus().equals(revoke_sys) || his.getStatus().equals(revoke_self)) {
                winningAmount.setTextColor(BoxApplication.getContext().getResources().getColor(R.color.history_item_blue));
                winningAmount.setText("撤单");
            } else if (his.getStatus().equals(revocation)) {
                winningAmount.setText("撤消");
                winningAmount.setTextColor(BoxApplication.getContext().getResources().getColor(R.color.history_item_blue));
            }

        }
    }

    class NNOrderHolder extends BaseViewHolder {
        TextView expectTv, orderTime, betNum, playName, betAmount, freeAmount, winAmount, backAmount;

        public NNOrderHolder(View itemView) {
            super(itemView);
            expectTv = itemView.findViewById(R.id.expect_tv);
            orderTime = itemView.findViewById(R.id.order_time);
            betNum = itemView.findViewById(R.id.bet_num);
            playName = itemView.findViewById(R.id.play_name);
            betAmount = itemView.findViewById(R.id.bet_amount);
            freeAmount = itemView.findViewById(R.id.free_amount);
            winAmount = itemView.findViewById(R.id.winning_amount);
            backAmount = itemView.findViewById(R.id.back_amount);
        }
        @Override
        public void onBindView(int position) {
            NoteRecordHis his = mDatas.get(position);
            expectTv.setText(his.getExpect());
            betNum.setText(LotteryUtil.getPlayName(his.getBetNum()));
            playName.setText(LotteryUtil.getPlayName(his.getPlayCode()));
            String time = DateTool.getTimeFromLong(DateTool.FMT_DATE_TIME, his.getBetTime());
            orderTime.setText(time.replace(" ", "\n"));
            betAmount.setText(his.getBetAmount() + "");
            if (his.getPlayCode().equalsIgnoreCase(LotteryPlayEnum.NN_LEVEL.getCode())) {
                freeAmount.setVisibility(View.GONE);
                backAmount.setVisibility(View.GONE);
            } else {
                freeAmount.setText("(" + his.getFreezAmount() + ")");
                freeAmount.setVisibility(View.VISIBLE);
                backAmount.setVisibility(View.VISIBLE);
            }

            if (his.getStatus().equals(pending)) {
                winAmount.setText("--");
                winAmount.setTextColor(BoxApplication.getContext().getResources().getColor(R.color.history_item_blue));
                backAmount.setVisibility(View.GONE);
            } else if (his.getStatus().equals(wining)) {
                winAmount.setTextColor(BoxApplication.getContext().getResources().getColor(R.color.history_item_green));
                winAmount.setText("+" + his.getProfit());
                backAmount.setText("返：" + his.getFreezAmount());
            } else if (his.getStatus().equals(nowin)) {
                winAmount.setTextColor(BoxApplication.getContext().getResources().getColor(R.color.history_item_red));
                winAmount.setText(String.valueOf(his.getProfit()));
                backAmount.setVisibility(View.GONE);
            } else if (his.getStatus().equals(revoke_sys) || his.getStatus().equals(revoke_self)) {
                winAmount.setTextColor(BoxApplication.getContext().getResources().getColor(R.color.history_item_blue));
                winAmount.setText("撤单");
                backAmount.setVisibility(View.GONE);
            } else if (his.getStatus().equals(revocation)) {
                winAmount.setText("撤消");
                winAmount.setTextColor(BoxApplication.getContext().getResources().getColor(R.color.history_item_blue));
                backAmount.setVisibility(View.GONE);
            }
        }
    }
}
