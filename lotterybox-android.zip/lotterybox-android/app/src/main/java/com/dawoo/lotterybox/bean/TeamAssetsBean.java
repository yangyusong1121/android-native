package com.dawoo.lotterybox.bean;

/**
 * Created by alex on 18-4-24.
 */

public class TeamAssetsBean {


    /**
     * error : 0
     * data : {"expendmoney":-34261.4,"withdrawmoney":-200,"depositmoney":60499,"favorablemoney":2040,"incomemoney":29431.9}
     */

    /**
     * expendmoney : -34261.4
     * withdrawmoney : -200.0
     * depositmoney : 60499.0
     * favorablemoney : 2040.0
     * incomemoney : 29431.9
     */

    private double expendmoney;
    private double withdrawmoney;
    private double depositmoney;
    private double favorablemoney;
    private double incomemoney;

    public double getExpendmoney() {
        return expendmoney;
    }

    public void setExpendmoney(double expendmoney) {
        this.expendmoney = expendmoney;
    }

    public double getWithdrawmoney() {
        return withdrawmoney;
    }

    public void setWithdrawmoney(double withdrawmoney) {
        this.withdrawmoney = withdrawmoney;
    }

    public double getDepositmoney() {
        return depositmoney;
    }

    public void setDepositmoney(double depositmoney) {
        this.depositmoney = depositmoney;
    }

    public double getFavorablemoney() {
        return favorablemoney;
    }

    public void setFavorablemoney(double favorablemoney) {
        this.favorablemoney = favorablemoney;
    }

    public double getIncomemoney() {
        return incomemoney;
    }

    public void setIncomemoney(double incomemoney) {
        this.incomemoney = incomemoney;
    }
}
