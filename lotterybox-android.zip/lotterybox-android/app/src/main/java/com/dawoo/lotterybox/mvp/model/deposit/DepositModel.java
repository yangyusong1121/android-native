package com.dawoo.lotterybox.mvp.model.deposit;

import com.dawoo.lotterybox.bean.Deposit.ParentDepositBean;
import com.dawoo.lotterybox.bean.Deposit.PayDetailBean;
import com.dawoo.lotterybox.bean.Deposit.SaleBean;
import com.dawoo.lotterybox.bean.EasyHttpResult;
import com.dawoo.lotterybox.mvp.model.BaseModel;
import com.dawoo.lotterybox.mvp.service.IDepositServece;
import com.dawoo.lotterybox.mvp.service.ILotteryService;
import com.dawoo.lotterybox.net.BaseHttpResult;
import com.dawoo.lotterybox.net.HttpResult;
import com.dawoo.lotterybox.net.RetrofitHelper;

import java.util.List;

import io.reactivex.Observable;
import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;


/**
 * Created by rain on 18-4-30.
 */

public class DepositModel extends BaseModel implements IDepositModel {

    @Override
    public Disposable getPayWay(Observer Observer, String type) {
        Observable<List<ParentDepositBean>> observable = RetrofitHelper
                .getService(IDepositServece.class)
                .getPayWay(type)
                .map(new HttpResultFunc<>());
        return toSubscribe(observable, Observer);
    }

    /**
     * 获取公司入款信息
     *
     * @param Observer
     * @return
     */
    @Override
    public Disposable getPayDetail(Observer Observer, String type, String item) {
        Observable<List<PayDetailBean>> observable = RetrofitHelper
                .getService(IDepositServece.class)
                .getPayDetail(type, item)
                .map(new HttpResultFunc<>());
        return toSubscribe(observable, Observer);
    }


    @Override
    public Disposable getFee(Observer Observer, int payAccountId, double money) {
        Observable<Object> observable = RetrofitHelper
                .getService(IDepositServece.class)
                .getFee(payAccountId, money)
                .map(new HttpResultFunc<>());
        return toSubscribe(observable, Observer);
    }

    @Override
    public Disposable postOnline(Observer Observer, int payAccountId, double money, String token) {
        Observable<EasyHttpResult> observable = RetrofitHelper
                .getService(IDepositServece.class)
                .postOnlinePay(payAccountId, money, token);
        return toSubscribe(observable, Observer);
    }


    @Override
    public Disposable getSales(Observer Observer, String type) {
        Observable<List<SaleBean>> observable = RetrofitHelper
                .getService(IDepositServece.class)
                .getCompanySales(type)
                .map(new HttpResultFunc<>());
        return toSubscribe(observable, Observer);
    }

    @Override
    public Disposable getSaleMoney(Observer Observer, double money, int id) {
        Observable<Object> observable = RetrofitHelper
                .getService(IDepositServece.class)
                .getCompanySaleMoney(money, id)
                .map(new HttpResultFunc<>());
        return toSubscribe(observable, Observer);
    }

    @Override
    public Disposable postCompanyPay(Observer Observer, int payAccountId, double rechargeAmount, int favorableId, String orderNumber, String payerName,String token) {
        if (favorableId == 0) {
            Observable<EasyHttpResult> observable = RetrofitHelper
                    .getService(IDepositServece.class)
                    .postCompanyPay(payAccountId, String.valueOf(rechargeAmount), orderNumber, payerName,token);
            return toSubscribe(observable, Observer);
        } else {
            Observable<EasyHttpResult> observable = RetrofitHelper
                    .getService(IDepositServece.class)
                    .postCompanyPay(payAccountId, String.valueOf(rechargeAmount), favorableId, orderNumber, payerName,token);
            return toSubscribe(observable, Observer);
        }
    }

}
