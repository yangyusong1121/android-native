package com.dawoo.lotterybox.bean;

import java.util.List;

public class IpBean {

    /**
     * error : 0
     * code : null
     * message : null
     * data : [{"domain":"8oj.longtoubet.com","ip":"43.242.33.234"}]
     * extend : null
     */

    private int error;
    private Object code;
    private Object message;
    private Object extend;
    private List<DataBean> data;

    public int getError() {
        return error;
    }

    public void setError(int error) {
        this.error = error;
    }

    public Object getCode() {
        return code;
    }

    public void setCode(Object code) {
        this.code = code;
    }

    public Object getMessage() {
        return message;
    }

    public void setMessage(Object message) {
        this.message = message;
    }

    public Object getExtend() {
        return extend;
    }

    public void setExtend(Object extend) {
        this.extend = extend;
    }

    public List<DataBean> getData() {
        return data;
    }

    public void setData(List<DataBean> data) {
        this.data = data;
    }

    public static class DataBean {
        /**
         * domain : 8oj.longtoubet.com
         * ip : 43.242.33.234
         */

        private String domain;
        private String ip;

        public String getDomain() {
            return domain;
        }

        public void setDomain(String domain) {
            this.domain = domain;
        }

        public String getIp() {
            return ip;
        }

        public void setIp(String ip) {
            this.ip = ip;
        }
    }
}
