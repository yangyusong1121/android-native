package com.dawoo.lotterybox.mvp.service;

import com.dawoo.lotterybox.bean.UpdateInfo;
import com.dawoo.lotterybox.net.HttpResult;

import io.reactivex.Observable;
import retrofit2.http.GET;
import retrofit2.http.Query;

/**
 * 用户相关的接口
 *
 * @author benson
 * @date 17-12-21
 */

public interface IMainService {

    /**
     * 获取版本更新
     *
     * @param versionCode
     * @return
     */
    @GET("hall/mobile/get-app-version-android.html")
    Observable<HttpResult<UpdateInfo>> getVersionsData(@Query("search.versionCode") int versionCode);

}
