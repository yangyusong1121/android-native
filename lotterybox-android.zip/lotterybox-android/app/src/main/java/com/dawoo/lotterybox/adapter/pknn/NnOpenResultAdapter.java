package com.dawoo.lotterybox.adapter.pknn;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.dawoo.lotterybox.R;
import com.dawoo.lotterybox.adapter.BaseViewHolder;
import com.dawoo.lotterybox.adapter.hall.child.adapterset.Item;
import com.dawoo.lotterybox.bean.lottery.Handicap;
import com.dawoo.lotterybox.bean.lottery.lotteryenum.BaseLotteryEnum;

import java.util.ArrayList;
import java.util.List;

public class NnOpenResultAdapter extends RecyclerView.Adapter<BaseViewHolder> {
    final int top = 0;
    final int content = 1;
    boolean isNN = false;
    List<Handicap> mHandicap = new ArrayList<>();
    private Context mContent;
    private String type;

    public NnOpenResultAdapter(Context mContent, List<Handicap> mHandicap, String type,boolean isNN) {
        this.mContent = mContent;
        this.mHandicap = mHandicap;
        this.type = type;
        this.isNN = isNN;
    }

    public void setmHandicap(List<Handicap> mHandicap){
        this.mHandicap = mHandicap;
        notifyDataSetChanged();
    }
    @NonNull
    @Override
    public BaseViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (viewType == top) {
            if (type.equalsIgnoreCase(BaseLotteryEnum.NN.getType())) {
                return new TopHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_nn_open_top, parent, false));
            }else{
                return new TopHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_happy_result_top, parent, false));
            }
        } else  {
            if (isNN) {
                if (type.equalsIgnoreCase(BaseLotteryEnum.NN.getType())) {
                    return new ResultHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_nn_open_result, parent, false));
                } else {
                    return new HappyResult(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_happy_result, parent, false));
                }
            } else {
                return new PK10Holder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_nn_pk10_result, parent, false));
            }

        }
    }

    @Override
    public int getItemViewType(int position) {
        if (isNN) {
            if (position == 0) {
                return top;
            }
        }
        return content;
    }

    @Override
    public void onBindViewHolder(@NonNull BaseViewHolder holder, int position) {
        if (isNN) {
            if (position != 0) {
                holder.onBindView(position - 1);
            }
        } else {
            holder.onBindView(position);
        }
    }

    @Override
    public int getItemCount() {
        if (isNN) {
            return mHandicap.size() + 1;
        } else {
            return mHandicap.size();
        }
    }

    class TopHolder extends BaseViewHolder {

        public TopHolder(View itemView) {
            super(itemView);
        }
    }

    class ResultHolder extends BaseViewHolder {
        TextView expectTV, orderTV, customer01, customer02, customer03, customer04, customer05;

        public ResultHolder(View itemView) {
            super(itemView);
            expectTV = itemView.findViewById(R.id.result_expect);
            orderTV = itemView.findViewById(R.id.order_code);
            customer01 = itemView.findViewById(R.id.customer_01);
            customer02 = itemView.findViewById(R.id.customer_02);
            customer03 = itemView.findViewById(R.id.customer_03);
            customer04 = itemView.findViewById(R.id.customer_04);
            customer05 = itemView.findViewById(R.id.customer_05);
        }

        @Override
        public void onBindView(int position) {
            super.onBindView(position);
            Handicap rcd = mHandicap.get(position);
            expectTV.setText(rcd.getExpect());
            if (rcd.getNnOpenCode() == null || rcd.getNnOpenCode().size() != 6) {
                return;
            }
            orderTV.setText(rcd.getNnOpenCode().get(0).getPlayName());
            customer01.setText(rcd.getNnOpenCode().get(1).getPlayName());
            customer02.setText(rcd.getNnOpenCode().get(2).getPlayName());
            customer03.setText(rcd.getNnOpenCode().get(3).getPlayName());
            customer04.setText(rcd.getNnOpenCode().get(4).getPlayName());
            customer05.setText(rcd.getNnOpenCode().get(5).getPlayName());
        }
    }

    class PK10Holder extends BaseViewHolder {
        TextView expectTV, code0, code1, code2, code3, code4, code5, code6, code7, code8, code9;

        public PK10Holder(View itemView) {
            super(itemView);
            expectTV = itemView.findViewById(R.id.expect_tv);
            code0 = itemView.findViewById(R.id.code_0);
            code1 = itemView.findViewById(R.id.code_1);
            code2 = itemView.findViewById(R.id.code_2);
            code3 = itemView.findViewById(R.id.code_3);
            code4 = itemView.findViewById(R.id.code_4);
            code5 = itemView.findViewById(R.id.code_5);
            code6 = itemView.findViewById(R.id.code_6);
            code7 = itemView.findViewById(R.id.code_7);
            code8 = itemView.findViewById(R.id.code_8);
            code9 = itemView.findViewById(R.id.code_9);

        }

        @Override
        public void onBindView(int position) {
            super.onBindView(position);
            Handicap rcd = mHandicap.get(position);
            expectTV.setText(rcd.getExpect());
            String[] codes = rcd.getOpenCode().split(",");
            if (codes.length == 10) {
                code0.setText(codes[0]);
                code1.setText(codes[1]);
                code2.setText(codes[2]);
                code3.setText(codes[3]);
                code4.setText(codes[4]);
                code5.setText(codes[5]);
                code6.setText(codes[6]);
                code7.setText(codes[7]);
                code8.setText(codes[8]);
                code9.setText(codes[9]);
            }
        }
    }

    class HappyResult extends BaseViewHolder {
        TextView expectTv,orderTv,customerTv,bigSmallTv;
        public HappyResult(View itemView) {
            super(itemView);
            expectTv = itemView.findViewById(R.id.expect_tv);
            orderTv = itemView.findViewById(R.id.order_tv);
            customerTv = itemView.findViewById(R.id.customer_tv);
            bigSmallTv = itemView.findViewById(R.id.big_small_tv);
        }

        @Override
        public void onBindView(int position) {
            super.onBindView(position);
            Handicap rcd = mHandicap.get(position);
            expectTv.setText(rcd.getExpect());
        }
    }
}
