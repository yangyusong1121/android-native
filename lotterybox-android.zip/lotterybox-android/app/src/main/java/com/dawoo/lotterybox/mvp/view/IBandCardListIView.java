package com.dawoo.lotterybox.mvp.view;

/**
 * Created by jack on 18-2-19.
 */

public interface IBandCardListIView extends IBaseView {
    void bandCardList(Object o);
}
