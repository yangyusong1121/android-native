package com.dawoo.lotterybox.bean;

import java.util.List;
import java.util.Map;

public class SavaParticipationBean {
    public String playerId;
    public List<Map<String, String>> grade;
}
