package com.dawoo.lotterybox.mvp.view;

import com.dawoo.lotterybox.bean.UpdateInfo;

/**
 * Created by benson on 17-12-21.
 */

public interface IMainView extends IBaseView{

    void onVersions(UpdateInfo updateInfo);
}
