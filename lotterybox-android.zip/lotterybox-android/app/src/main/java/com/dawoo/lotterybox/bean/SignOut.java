package com.dawoo.lotterybox.bean;

/**
 * Created by jack on 18-2-11.
 */

public class SignOut {

}
