package com.dawoo.lotterybox.bean.Deposit;

import com.dawoo.lotterybox.bean.lottery.lotteryenum.ICodeEnum;

/**
 * Created by rain on 18-5-1.
 */

public interface IPayEnum extends ICodeEnum{
    int getDrawable();
}
