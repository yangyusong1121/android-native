package com.dawoo.lotterybox.net.rx;

import android.animation.ObjectAnimator;
import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.animation.LinearInterpolator;
import android.widget.ImageView;

import com.blankj.utilcode.util.ActivityUtils;
import com.blankj.utilcode.util.AppUtils;
import com.dawoo.lotterybox.BoxApplication;
import com.dawoo.lotterybox.R;
import com.dawoo.lotterybox.util.ActivityUtil;
import com.dawoo.lotterybox.view.activity.BaseActivity;

import java.util.Objects;


public class ProgressDialogHandler extends Handler {

    public static final int SHOW_PROGRESS_DIALOG = 1;
    public static final int DISMISS_PROGRESS_DIALOG = 2;
    private Context mContext;

    public ProgressDialogHandler(Context context, ProgressCancelListener mProgressCancelListener,
                                 boolean cancelable) {
        super();
        this.mContext = context;
        if (context instanceof BaseActivity) {
            ((BaseActivity) context).initProgressDialog(cancelable, mProgressCancelListener);
        }
    }


    @Override
    public void handleMessage(Message msg) {
        switch (msg.what) {
            case SHOW_PROGRESS_DIALOG:
                if (mContext instanceof BaseActivity) {
                    ((BaseActivity) mContext).showProgressDialog();
                }
                break;
            case DISMISS_PROGRESS_DIALOG:
                if (mContext instanceof BaseActivity) {
                    ((BaseActivity) mContext).dissMissProgress();
                }
                break;
            default:
        }
    }

}
