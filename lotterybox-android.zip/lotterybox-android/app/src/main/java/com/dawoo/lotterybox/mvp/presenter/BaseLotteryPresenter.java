package com.dawoo.lotterybox.mvp.presenter;

import android.content.Context;
import android.util.Log;

import com.dawoo.lotterybox.ConstantValue;
import com.dawoo.lotterybox.bean.lottery.BaseHandicap;
import com.dawoo.lotterybox.bean.lottery.Handicap;
import com.dawoo.lotterybox.bean.lottery.LotteryOddBean;
import com.dawoo.lotterybox.bean.lottery.SaveOrderResult;
import com.dawoo.lotterybox.mvp.model.Lottery.ILotteryModel;
import com.dawoo.lotterybox.mvp.model.Lottery.LotteryModel;
import com.dawoo.lotterybox.mvp.model.common.CommonModel;
import com.dawoo.lotterybox.mvp.view.IBaseLotteryView;
import com.dawoo.lotterybox.mvp.view.IBaseView;
import com.dawoo.lotterybox.net.rx.ProgressSubscriber;
import com.dawoo.lotterybox.view.activity.BaseActivity;
import com.dawoo.lotterybox.view.view.dialog.SureNoteDialog;

import java.util.List;
import java.util.Map;

import io.reactivex.disposables.Disposable;


/**
 * Created by benson on 18-3-13.
 */

public class BaseLotteryPresenter<T extends IBaseView> extends BasePresenter {
    protected static final int PAGE_NUMBER = ConstantValue.LOTTERY_LIST_PAGE_NUMBER;
    protected static final int PAGE_SIZE = ConstantValue.LOTTERY_LIST_PAGE_SIZE;


    protected Context mContext;
    protected T mView;
    protected final ILotteryModel mModel;
    protected final CommonModel mCommonModel;
    protected String mCode;
    private SureNoteDialog mSureNoteDialog;

    public BaseLotteryPresenter(Context context, T mView) {
        super(context, mView);

        mContext = context;
        this.mView = mView;
        mModel = new LotteryModel();
        mCommonModel = new CommonModel();
    }

    /**
     * 获取近120期开奖数据
     */

    public void getResultByCode() {
        Disposable Disposable = mModel.getResultByCode(new ProgressSubscriber(o ->
                        ((IBaseLotteryView) mView).onResultByCode((List<Handicap>) o), mContext, false),
                mCode,
                String.valueOf(PAGE_SIZE),
                String.valueOf(PAGE_NUMBER));
        subList.add(Disposable);
    }


    /**
     * 获取已封盘最近一期开奖数据（开奖号码（空则说明正在开奖中））；
     */

    public void getRecentCloseExpect() {
        Disposable Disposable = mModel.getRecentCloseExpect(new ProgressSubscriber(o ->
                        ((IBaseLotteryView) mView).onRecentCloseExpect((Handicap) o), mContext, false),
                mCode);
        subList.add(Disposable);
    }


    /**
     * 获取盘口数据
     */
    public void getLotteryExpect() {
        if (mContext instanceof BaseActivity) {
            ((BaseActivity) mContext).checkNetWork();
        }
        Log.e("Finish getLotteryExpect", "  getLotteryExpect");
        Disposable Disposable = mModel.getLotteryExpect(new ProgressSubscriber<>(o ->
                        ((IBaseLotteryView) mView).onLotteryExpect((BaseHandicap) o), mContext),
                mCode);
        subList.add(Disposable);
    }

    /**
     * 获取盘口数据
     */
    public void getLotteryExpect(boolean isNeedProgress) {
        if (mContext instanceof BaseActivity) {
            ((BaseActivity) mContext).checkNetWork();
        }
        Disposable Disposable = mModel.getLotteryExpect(new ProgressSubscriber<>(o ->
                        ((IBaseLotteryView) mView).onLotteryExpect((BaseHandicap) o), mContext, isNeedProgress),
                mCode);
        subList.add(Disposable);
    }

    /**
     * 获取赔率
     */
    public void getLotteryOdd(String betCode) {
        Disposable Disposable = mModel.getLotteryOdd(new ProgressSubscriber<>(o ->
                        ((IBaseLotteryView) mView).onLotteryOdd((Map<String, LotteryOddBean>) o), mContext),
                mCode,
                betCode);
        subList.add(Disposable);
    }

    /**
     * 获取下单防重token
     */
    public void getLtToken() {
        Disposable Disposable = mCommonModel.getLtToken(new ProgressSubscriber<>(o ->
                ((IBaseLotteryView) mView).onLtToken((String) o), mContext, false)
        );
        subList.add(Disposable);
    }

    /**
     * 下单
     */
    public void saveBetOrder(String token, String betForm) {
        Disposable Disposable = mModel.saveBetOrder(new ProgressSubscriber<>(o ->
                        ((IBaseLotteryView) mView).onSaveBetOrder((SaveOrderResult) o), mContext),
                token, betForm);
        subList.add(Disposable);
    }

    /**
     * 下单提示dialog
     */

    public void sureNoteDialogShow(String playTypeName, String expect, String betCount, String totalMoney) {
        if (mSureNoteDialog == null)
            mSureNoteDialog = new SureNoteDialog(mContext, (IBaseLotteryView) mView, playTypeName, expect, betCount, totalMoney);
        else mSureNoteDialog.setData(playTypeName, expect, betCount, totalMoney);
    }

    @Override
    public void onDestory() {
        super.onDestory();
        if (mSureNoteDialog != null)
            mSureNoteDialog.dismiss();

    }
}
