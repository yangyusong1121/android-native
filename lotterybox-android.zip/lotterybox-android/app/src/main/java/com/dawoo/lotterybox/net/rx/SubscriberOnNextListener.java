package com.dawoo.lotterybox.net.rx;

public interface SubscriberOnNextListener<T> {
    void onNext(T t);
}
