package com.dawoo.lotterybox.mvp.view;

import com.dawoo.lotterybox.bean.TeamAssetsBean;

/**
 * Created by alex on 18-4-24.
 */

public interface ITeamAssetsView extends IBaseView{
    void onTeamAssetsResult(TeamAssetsBean o);
}
