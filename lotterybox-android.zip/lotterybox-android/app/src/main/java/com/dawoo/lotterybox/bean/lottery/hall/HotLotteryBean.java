package com.dawoo.lotterybox.bean.lottery.hall;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by b on 18-5-30.
 */

public class HotLotteryBean {

    List<LotteryBean> tradition = new ArrayList<>();  //传统
    List<LotteryBean> official = new ArrayList<>();     //官方

    public List<LotteryBean> getTradition() {
        return tradition;
    }

    public void setTradition(List<LotteryBean> tradition) {
        this.tradition = tradition;
    }

    public List<LotteryBean> getOfficial() {
        return official;
    }

    public void setOfficial(List<LotteryBean> official) {
        this.official = official;
    }
}
