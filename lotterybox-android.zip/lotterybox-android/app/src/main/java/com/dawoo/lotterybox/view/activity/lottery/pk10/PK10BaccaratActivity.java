package com.dawoo.lotterybox.view.activity.lottery.pk10;

import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.dawoo.lotterybox.R;
import com.dawoo.lotterybox.bean.lottery.Pk10BetOderBean;
import com.dawoo.lotterybox.bean.lottery.lotteryenum.LotteryPlayEnum;
import com.dawoo.lotterybox.view.activity.team.base.OnMultiClickListener;
import com.dawoo.lotterybox.view.fragment.pk10_bet_room.BasePk10Fragment;
import com.dawoo.lotterybox.view.fragment.pk10_bet_room.Pk10BaccaratFragment;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * - @Description:  PK10　百家乐玩法
 * - @Author:  bella
 * - @Time:  18-8-9 下午5:25
 */
public class PK10BaccaratActivity extends BasePk10BetRoomActivity {
    @Override
    protected void initViews() {
        super.initViews();
        //设置游戏规则
        nnOpenCodeDialog.setInfo(R.string.bjl_info);
    }

    @Override
    public BasePk10Fragment setBody() {
        return Pk10BaccaratFragment.newInstance();
    }

    @Override
    public View setComfireDialogBodyHead() {
        return LayoutInflater.from(this).inflate(R.layout.item_pk_cattle_commit_bet, null);
    }

    @Override
    public BaseQuickAdapter setComfireDialogAdapter() {
        return new Pk10CattleCommitBetAdapter();
    }
    class Pk10CattleCommitBetAdapter extends BaseQuickAdapter<Pk10BetOderBean.BetOrdersBean, PK10CattleActivity.Pk10CattleCommitBetAdapter.ViewHolder> {
        final String x1 = LotteryPlayEnum.NN_XIAN_YI.getCode();
        final String x2 = LotteryPlayEnum.NN_XIAN_ER.getCode();
        final String x3 = LotteryPlayEnum.NN_XIAN_SAN.getCode();
        final String x4 = LotteryPlayEnum.NN_XIAN_SI.getCode();
        final String x5 = LotteryPlayEnum.NN_XIAN_WU.getCode();

        public Pk10CattleCommitBetAdapter() {
            super(R.layout.item_pk_cattle_commit_bet);
        }

        @Override
        protected void convert(PK10CattleActivity.Pk10CattleCommitBetAdapter.ViewHolder helper, Pk10BetOderBean.BetOrdersBean item) {
            String contentHead = "";
            String contentTail = "";
            if (x1.equals(item.getBetNum())) {
                contentHead = item.getFreezAmount() != 0 ? "翻倍" : "平倍";
                contentTail = "闲一";
            }
            if (x2.equals(item.getBetNum())) {
                contentHead = item.getFreezAmount() != 0 ? "翻倍" : "平倍";
                contentTail = "闲二";
            }
            if (x3.equals(item.getBetNum())) {
                contentHead = item.getFreezAmount() != 0 ? "翻倍" : "平倍";
                contentTail = "闲三";
            }
            if (x4.equals(item.getBetNum())) {
                contentHead = item.getFreezAmount() != 0 ? "翻倍" : "平倍";
                contentTail = "闲四";
            }
            if (x5.equals(item.getBetNum())) {
                contentHead = item.getFreezAmount() != 0 ? "翻倍" : "平倍";
                contentTail = "闲五";
            }

            helper.tvBetContent.setText(String.valueOf(contentHead +" "+ contentTail));
            helper.tvBetRate.setText("2-6");
            helper.tvBetSetting.setText("删除");
            helper.tvBetBalance.setText(String.valueOf(item.getBetAmount()));
            helper.tvBetBalance.setTextColor(mContext.getResources().getColor(R.color.colorPrimary));
            helper.tvBetFrezzNumber.setText(String.valueOf(item.getFreezAmount()));
            helper.tvBetFrezzNumber.setTextColor(mContext.getResources().getColor(R.color.pk_yellow_bjl));
            helper.tvBetSetting.setTextColor(mContext.getResources().getColor(R.color.colorPrimary));
            helper.tvBetSetting.setOnClickListener(new OnMultiClickListener() {
                @Override
                public void onMultiClick(View v) {
                    //删除
                    remove(helper.getPosition());
                }
            });
        }

        class ViewHolder extends BaseViewHolder {
            @BindView(R.id.tv_bet_content)
            TextView tvBetContent;
            @BindView(R.id.tv_bet_rate)
            TextView tvBetRate;
            @BindView(R.id.tv_bet_balance)
            TextView tvBetBalance;
            @BindView(R.id.tv_bet_frezz_number)
            TextView tvBetFrezzNumber;
            @BindView(R.id.tv_bet_setting)
            TextView tvBetSetting;

            public ViewHolder(View view) {
                super(view);
                ButterKnife.bind(this, view);
            }
        }


    }
}
