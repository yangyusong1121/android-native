package com.dawoo.lotterybox.mvp.service;

import com.dawoo.lotterybox.bean.AllMode;
import com.dawoo.lotterybox.bean.TypeAndLotteryBean;
import com.dawoo.lotterybox.bean.lottery.BaseHandicap;
import com.dawoo.lotterybox.bean.lottery.BaseLottery;
import com.dawoo.lotterybox.bean.lottery.Handicap;
import com.dawoo.lotterybox.bean.lottery.HandicapWithOpening;
import com.dawoo.lotterybox.bean.lottery.LotteryLastOpenAndOpening;
import com.dawoo.lotterybox.bean.lottery.LotteryOddBean;
import com.dawoo.lotterybox.bean.lottery.LotteryType;
import com.dawoo.lotterybox.bean.lottery.OrderInfo;
import com.dawoo.lotterybox.bean.lottery.SaveOrderResult;
import com.dawoo.lotterybox.bean.lottery.hall.HotLotteryBean;
import com.dawoo.lotterybox.net.HttpResult;

import java.util.List;
import java.util.Map;

import io.reactivex.Observable;
import io.reactivex.Single;
import okhttp3.ResponseBody;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;

/**
 * 彩票相关接口
 * Created by benson on 18-2-8.
 */

public interface ILotteryService {


    /**
     * 获取所有彩种类型
     *
     * @return
     */
    @GET("hall/mobile/lottery/get-type.html")
    Observable<HttpResult<List<LotteryType>>> getLotteryType();

    /**
     * 获取所有彩种
     *
     * @return
     */
    @GET("hall/mobile/lottery/get-lottery.html")
    Observable<HttpResult<List<BaseLottery>>> getLottery();

    /**
     * 获取彩种类型及其子彩种的代号和名称
     *
     * @return
     */
    @GET("hall/mobile/lottery/get-type-and-lottery.html")
    Observable<HttpResult<List<TypeAndLotteryBean>>> getTypeAndLottery();

    /**
     * 获取盘口数据
     *
     * @return
     */
    @GET("hall/mobile/lottery/get-expect.html")
    Observable<HttpResult<BaseHandicap>> getLotteryExpect(@Query("code") String code);

    /**
     * 获取近期开奖结果
     *
     * @return
     */
    @GET("hall/mobile/lottery/get-result-by-code.html")
    Observable<HttpResult<List<Handicap>>> getResultByCode(
            @Query("search.code") String code,
            @Query("paging.pageSize") String pageSize,
            @Query("paging.pageNumber") String pageNumber);

    /**
     * 获取近期数据（包含未开奖期）
     *
     * @return
     */
    @GET("hall/mobile/lottery/get-recent-records.html")
    Observable<HttpResult<List<HandicapWithOpening>>> getRecentRecords(
            @Query("code") String code,
            @Query("pageSize") String pageSize);

    /**
     * 获取每个彩种最后一期开奖结果和未开奖一期的数据
     *
     * @return
     */
    @GET("hall/mobile/lottery/get-last-opened-and-opening-result.html")
    Observable<HttpResult<List<LotteryLastOpenAndOpening>>> getLastOpenedAndOpeningResult();

    /**
     * 获取每个彩种最后一期开奖结果和未开奖一期的数据
     *
     * @return
     */
    @GET("hall/mobile/lottery/get-last-opened-and-opening-result.html")
    Observable<HttpResult<List<LotteryLastOpenAndOpening>>> getLastOpenedAndOpeningResult(@Query("code") String code);

    /**
     * 获取彩种是否拥有传统玩法，官方玩法
     * 类型(1.全部2.官方玩法3.传统玩法)
     *
     * @return
     */
    @GET("hall/mobile/lottery/get-lottery-genre.html")
    Observable<HttpResult<Integer>> getLotterygenre(
            @Query("code") String code);


    /**
     * 获取赔率
     *
     * @return
     */
    @GET("hall/mobile/lottery/get-lottery-odd.html")
    Observable<HttpResult<Map<String, LotteryOddBean>>> getLotteryOdd(
            @Query("code") String code,
            @Query("betCode") String betCode);


    /**
     * 官方下单
     */
    @FormUrlEncoded
    @POST("hall/mobile/lottery/save-bet-order.html")
    Observable<SaveOrderResult> saveBetOrder(
            @Field("lb.token") String token,
            @Field("betForm") String betForm
    );

    /**
     * 获取已封盘最近一期开奖数据
     *
     * @return
     */
    @GET("hall/mobile/lottery/get-recent-close-expect.html")
    Observable<HttpResult<Handicap>> getRecentCloseExpect(
            @Query("code") String code);

    /**
     * 根据订单编号，查询订单信息
     */
    @FormUrlEncoded
    @POST("hall/mobile/bet/get-order-billNo.html")
    Observable<HttpResult<OrderInfo>> getOrderInfo(
            @Field("billNo") String billNo,
            @Field("code") String code);


    /**
     * 获取彩种类型首页彩种
     *
     * @return
     */
    @GET("hall/mobile/hall/get-main-lottery.html")
    Observable<HttpResult<HotLotteryBean>> getHomeLottery();


    /**
     * 获取彩种类型首页彩种
     *
     * @return
     */
    @GET("hall/mobile/hall/get-main-lottery-more.html")
    Observable<HttpResult<AllMode>> getAllLottery();

    /**
     * 获取当期彩票玩家列表和注单数
     *
     * @return
     */

    @GET("hall/mobile/lottery/get-username-by-code.html")
    Observable<HttpResult<Object>> getCustomersbyCode(
            @Query("expect") String expect,
            @Query("code") String code);

    @GET("hall/mobile/lottery/get-amount-by-code.html")
    Observable<HttpResult<Object>> getAmountsbyCode(
            @Query("expect") String expect,
            @Query("code") String code);

}
