package com.dawoo.lotterybox.view.activity.lottery.keno;

import android.graphics.drawable.AnimationDrawable;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.dawoo.lotterybox.ConstantValue;
import com.dawoo.lotterybox.R;
import com.dawoo.lotterybox.bean.OrderEventBean;
import com.dawoo.lotterybox.bean.lottery.Handicap;
import com.dawoo.lotterybox.bean.lottery.HandicapWithOpening;
import com.dawoo.lotterybox.bean.playtype.PlayChooseBean;
import com.dawoo.lotterybox.mvp.view.LotteryBView;
import com.dawoo.lotterybox.util.lottery.LotteryUtil;
import com.dawoo.lotterybox.util.lottery.initdata.Lottery_B_DataUtils;
import com.dawoo.lotterybox.view.activity.lottery.BaseLotteryBActivity;
import com.dawoo.lotterybox.view.fragment.keno.XY28_HH_Fragment;
import com.dawoo.lotterybox.view.fragment.keno.XY28_HZTM_Fragment;
import com.dawoo.lotterybox.view.fragment.keno.XY28_TMBS_Fragment;
import com.dawoo.lotterybox.view.view.CountDownTimerUtils;
import com.dawoo.lotterybox.view.view.LotteryBFragmentManager;
import com.hwangjr.rxbus.RxBus;
import com.hwangjr.rxbus.annotation.Subscribe;
import com.hwangjr.rxbus.annotation.Tag;

import java.text.SimpleDateFormat;
import java.util.List;

import butterknife.BindView;
import butterknife.BindViews;

import static com.dawoo.lotterybox.ConstantValue.LT_CODE;
import static com.dawoo.lotterybox.ConstantValue.LT_NAME;


/**
 * Created by archar on 18-3-26.
 */

public class XY28Activity extends BaseLotteryBActivity implements LotteryBView, BaseLotteryBActivity.OnTheNextToDoListener {

    @BindViews({R.id.iv_red_result_128, R.id.iv_red_result_228, R.id.iv_red_result_328})
    List<TextView> showTextViews;

    @BindView(R.id.tv_result_sum)
    TextView mResultNum;


    @Override
    protected void createLayoutView() {
        super.createLayoutView();
        setContentView(R.layout.activity_lottery_base_b);

        RxBus.get().register(this);
        // 当前彩种代码
        mLotteryCode = getIntent().getStringExtra(LT_CODE);
        mLotteryName = getIntent().getStringExtra(LT_NAME);
        mHistoryAdapter = new AwardResultsQuickAdapter(R.layout.item_xy28_lottery_result_item);
        setOnTheNextToDoListener(this);
    }


    @Override
    protected void initViews() {
        super.initViews();
        setViewsGone(null, LotteryUtil.TOP_XY28);

    }

    @Override
    public void onNextInit() {
        OPEN_DELATED = 10000;
        setTickDelegate(mTickDelegate);
        setLeftOpenTimeFinishDelegate(mLeftOpenTimeFinishDelegate);
        setLeftTimeFinishDelegate(mLeftTimeFinishDelegate);
    }

    @Override
    public void onNextDataInit() {
        LotteryBFragmentManager.getInstance().switchFragment(mFragmentManager, XY28_HH_Fragment.class);
    }

    @Override
    public void onNextResultByCode(List<Handicap> handicapList) {
        setResultToBall(handicapList.get(0).getOpenCode());
    }

    @Override
    public void onNextRecentRecords(List<HandicapWithOpening> handicapWithOpeningList) {

    }

    @Override
    public void openLottery() {
        mLlFendan.setVisibility(View.GONE);
        runAnimation();

    }

    @Override
    public void onRecentCloseExpect(Handicap handicap) {
        super.onRecentCloseExpect(handicap);
        if (!TextUtils.isEmpty(handicap.getOpenCode()))
            stopAnimation();
    }

    private void stopAnimation() {

        for (TextView tv : showTextViews) {
            ((AnimationDrawable) tv.getBackground()).stop();
            tv.setBackgroundResource(R.drawable.shape_round_bg);
        }
        ((AnimationDrawable) mResultNum.getBackground()).stop();
        mResultNum.setBackgroundResource(R.drawable.shape_round_bg);
        tv_result_lottery.setVisibility(View.VISIBLE);
    }

    private void runAnimation() {
        for (TextView tv : showTextViews) {
            tv.setBackgroundResource(R.drawable.anim_blue_ball_result);
            ((AnimationDrawable) tv.getBackground()).start();
            tv.setText("");
        }

        mResultNum.setBackgroundResource(R.drawable.anim_blue_ball_result);
        ((AnimationDrawable) mResultNum.getBackground()).start();
        mResultNum.setText("");
        tv_result_lottery.setVisibility(View.GONE);
    }

    @Override
    public void onNextShowFragment(PlayChooseBean playChooseBean) {
        String name = playChooseBean.getBetName();
        if (name.equals(mPlayChooseBeans.get(0).getBetName())) {
            LotteryBFragmentManager.getInstance().switchFragment(mFragmentManager, XY28_HH_Fragment.class);
        } else if (name.equals(mPlayChooseBeans.get(1).getBetName())) {
            LotteryBFragmentManager.getInstance().switchFragment(mFragmentManager, XY28_HZTM_Fragment.class);
        } else if (name.equals(mPlayChooseBeans.get(2).getBetName())) {
            LotteryBFragmentManager.getInstance().switchFragment(mFragmentManager, XY28_TMBS_Fragment.class);
        }
    }

    public void setResultToBall(String string) {
        tv_result_lottery.setText(Lottery_B_DataUtils.getXY28tatus(string));
        if (!TextUtils.isEmpty(string)) {
            String[] numbers = string.split(",");
            for (int i = 0; i < showTextViews.size(); i++) {
                showTextViews.get(i).setText(numbers[i]);
            }
            mResultNum.setVisibility(View.VISIBLE);
            mResultNum.setText((Integer.parseInt(numbers[0]) + Integer.parseInt(numbers[1]) + Integer.parseInt(numbers[2])) + "");
        }
    }

    //倒计时期间回调
    CountDownTimerUtils.TickDelegate mTickDelegate = new CountDownTimerUtils.TickDelegate() {
        SimpleDateFormat sdf1 = new SimpleDateFormat("mm:ss");

        @Override
        public void onTick(long pMillisUntilFinished) {
            String str1 = sdf1.format(pMillisUntilFinished);
            mTimeTextView.setText(str1);
        }
    };
    //距离开盘时间 倒计时结束回调
    CountDownTimerUtils.FinishDelegate mLeftOpenTimeFinishDelegate = new CountDownTimerUtils.FinishDelegate() {
        @Override
        public void onFinish() {

            mTimeTextView.setText("00:00");
            openLottery();
            mPresenter.getLotteryExpect();
            mResultNum.setVisibility(View.GONE);

        }
    };


    //距离封盘时间 倒计时结束回调
    CountDownTimerUtils.FinishDelegate mLeftTimeFinishDelegate = new CountDownTimerUtils.FinishDelegate() {
        @Override
        public void onFinish() {

            mTimeTextView.setText("00:00");
            mLlFendan.setVisibility(View.VISIBLE);
            mResultNum.setText("?");
          /*  mIvRedResult1.setImageResource(R.mipmap.red_ball_result_);
            mIvRedResult2.setImageResource(R.mipmap.red_ball_result_);
            mIvRedResult3.setImageResource(R.mipmap.red_ball_result_);*/
            mPresenter.getRecentCloseExpect();
            mPresenter.getLotteryExpect();

        }
    };

    class AwardResultsQuickAdapter extends BaseQuickAdapter {
        public AwardResultsQuickAdapter(int layoutResId) {
            super(layoutResId);
        }

        @Override
        protected void convert(BaseViewHolder helper, Object item) {
            Handicap cqsscAwardResultBean = (Handicap) item;
            String openCode = cqsscAwardResultBean.getOpenCode().replace(",", " ");
            String[] nums = cqsscAwardResultBean.getOpenCode().split(",");
            helper.setText(R.id.tv_no, getString(R.string.which_periods, cqsscAwardResultBean.getExpect()));
            helper.setText(R.id.tv_num, openCode);
            int addNums = Integer.valueOf(nums[0]) + Integer.valueOf(nums[1]) + Integer.valueOf(nums[2]);
            helper.setText(R.id.tv_hz, addNums + "");
            helper.setText(R.id.tv_dx, getString(addNums < 14 ? R.string.small : R.string.big));
            helper.setText(R.id.tv_ds, getString((addNums % 2) == 0 ? R.string.double_ : R.string.single));

            if (helper.getAdapterPosition() % 2 == 0) {
                helper.itemView.setBackgroundColor(getResources().getColor(R.color.gray));
            } else {
                helper.itemView.setBackgroundColor(getResources().getColor(R.color.white));
            }
        }
    }


    @Subscribe(tags = {@Tag(ConstantValue.EVENT_LOTTERY_CART_DATA_CHANGE)})
    public void orderDataChange(OrderEventBean orderEventBean) {
        super.orderDataChange(orderEventBean);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        RxBus.get().unregister(this);
    }
}
