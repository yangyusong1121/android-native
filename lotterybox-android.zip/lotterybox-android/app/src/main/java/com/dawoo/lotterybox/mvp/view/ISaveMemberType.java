package com.dawoo.lotterybox.mvp.view;

public interface ISaveMemberType extends IBaseView {
    void saveMemberTypeResult(Object o);
}
