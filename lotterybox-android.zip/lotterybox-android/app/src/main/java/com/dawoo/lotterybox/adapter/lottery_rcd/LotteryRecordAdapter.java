package com.dawoo.lotterybox.adapter.lottery_rcd;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.chad.library.adapter.base.BaseViewHolder;
import com.dawoo.coretool.ToastUtil;
import com.dawoo.coretool.util.date.DateTool;
import com.dawoo.lotterybox.R;
import com.dawoo.lotterybox.adapter.SaleAdapter;
import com.dawoo.lotterybox.bean.lottery.LotteryLastOpenAndOpening;
import com.dawoo.lotterybox.util.lottery.K3Util;
import com.dawoo.lotterybox.util.lottery.LHCUtil;
import com.dawoo.lotterybox.util.lottery.LotteryUtil;
import com.dawoo.lotterybox.util.lottery.SSCUtil;
import com.dawoo.lotterybox.util.lottery.SYX5ComputeUtil;
import com.dawoo.lotterybox.view.fragment.xync.Cqxync_DataUtils;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class LotteryRecordAdapter extends RecyclerView.Adapter<BaseViewHolder> {

    public static final int ITEM_TYPE_SSC = 10; //时时彩
    public static final int ITEM_TYPE_PK10 = 20; //pk10
    public static final int ITEM_TYPE_LHC = 30; //六合彩
    public static final int ITEM_TYPE_K3 = 40; //快三
    public static final int ITEM_TYPE_SFC = 50; // 幸运农场
    public static final int ITEM_TYPE_KENO = 60;// keno
    public static final int ITEM_TYPE_FC3D = 70;// 3D
    public static final int ITEM_TYPE_XY28 = 80;//(幸运28)
    public static final int ITEM_TYPE_SYX5 = 91; // 十一选五
    private List<LotteryLastOpenAndOpening> mDatas = new ArrayList<>();
    private Context mContext;
    private OnItemClickLinstener onItemClickLInstener;


    public LotteryLastOpenAndOpening getItemByPosition(int position){
        return mDatas.get(position);
    }
    public LotteryRecordAdapter(Context mContext) {
        super();
        this.mContext = mContext;
    }

    public void setmDatas(List<LotteryLastOpenAndOpening> mDatas) {
        this.mDatas = mDatas;
        notifyDataSetChanged();
    }

    private void setSSC(BaseViewHolder helper, LotteryLastOpenAndOpening rcd) {
        if (rcd.getLastOpenCode() != null && 9 == rcd.getLastOpenCode().length()) {
            String[] OpenCode = rcd.getLastOpenCode().split(",");
            SSCUtil.getImageResourceFormNumber(OpenCode[0], helper.getView(R.id.ssc_ball_one_tv));
            SSCUtil.getImageResourceFormNumber(OpenCode[1], helper.getView(R.id.ssc_ball_tow_tv));
            SSCUtil.getImageResourceFormNumber(OpenCode[2], helper.getView(R.id.ssc_ball_three_tv));
            SSCUtil.getImageResourceFormNumber(OpenCode[3], helper.getView(R.id.ssc_ball_four_tv));
            SSCUtil.getImageResourceFormNumber(OpenCode[4], helper.getView(R.id.ssc_ball_five_tv));
            helper.setText(R.id.ssc_value_sum_tv, "" + SSCUtil.getHeZhi(OpenCode));
            try {
                int code3 = Integer.parseInt(OpenCode[2]);
                int code4 = Integer.parseInt(OpenCode[3]);
                int code5 = Integer.parseInt(OpenCode[4]);
                if ("豹子".equals(SSCUtil.getZuLiuOrZUSan2(code3, code4, code5))) {
                    helper.setGone(R.id.ssc_lable_group_tv, false);
                    helper.setTextColor(R.id.ssc_lable_group_tv, ContextCompat.getColor(mContext, R.color.history_item_green));
                    helper.setTextColor(R.id.ssc_value_group_tv, ContextCompat.getColor(mContext, R.color.history_item_green));
                } else if ("六".equals(SSCUtil.getZuLiuOrZUSan2(code3, code4, code5))) {
                    helper.setGone(R.id.ssc_lable_group_tv, true);
                    helper.setTextColor(R.id.ssc_lable_group_tv, ContextCompat.getColor(mContext, R.color.color_gray_666666));
                    helper.setTextColor(R.id.ssc_value_group_tv, ContextCompat.getColor(mContext, R.color.color_gray_666666));

                } else if ("三".equals(SSCUtil.getZuLiuOrZUSan2(code3, code4, code5))) {
                    helper.setGone(R.id.ssc_lable_group_tv, true);
                    helper.setTextColor(R.id.ssc_lable_group_tv, ContextCompat.getColor(mContext, R.color.colorPrimary));
                    helper.setTextColor(R.id.ssc_value_group_tv, ContextCompat.getColor(mContext, R.color.colorPrimary));
                }
                helper.setText(R.id.ssc_value_group_tv, SSCUtil.getZuLiuOrZUSan2(code3, code4, code5));
            } catch (NumberFormatException e) {
                ToastUtil.showToastShort(mContext, e.getMessage());
            }
        } else {

        }
    }

    private void setPk10(BaseViewHolder helper, LotteryLastOpenAndOpening rcd) {
        // 这期开奖时间
        if (rcd.getLastOpenCode() != null && 29 == rcd.getLastOpenCode().length()) {
            String[] OpenCode = rcd.getLastOpenCode().split(",");
            helper.setBackgroundRes(R.id.pk10_ball_one_tv, getBgPk10(OpenCode[0]));
            helper.setBackgroundRes(R.id.pk10_ball_two_tv, getBgPk10(OpenCode[1]));
            helper.setBackgroundRes(R.id.pk10_ball_three_tv, getBgPk10(OpenCode[2]));
            helper.setBackgroundRes(R.id.pk10_ball_four_tv, getBgPk10(OpenCode[3]));
            helper.setBackgroundRes(R.id.pk10_ball_five_tv, getBgPk10(OpenCode[4]));
            helper.setBackgroundRes(R.id.pk10_ball_six_tv, getBgPk10(OpenCode[5]));
            helper.setBackgroundRes(R.id.pk10_ball_seven_tv, getBgPk10(OpenCode[6]));
            helper.setBackgroundRes(R.id.pk10_ball_eight_tv, getBgPk10(OpenCode[7]));
            helper.setBackgroundRes(R.id.pk10_ball_nine_tv, getBgPk10(OpenCode[8]));
            helper.setBackgroundRes(R.id.pk10_ball_ten_tv, getBgPk10(OpenCode[9]));
        }else{

        }
    }

    int getBgPk10(String code) {
        switch (code) {
            case "01":
                return R.mipmap.car_1;
            case "02":
                return R.mipmap.car_2;
            case "03":
                return R.mipmap.car_3;
            case "04":
                return R.mipmap.car_4;
            case "05":
                return R.mipmap.car_5;
            case "06":
                return R.mipmap.car_6;
            case "07":
                return R.mipmap.car_7;
            case "08":
                return R.mipmap.car_8;
            case "09":
                return R.mipmap.car_9;
            case "10":
                return R.mipmap.car_10;
            default:
                return 0;
        }
    }

    private void setLHC(BaseViewHolder helper, LotteryLastOpenAndOpening rcd) {
        if (rcd.getLastOpenCode() != null && 20 == rcd.getLastOpenCode().length()) {
            String[] OpenCode = rcd.getLastOpenCode().split(",");
            if (OpenCode != null && OpenCode.length == 7) {
                LHCUtil.initBallText(helper.getView(R.id.lhc_ball_one_tv), helper.getView(R.id.lhc_animal_one_tv), OpenCode[0]);
                LHCUtil.initBallText(helper.getView(R.id.lhc_ball_two_tv), helper.getView(R.id.lhc_animal_two_tv), OpenCode[1]);
                LHCUtil.initBallText(helper.getView(R.id.lhc_ball_three_tv), helper.getView(R.id.lhc_animal_three_tv), OpenCode[2]);
                LHCUtil.initBallText(helper.getView(R.id.lhc_ball_four_tv), helper.getView(R.id.lhc_animal_four_tv), OpenCode[3]);
                LHCUtil.initBallText(helper.getView(R.id.lhc_ball_five_tv), helper.getView(R.id.lhc_animal_five_tv), OpenCode[4]);
                LHCUtil.initBallText(helper.getView(R.id.lhc_ball_six_tv), helper.getView(R.id.lhc_animal_six_tv), OpenCode[5]);
                LHCUtil.initBallText(helper.getView(R.id.plhc_ball_eight_tv), helper.getView(R.id.lhc_animal_eight_tv), OpenCode[6]);

                helper.setBackgroundRes(R.id.lhc_ball_one_tv, LHCUtil.getBallbgSolid(OpenCode[0], helper.getView(R.id.lhc_ball_one_tv)));
                helper.setBackgroundRes(R.id.lhc_ball_two_tv, LHCUtil.getBallbgSolid(OpenCode[1], helper.getView(R.id.lhc_ball_two_tv)));
                helper.setBackgroundRes(R.id.lhc_ball_three_tv, LHCUtil.getBallbgSolid(OpenCode[2], helper.getView(R.id.lhc_ball_three_tv)));
                helper.setBackgroundRes(R.id.lhc_ball_four_tv, LHCUtil.getBallbgSolid(OpenCode[3], helper.getView(R.id.lhc_ball_four_tv)));
                helper.setBackgroundRes(R.id.lhc_ball_five_tv, LHCUtil.getBallbgSolid(OpenCode[4], helper.getView(R.id.lhc_ball_five_tv)));
                helper.setBackgroundRes(R.id.lhc_ball_six_tv, LHCUtil.getBallbgSolid(OpenCode[5], helper.getView(R.id.lhc_ball_six_tv)));
                helper.setBackgroundRes(R.id.plhc_ball_eight_tv, LHCUtil.getBallbgSolid(OpenCode[6], helper.getView(R.id.plhc_ball_eight_tv)));

            }
        }else{

        }
    }

    private void setK3(BaseViewHolder helper, LotteryLastOpenAndOpening rcd) {
        if (rcd.getLastOpenCode() != null && 5 == rcd.getLastOpenCode().length()) {
            String[] OpenCode = rcd.getLastOpenCode().split(",");
            helper.setBackgroundRes(R.id.k3_ball_one_tv, getBgK3(OpenCode[0]));
            helper.setBackgroundRes(R.id.k3_ball_tow_tv, getBgK3(OpenCode[1]));
            helper.setBackgroundRes(R.id.k3_ball_three_tv, getBgK3(OpenCode[2]));
            helper.setText(R.id.k3_ball_one_tv, "");
            helper.setText(R.id.k3_ball_tow_tv, "");
            helper.setText(R.id.k3_ball_three_tv, "");
            helper.setTextColor(R.id.k3_ball_one_tv, ContextCompat.getColor(mContext, R.color.transparent));
            helper.setTextColor(R.id.k3_ball_tow_tv, ContextCompat.getColor(mContext, R.color.transparent));
            helper.setTextColor(R.id.k3_ball_three_tv, ContextCompat.getColor(mContext, R.color.transparent));
            helper.setText(R.id.k3_value_sum_tv, "" + K3Util.getHeZhi(OpenCode));
            helper.setText(R.id.k3_lable_group_tv, K3Util.getK3SanBuTongHao(OpenCode));
        }else{

        }
    }

    int getBgK3(String code) {
        switch (code) {
            case "1":
                return R.mipmap.fast1;
            case "2":
                return R.mipmap.fast2;
            case "3":
                return R.mipmap.fast3;
            case "4":
                return R.mipmap.fast4;
            case "5":
                return R.mipmap.fast5;
            case "6":
                return R.mipmap.fast6;
            default:
                return 0;
        }
    }

    private void setSFC(BaseViewHolder helper, LotteryLastOpenAndOpening rcd) {
        if (rcd.getLastOpenCode() != null && 23 == rcd.getLastOpenCode().length()) {
            String[] OpenCode = rcd.getLastOpenCode().split(",");
            Cqxync_DataUtils.getImageResourceFormNumber(OpenCode[0], helper.getView(R.id.sfc_ball_one_tv));
            Cqxync_DataUtils.getImageResourceFormNumber(OpenCode[1], helper.getView(R.id.sfc_ball_two_tv));
            Cqxync_DataUtils.getImageResourceFormNumber(OpenCode[2], helper.getView(R.id.sfc_ball_three_tv));
            Cqxync_DataUtils.getImageResourceFormNumber(OpenCode[3], helper.getView(R.id.sfc_ball_four_tv));
            Cqxync_DataUtils.getImageResourceFormNumber(OpenCode[4], helper.getView(R.id.sfc_ball_five_tv));
            Cqxync_DataUtils.getImageResourceFormNumber(OpenCode[5], helper.getView(R.id.sfc_ball_six_tv));
            Cqxync_DataUtils.getImageResourceFormNumber(OpenCode[6], helper.getView(R.id.sfc_ball_seven_tv));
            Cqxync_DataUtils.getImageResourceFormNumber(OpenCode[7], helper.getView(R.id.sfc_ball_eight_tv));
        }else{

        }
    }

    private void setKeno(BaseViewHolder helper, LotteryLastOpenAndOpening rcd) {
        if (rcd.getLastOpenCode() != null && 59 <= rcd.getLastOpenCode().length()) {
            String[] OpenCode = rcd.getLastOpenCode().split(",");
            helper.setText(R.id.keno_xy28_ball_one_tv, OpenCode[0]);
            helper.setText(R.id.keno_xy28_ball_two_tv, OpenCode[1]);
            helper.setText(R.id.keno_xy28_ball_three_tv, OpenCode[2]);
            helper.setText(R.id.keno_xy28_ball_four_tv, OpenCode[3]);
            helper.setText(R.id.keno_xy28_ball_five_tv, OpenCode[4]);
            helper.setText(R.id.keno_xy28_ball_six_tv, OpenCode[5]);
            helper.setText(R.id.keno_xy28_ball_seven_tv, OpenCode[6]);
            helper.setText(R.id.keno_xy28_ball_eight_tv, OpenCode[7]);
            helper.setText(R.id.keno_xy28_ball_nine_tv, OpenCode[8]);
            helper.setText(R.id.keno_xy28_ball_ten_tv, OpenCode[9]);
            helper.setText(R.id.keno_xy28_ball_eleven_tv, OpenCode[10]);
            helper.setText(R.id.keno_xy28_ball_twelve_tv, OpenCode[11]);
            helper.setText(R.id.keno_xy28_ball_thirteen_tv, OpenCode[12]);
            helper.setText(R.id.keno_xy28_ball_fourteen_tv, OpenCode[13]);
            helper.setText(R.id.keno_xy28_ball_fifteen_tv, OpenCode[14]);
            helper.setText(R.id.keno_xy28_ball_sixteen_tv, OpenCode[15]);
            helper.setText(R.id.keno_xy28_ball_seventeen_tv, OpenCode[16]);
            helper.setText(R.id.keno_xy28_ball_eighteen_tv, OpenCode[17]);
            helper.setText(R.id.keno_xy28_ball_nineteen_tv, OpenCode[18]);
            helper.setText(R.id.keno_xy28_ball_twenty_tv, OpenCode[19]);
        }else{

        }
    }

    String getKenoSingleBigSmall(String[] openCode) {
        int sum = getKenoSumValue(openCode);
        if (sum > 810) {
            return "大";
        } else if (sum < 810) {
            return "小";
        }
        return "和";
    }

    String getKenoCoupleBigSmall(String[] openCode) {
        int sum = getKenoSumValue(openCode);
        String couple;

        if (sum % 2 == 0) {
            couple = "双";
        } else {
            couple = "单";
        }

        if (sum > 810) {
            return "大" + couple;
        } else if (sum < 810) {
            return "小" + couple;
        }
        return "和" + couple;
    }

    String getKenoFiveGo(String[] openCode) {
        int sum = getKenoSumValue(openCode);
        if (sum >= 210 && sum <= 695) {
            return "金";
        } else if (sum >= 696 && sum <= 763) {
            return "木";
        } else if (sum >= 764 && sum <= 855) {
            return "水";
        } else if (sum >= 856 && sum <= 923) {
            return "火";
        } else if (sum >= 924 && sum <= 1410) {
            return "土";
        }

        return "";
    }

    int getKenoSumValue(String[] openCode) {
        int sum = 0;
        for (String i : openCode) {
            int a = Integer.parseInt(i);
            sum = sum + a;
        }
        return sum;
    }

    private void setFC3D(BaseViewHolder helper, LotteryLastOpenAndOpening rcd) {
        if (rcd.getLastOpenCode() != null && 5 == rcd.getLastOpenCode().length()) {
            String[] OpenCode = rcd.getLastOpenCode().split(",");
            helper.setText(R.id.fc3d_ball_one_tv, OpenCode[0]);
            helper.setText(R.id.fc3d_ball_two_tv, OpenCode[1]);
            helper.setText(R.id.fc3d_ball_three_tv, OpenCode[2]);
        }else{

        }
    }

    private void setXY28(BaseViewHolder helper, LotteryLastOpenAndOpening rcd) {

        if (rcd.getLastOpenCode() != null && 5 == rcd.getLastOpenCode().length()) {
            String[] OpenCode = rcd.getLastOpenCode().split(",");
            helper.setText(R.id.xy28_ball_one_tv, OpenCode[0]);
            helper.setText(R.id.xy28_ball_two_tv, OpenCode[1]);
            helper.setText(R.id.xy28_ball_three_tv, OpenCode[2]);
            helper.setText(R.id.xy28_ball_fout_tv, String.valueOf(getXy28Sum(OpenCode)));
            helper.setBackgroundRes(R.id.xy28_ball_one_tv, R.drawable.shape_round_bg);
            helper.setBackgroundRes(R.id.xy28_ball_two_tv, R.drawable.shape_round_bg);
            helper.setBackgroundRes(R.id.xy28_ball_three_tv, R.drawable.shape_round_bg);
            helper.setBackgroundRes(R.id.xy28_ball_fout_tv, R.drawable.shape_round_bg/*shape_ball_red_red*/);
            helper.setTextColor(R.id.xy28_ball_one_tv, ContextCompat.getColor(mContext, R.color.white));
            helper.setTextColor(R.id.xy28_ball_two_tv, ContextCompat.getColor(mContext, R.color.white));
            helper.setTextColor(R.id.xy28_ball_three_tv, ContextCompat.getColor(mContext, R.color.white));
            helper.setTextColor(R.id.xy28_ball_fout_tv, ContextCompat.getColor(mContext, R.color.white));
        }else{

        }
    }

    int getXy28Sum(String[] openCode) {
        int sum = 0;
        for (String i : openCode) {
            int a = Integer.parseInt(i);
            sum = sum + a;
        }

        return sum;
    }

    private void setSYX5(BaseViewHolder helper, LotteryLastOpenAndOpening rcd) {
        if (rcd.getLastOpenCode() != null && rcd.getLastOpenCode().contains(",")) {
            String[] OpenCode = rcd.getLastOpenCode().split(",");
            helper.setText(R.id.ssc_ball_one_tv, OpenCode[0]);
            helper.setText(R.id.ssc_ball_tow_tv, OpenCode[1]);
            helper.setText(R.id.ssc_ball_three_tv, OpenCode[2]);
            helper.setText(R.id.ssc_ball_four_tv, OpenCode[3]);
            helper.setText(R.id.ssc_ball_five_tv, OpenCode[4]);

            helper.setText(R.id.ssc_value_sum_tv, "" + SYX5ComputeUtil.getCount(rcd.getLastOpenCode()));
            helper.setVisible(R.id.value_count_time, false);
            helper.setBackgroundRes(R.id.ssc_ball_one_tv, R.drawable.shape_round_bg);
            helper.setBackgroundRes(R.id.ssc_ball_tow_tv, R.drawable.shape_round_bg);
            helper.setBackgroundRes(R.id.ssc_ball_three_tv, R.drawable.shape_round_bg);
            helper.setBackgroundRes(R.id.ssc_ball_four_tv, R.drawable.shape_round_bg);
            helper.setBackgroundRes(R.id.ssc_ball_five_tv, R.drawable.shape_round_bg);
            helper.setTextColor(R.id.ssc_ball_one_tv, ContextCompat.getColor(mContext, R.color.white));
            helper.setTextColor(R.id.ssc_ball_tow_tv, ContextCompat.getColor(mContext, R.color.white));
            helper.setTextColor(R.id.ssc_ball_three_tv, ContextCompat.getColor(mContext, R.color.white));
            helper.setTextColor(R.id.ssc_ball_four_tv, ContextCompat.getColor(mContext, R.color.white));
            helper.setTextColor(R.id.ssc_ball_five_tv, ContextCompat.getColor(mContext, R.color.white));
            helper.setText(R.id.ssc_value_group_tv, "" + SYX5ComputeUtil.getMantissa(rcd.getLastOpenCode()));
        } else {

        }

    }

    @NonNull
    @Override
    public BaseViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        switch (viewType) {
            case ITEM_TYPE_SSC:
                return new BaseViewHolder(LayoutInflater.from(mContext).inflate(R.layout.fragment_lottery_rcd_ssc, parent, false));

            case ITEM_TYPE_PK10:
                return new BaseViewHolder(LayoutInflater.from(mContext).inflate(R.layout.fragment_lottery_rcd_pk10, parent, false));

            case ITEM_TYPE_LHC:
                return new BaseViewHolder(LayoutInflater.from(mContext).inflate(R.layout.fragment_lottery_rcd_lhc, parent, false));

            case ITEM_TYPE_K3:
                return new BaseViewHolder(LayoutInflater.from(mContext).inflate(R.layout.fragment_lottery_rcd_k3, parent, false));

            case ITEM_TYPE_SFC:
                return new BaseViewHolder(LayoutInflater.from(mContext).inflate(R.layout.fragment_lottery_rcd_sfc, parent, false));

            case ITEM_TYPE_KENO:
                return new BaseViewHolder(LayoutInflater.from(mContext).inflate(R.layout.fragment_lottery_rcd_keno, parent, false));

            case ITEM_TYPE_FC3D:
                return new BaseViewHolder(LayoutInflater.from(mContext).inflate(R.layout.fragment_lottery_rcd_fc3d, parent, false));

            case ITEM_TYPE_XY28:
                return new BaseViewHolder(LayoutInflater.from(mContext).inflate(R.layout.fragment_lottery_rcd_xy28, parent, false));

            case ITEM_TYPE_SYX5:
                return new BaseViewHolder(LayoutInflater.from(mContext).inflate(R.layout.fragment_lottery_rcd_syx5, parent, false));

            default:
                return new BaseViewHolder(LayoutInflater.from(mContext).inflate(R.layout.fragment_lottery_rcd_ssc, parent, false));
        }
    }

    @Override
    public void onBindViewHolder(@NonNull BaseViewHolder helper, int position) {
        helper.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onItemClickLInstener.onItemClickLinstener(position);
            }
        });
        LotteryLastOpenAndOpening rcd = mDatas.get(position);

        // 这期期数
        if (rcd.getLastExpect() != null) {
            helper.setText(R.id.expect_tv, mContext.getResources().getString(R.string.the_expect, rcd.getLastExpect()));
        } else {
            helper.setText(R.id.expect_tv, "");
        }
        if (rcd.getLotteryName() != null) {
            helper.setText(R.id.name_tv, rcd.getLotteryName());
        } else {
            helper.setText(R.id.name_tv, "");
        }
        // 这期开奖时间
        helper.setText(R.id.time_tv, DateTool.convert2String(new Date(rcd.getLastOpenTime()), DateTool.FMT_DATE_TIME));
        helper.itemView.setVisibility(View.VISIBLE);
        switch (helper.getItemViewType()) {
            case ITEM_TYPE_SSC:
                setSSC(helper, rcd);
                break;
            case ITEM_TYPE_PK10:
                setPk10(helper, rcd);
                break;
            case ITEM_TYPE_LHC:
                setLHC(helper, rcd);
                break;
            case ITEM_TYPE_K3:
                setK3(helper, rcd);
                break;
            case ITEM_TYPE_SFC:
                setSFC(helper, rcd);
                break;
            case ITEM_TYPE_KENO:
                setKeno(helper, rcd);
                break;
            case ITEM_TYPE_FC3D:
                setFC3D(helper, rcd);
                break;
            case ITEM_TYPE_XY28:
                setXY28(helper, rcd);
                break;
            case ITEM_TYPE_SYX5:
                setSYX5(helper, rcd);
                break;
        }
    }

    @Override
    public int getItemCount() {
        return mDatas.size();
    }

    @Override
    public int getItemViewType(int position) {
        return LotteryUtil.getDataTypeByCode(mDatas.get(position).getType());
    }


    public interface OnItemClickLinstener{
        void onItemClickLinstener(int position);
    }
    public void setOnItemClickLInstener(OnItemClickLinstener onItemClickLInstener) {
        this.onItemClickLInstener = onItemClickLInstener;
    }
}
