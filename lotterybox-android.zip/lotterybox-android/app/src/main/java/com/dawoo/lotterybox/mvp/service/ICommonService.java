package com.dawoo.lotterybox.mvp.service;

import com.dawoo.lotterybox.net.HttpResult;

import io.reactivex.Observable;
import retrofit2.http.GET;


/**
 * Created by b on 18-5-24.
 * 存放通用的一些接口
 */

public interface ICommonService {
    /**
     * 获取防重复下注token
     *
     * @return
     */
    @GET("hall/mobile/get-lt-token.html")
    Observable<HttpResult<String>> getLtToken();
}
