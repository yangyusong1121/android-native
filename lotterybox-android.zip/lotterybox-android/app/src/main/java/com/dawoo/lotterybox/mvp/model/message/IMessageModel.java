package com.dawoo.lotterybox.mvp.model.message;


import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;


/**
 * Created by archar on 17-12-21.
 */

public interface IMessageModel {
    /**
     * 消息公告列表
     */

    Disposable getBulletins(Observer Observer, String pageSize, String pageNumber);

    /**
     * 收件箱列表
     */

    Disposable getReceiveMsg(Observer Observer, String pageSize, String pageNumber);

    /**
     * 发件箱列表
     */

    Disposable getSendMsg(Observer Observer, String pageSize, String pageNumber);

    /**
     * 删除消息
     */

    Disposable deleteMsg(Observer Observer, Object[] ids);

    /**
     * 消息详情
     */

    Disposable getMsgDetail(Observer Observer, int id, int type);

    /**
     * 回复消息
     */

    Disposable replyMsg(Observer Observer, String username, String content, String title,String token);

    /**
     * 发送消息
     */

    Disposable sendMsg(Observer Observer, String sendType, String content, String title,String token);

    /**
     * 下级代理，下级会员数量
     */

    Disposable getSubordinate(Observer Observer);

}
