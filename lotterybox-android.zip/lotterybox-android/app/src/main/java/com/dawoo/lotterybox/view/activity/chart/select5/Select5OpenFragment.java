package com.dawoo.lotterybox.view.activity.chart.select5;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.dawoo.lotterybox.ConstantValue;
import com.dawoo.lotterybox.R;
import com.dawoo.lotterybox.bean.lottery.Handicap;
import com.dawoo.lotterybox.view.activity.chart.k3.K3OpenFragment;
import com.dawoo.lotterybox.view.fragment.BaseFragment;
import com.hwangjr.rxbus.annotation.Subscribe;
import com.hwangjr.rxbus.annotation.Tag;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;

/**
 * Created by b on 18-6-25.
 */

public class Select5OpenFragment extends BaseFragment {

    @BindView(R.id.rlv_open_result)
    RecyclerView mRlvOpenResult;
    private Unbinder mUnbinder;
    private static final String ARG_PARAM1 = "param1";
    private ArrayList<Handicap> mHandicaps;
    private OpenResultQuickAdapter mQuickAdapter;
    private View mRightFooterView;

    public static Select5OpenFragment newInstance(ArrayList<Handicap> handicaps) {
        Select5OpenFragment fragment = new Select5OpenFragment();
        Bundle args = new Bundle();
        args.putParcelableArrayList(ARG_PARAM1, handicaps);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mHandicaps = getArguments().getParcelableArrayList(ARG_PARAM1);
        }
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_selct5_open, container, false);
        mUnbinder = ButterKnife.bind(this, view);
        initViews();
        return view;
    }

    private void initViews() {
        mQuickAdapter = new OpenResultQuickAdapter(R.layout.layout_select5_open);
        mQuickAdapter.setEmptyView(LayoutInflater.from(mContext).inflate(R.layout.empty_view, null));
        mRlvOpenResult.setLayoutManager(new LinearLayoutManager(mContext));
        mRlvOpenResult.setAdapter(mQuickAdapter);
    }

    @Override
    protected void loadData() {
        mQuickAdapter.setNewData(mHandicaps);
    }

    class OpenResultQuickAdapter extends BaseQuickAdapter {
        public OpenResultQuickAdapter(int layoutResId) {
            super(layoutResId);
        }

        @Override
        protected void convert(BaseViewHolder helper, Object item) {
            Handicap ResultBean = (Handicap) item;
            setItemBg(helper);
            String openCode = ResultBean.getOpenCode().replace(",", " ");
            String expect = ResultBean.getExpect();
            if (TextUtils.isEmpty(expect)) {
                return;
            }
            helper.setText(R.id.tv_no, getString(R.string.which_periods_, ResultBean.getExpect()));
            helper.setText(R.id.tv_award_results, openCode);
            List<String> numbers = Arrays.asList(ResultBean.getOpenCode().split(","));
            Collections.sort(numbers);
            int count = 0;
            if (numbers.size() == 5) {   //接口没做好，包含有3个号的结果
                for (String s : numbers) {
                    if (!s.isEmpty()) {
                        count += Integer.parseInt(s);
                    }
                }
                helper.setText(R.id.tv_count, count + "");
                try {
                    int mantissa = Math.abs(Integer.parseInt(numbers.get(0)) - Integer.parseInt(numbers.get(4)));
                    helper.setText(R.id.tv_mantissa, String.valueOf(mantissa));
                } catch (Exception e) {

                }

            }
        }


        /**
         * 设置item背景颜色
         *
         * @param helper
         */
        void setItemBg(BaseViewHolder helper) {
            int position = helper.getAdapterPosition();
            if (position % 2 == 0) {
                helper.itemView.setBackgroundColor(ContextCompat.getColor(mContext, R.color.white));
            } else {
                helper.itemView.setBackgroundColor(ContextCompat.getColor(mContext, R.color.color_chart_item_bg));
            }
        }
    }

    /**
     * 控制开奖footer
     */
    @Subscribe(tags = {@Tag(ConstantValue.EVENT_TYPE_OPENING_LOTTERY)})
    public void toggleOpenFooter(String s) {
        if (mHandicaps == null) {
            return;
        }
        if ("opening".equals(s)) {
            if (mRightFooterView == null) {
                mRightFooterView = View.inflate(mContext, R.layout.list_item_chart_right_footer_fix_view, null);
            }
            mQuickAdapter.addFooterView(mRightFooterView);
        } else {

            mQuickAdapter.removeFooterView(mRightFooterView);
            mQuickAdapter.notifyDataSetChanged();
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mUnbinder.unbind();
    }
}
