package com.dawoo.lotterybox.mvp.presenter;

import android.content.Context;

import com.dawoo.lotterybox.bean.lottery.LotteryLastOpenAndOpening;
import com.dawoo.lotterybox.bean.lottery.OrderInfo;
import com.dawoo.lotterybox.bean.record.NoteRecordHisData;
import com.dawoo.lotterybox.mvp.model.Lottery.LotteryModel;
import com.dawoo.lotterybox.mvp.model.record.RecordModel;
import com.dawoo.lotterybox.mvp.service.IRecordService;
import com.dawoo.lotterybox.mvp.view.IBaseView;
import com.dawoo.lotterybox.mvp.view.ILastLotteryRecView;
import com.dawoo.lotterybox.mvp.view.INoteRecordHisView;
import com.dawoo.lotterybox.mvp.view.IOrderView;
import com.dawoo.lotterybox.net.RetrofitHelper;
import com.dawoo.lotterybox.net.rx.ProgressSubscriber;


import java.util.List;

import io.reactivex.Observable;
import io.reactivex.disposables.Disposable;

/**
 * Created by b on 18-4-18.
 * 注单信息
 */

public class OrderInfoPresenter<T extends IBaseView> extends BasePresenter {
    private final LotteryModel mModel;
    private IOrderView mView;
    private final RecordModel mRecordModel;

    public OrderInfoPresenter(Context mContext, T view) {
        super(mContext, view);
        this.mView = (IOrderView) view;
        mModel = new LotteryModel();
        mRecordModel = new RecordModel();
    }

    /**
     * 获取注单信息
     */
    public void getOrderInfo(String billNo, String code) {
        Disposable Disposable = mModel.getOrderInfo(new ProgressSubscriber(o ->
                        (mView).onOrderResult((OrderInfo) o), mContext)
                , billNo, code);
        subList.add(Disposable);
    }

    public void getRecords(String code, String today) {
        Disposable Disposable = mRecordModel.getOrders(new ProgressSubscriber(o ->
                        (mView).onRecords((NoteRecordHisData) o), mContext, false),
                code,
                "",
                "",
                today + " 00:00:00",
                today + " 23:59:59",
                120 + "",
                1 + "",
                "",
                "",
                "");

        subList.add(Disposable);
    }

    public void getCustomers(String expect, String code) {
        Disposable Disposable = mModel.getAllCustomerbyCode(new ProgressSubscriber(o ->
                        (mView).onCustomers(o), mContext)
                , expect, code);
        subList.add(Disposable);
    }
}
