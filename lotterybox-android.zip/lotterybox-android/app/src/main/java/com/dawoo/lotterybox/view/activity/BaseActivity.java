package com.dawoo.lotterybox.view.activity;

import android.app.Activity;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentManager;
import android.text.TextUtils;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.blankj.utilcode.util.AppUtils;
import com.blankj.utilcode.util.NetworkUtils;
import com.blankj.utilcode.util.SPUtils;
import com.dawoo.coretool.ToastUtil;
import com.dawoo.coretool.util.activity.ActivityStackManager;
import com.dawoo.coretool.util.activity.DensityUtil;
import com.dawoo.lotterybox.BoxApplication;
import com.dawoo.lotterybox.R;
import com.dawoo.lotterybox.net.rx.ProgressCancelListener;
import com.dawoo.lotterybox.util.AppStatusManager;
import com.dawoo.lotterybox.util.SPConfig;
import com.dawoo.lotterybox.util.ScreenListener;
import com.dawoo.lotterybox.view.activity.setting.LockActivity;
import com.dawoo.lotterybox.view.activity.team.base.OnMultiClickListener;
import com.dawoo.lotterybox.view.activity.webview.AndroidBug5497Workaround2;
import com.dawoo.lotterybox.view.view.CustomProgressDialog;
import com.dawoo.lotterybox.view.view.error.Error401Callback;
import com.dawoo.lotterybox.view.view.error.Error403Callback;
import com.dawoo.lotterybox.view.view.error.Error404Callback;
import com.dawoo.lotterybox.view.view.error.Error603Callback;
import com.dawoo.lotterybox.view.view.error.Error604Callback;
import com.dawoo.lotterybox.view.view.error.Error605Callback;
import com.dawoo.lotterybox.view.view.error.Error607Callback;
import com.dawoo.lotterybox.view.view.error.ErrorBusyCallback;
import com.dawoo.lotterybox.view.view.error.ErrorNetWorkCallback;
import com.dawoo.lotterybox.view.view.error.ErrorNoDataCallback;
import com.gyf.barlibrary.ImmersionBar;
import com.kingja.loadsir.callback.SuccessCallback;
import com.kingja.loadsir.core.LoadService;
import com.kingja.loadsir.core.LoadSir;
import com.kingja.loadsir.core.Transport;
import com.trello.rxlifecycle2.components.support.RxAppCompatActivity;

import butterknife.ButterKnife;
import butterknife.Unbinder;

/**
 * activity的基本类
 * Created by benson on 17-12-19.
 */

public abstract class BaseActivity extends RxAppCompatActivity {
    private Unbinder mBind;
    private ScreenListener mScreenListener;
    static boolean isActive = true;
    private ImmersionBar mImmersionBar;
    protected LoadService loadService;
    protected CustomProgressDialog  mProgressDialog;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        AppStatusManager.getInstance().setAppStatus(AppStatusManager.AppStatusConstant.APP_NORMAL);
        super.onCreate(savedInstanceState);
        checkAppStatus();
        ActivityStackManager.getInstance().addActivity(this);
        if (savedInstanceState != null) {
            FragmentManager manager = getSupportFragmentManager();
            manager.popBackStackImmediate(null, 1);
        }
        createLayoutView();
        initStatusBar();
        mBind = ButterKnife.bind(this);
        loadService = LoadSir.getDefault().register(this);
        initCallBack();
        mScreenListener = new ScreenListener(this);
        mScreenListener.register(new ScreenListener.ScreenStateListener() {
            @Override
            public void onScreenOn() {
                if (SPUtils.getInstance().getBoolean(SPConfig.IS_OPEN_CODE)) {
                    Intent intent = new Intent(BaseActivity.this, LockActivity.class);
                    intent.putExtra(LockActivity.LOCK_TYPE, LockActivity.UN_LOCK);
                    startActivity(intent);
                }

            }

            @Override
            public void onScreenOff() {

            }

            @Override
            public void onUserPresent() {

            }
        });
        initViews();
        initData();
        // your retry logic
        AndroidBug5497Workaround2.assistActivity(this, this);
    }

    public void checkNetWork() {
        if (!NetworkUtils.isConnected()) {
            loadService.showCallback(ErrorNetWorkCallback.class);
        }
    }

    //状态栏
    private void initStatusBar() {
        //兼容４．４
        //   StatusBarUtil.setTranslucent(this,50);
        //     StatusBarUtil.setDarkMode(this);
        mImmersionBar = ImmersionBar
                .with(this);
        mImmersionBar.init();   //所有子类都将继承这些相同的属性
        addStatusView(this);
    }

    //动态设置填充高度
    public static void addStatusView(Activity activity) {
        View top = activity.findViewById(R.id.v_top_child);
        if (top != null) {
            top.post(new Runnable() {
                @Override
                public void run() {
                    top.setLayoutParams(new LinearLayout.LayoutParams
                            (LinearLayout.LayoutParams.MATCH_PARENT, DensityUtil.getStatusBarHeight(activity)));
                }
            });
        }
    }

    //动态设置填充高度
    public static void addStatusView(View view, Context fragment) {
        View top = view.findViewById(R.id.v_top_child);
        if (top != null) {
            top.post(new Runnable() {
                @Override
                public void run() {
                    top.setLayoutParams(new LinearLayout.LayoutParams
                            (LinearLayout.LayoutParams.MATCH_PARENT, DensityUtil.getStatusBarHeight(fragment)));
                }
            });
        }
    }

    protected abstract void createLayoutView();


    protected abstract void initViews();

    protected void initData() {
        checkNetWork();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!isActive) {
            isActive = true;
            if (SPUtils.getInstance().getBoolean(SPConfig.IS_OPEN_CODE)) {
                Intent intent = new Intent(BaseActivity.this, LockActivity.class);
                intent.putExtra(LockActivity.LOCK_TYPE, LockActivity.UN_LOCK);
                startActivity(intent);
            }


        }
    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onRestart() {
        super.onRestart();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (!AppUtils.isAppForeground()) {
            isActive = false;
        }
    }


//    @Override
//    public boolean dispatchTouchEvent(MotionEvent ev) {
//        if (ev.getAction() == MotionEvent.ACTION_DOWN) {
//            View v = getCurrentFocus();
//            if (isShouldHideInput(v, ev)) {
//                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
//                if (imm != null) {
//                    imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
//                }
//            }
//            return super.dispatchTouchEvent(ev);
//        }
//        // 必不可少，否则所有的组件都不会有TouchEvent了
//        if (getWindow().superDispatchTouchEvent(ev)) {
//            return true;
//        }
//        return onTouchEvent(ev);
//    }

    /**
     * 点击 EditText 以外的区域 ，自动收起软键盘
     *
     * @param v
     * @param event
     * @return
     */
    public boolean isShouldHideInput(View v, MotionEvent event) {
        if (v != null && (v instanceof EditText)) {
            int[] leftTop = {0, 0};
            //获取输入框当前的location位置
            v.getLocationInWindow(leftTop);
            int left = leftTop[0];
            int top = leftTop[1];
            int bottom = top + v.getHeight();
            int right = left + v.getWidth();
            if (event.getX() > left && event.getX() < right
                    && event.getY() > top && event.getY() < bottom) {
                // 点击的是输入框区域，保留点击EditText的事件
                return false;
            } else {
                return true;
            }
        }
        return false;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        //当用户返回这个界面的时候让全局的code 变成正常
        BoxApplication.HttpStateCode = 0;
        mBind.unbind();
        if (mImmersionBar != null)
            mImmersionBar.destroy();  //必须调用该方法，防止内存泄漏，不调用该方法，如果界面bar发生改变，在不关闭app的情况下，退出此界面再进入将记忆最后一次bar改变的状态
        mScreenListener.unregister();
        if (mProgressDialog != null) {
            mProgressDialog.cancel();
        }
        ActivityStackManager.getInstance().removeActivity(this);
    }

    private void initCallBack() {
        loadService.setCallBack(SuccessCallback.class, new Transport() {
            @Override
            public void order(Context context, View view) {

            }
        });
        loadService.setCallBack(ErrorNetWorkCallback.class, (context, view) -> {
            LinearLayout llHead = view.findViewById(R.id.ll_head);
            setErrorHead(llHead);
            TextView titleName = view.findViewById(R.id.title_name);
            setErrorTitleName(titleName);
            view.findViewById(R.id.tv_back).setOnClickListener(new OnMultiClickListener() {
                @Override
                public void onMultiClick(View v) {
                    errorRetry();
                }
            });
            FrameLayout back = view.findViewById(R.id.left_btn);
            errorShowBack(back);
        });

        loadService.setCallBack(ErrorBusyCallback.class, (context, view12) -> {
            //一般是服务器连接超时了
            LinearLayout llHead = view12.findViewById(R.id.ll_head);
            setErrorHead(llHead);
            TextView titleName = view12.findViewById(R.id.title_name);
            setErrorTitleName(titleName);
            view12.findViewById(R.id.tv_back)
                    .setOnClickListener(new OnMultiClickListener() {
                        @Override
                        public void onMultiClick(View v) {
                            errorRetry();
                        }
                    });
            FrameLayout back = view12.findViewById(R.id.left_btn);
            errorShowBack(back);
        });

        loadService.setCallBack(ErrorNoDataCallback.class, (context, view13) -> {
            //一般是服务器连接超时了
            LinearLayout llHead = view13.findViewById(R.id.ll_head);
            setErrorHead(llHead);
            TextView titleName = view13.findViewById(R.id.title_name);
            setErrorTitleName(titleName);
            view13.findViewById(R.id.tv_back)
                    .setOnClickListener(new OnMultiClickListener() {
                        @Override
                        public void onMultiClick(View v) {
                            errorRetry();
                        }
                    });
            FrameLayout back = view13.findViewById(R.id.left_btn);
            errorShowBack(back);
        });

        loadService.setCallBack(Error401Callback.class, (context, view13) -> {
            //一般是服务器连接超时了
            LinearLayout llHead = view13.findViewById(R.id.ll_head);
            setErrorHead(llHead);
            TextView titleName = view13.findViewById(R.id.title_name);
            setErrorTitleName(titleName);
            FrameLayout back = view13.findViewById(R.id.left_btn);
            errorShowBack(back);
        });

        loadService.setCallBack(Error403Callback.class, (context, view13) -> {
            //一般是服务器连接超时了
            LinearLayout llHead = view13.findViewById(R.id.ll_head);
            setErrorHead(llHead);
            TextView titleName = view13.findViewById(R.id.title_name);
            setErrorTitleName(titleName);
            view13.findViewById(R.id.tv_back)
                    .setOnClickListener(new OnMultiClickListener() {
                        @Override
                        public void onMultiClick(View v) {
                            errorRetry();
                        }
                    });
            FrameLayout back = view13.findViewById(R.id.left_btn);
            errorShowBack(back);
        });
        loadService.setCallBack(Error404Callback.class, (context, view13) -> {
            //一般是服务器连接超时了
            LinearLayout llHead = view13.findViewById(R.id.ll_head);
            setErrorHead(llHead);
            TextView titleName = view13.findViewById(R.id.title_name);
            setErrorTitleName(titleName);
            view13.findViewById(R.id.tv_back)
                    .setOnClickListener(new OnMultiClickListener() {
                        @Override
                        public void onMultiClick(View v) {
                            errorRetry();
                        }
                    });
            FrameLayout back = view13.findViewById(R.id.left_btn);
            errorShowBack(back);
        });
        loadService.setCallBack(Error603Callback.class, (context, view13) -> {
            //一般是服务器连接超时了
            LinearLayout llHead = view13.findViewById(R.id.ll_head);
            setErrorHead(llHead);
            TextView titleName = view13.findViewById(R.id.title_name);
            setErrorTitleName(titleName);
            FrameLayout back = view13.findViewById(R.id.left_btn);
            back.setVisibility(View.VISIBLE);
            back.setOnClickListener(new OnMultiClickListener() {
                @Override
                public void onMultiClick(View v) {
                    finish();
                }
            });
        });
        loadService.setCallBack(Error604Callback.class, (context, view13) -> {
            //一般是服务器连接超时了
            LinearLayout llHead = view13.findViewById(R.id.ll_head);
            setErrorHead(llHead);
            TextView titleName = view13.findViewById(R.id.title_name);
            setErrorTitleName(titleName);
            FrameLayout back = view13.findViewById(R.id.left_btn);
            back.setVisibility(View.VISIBLE);
            back.setOnClickListener(new OnMultiClickListener() {
                @Override
                public void onMultiClick(View v) {
                    finish();
                }
            });
        });
        loadService.setCallBack(Error605Callback.class, (context, view13) -> {
            //一般是服务器连接超时了
            LinearLayout llHead = view13.findViewById(R.id.ll_head);
            setErrorHead(llHead);
            TextView titleName = view13.findViewById(R.id.title_name);
            setErrorTitleName(titleName);
            FrameLayout back = view13.findViewById(R.id.left_btn);
            back.setVisibility(View.VISIBLE);
            back.setOnClickListener(new OnMultiClickListener() {
                @Override
                public void onMultiClick(View v) {
                    finish();
                }
            });
        });
        loadService.setCallBack(Error607Callback.class, (context, view13) -> {
            //一般是服务器连接超时了
            LinearLayout llHead = view13.findViewById(R.id.ll_head);
            setErrorHead(llHead);
            TextView titleName = view13.findViewById(R.id.title_name);
            setErrorTitleName(titleName);
            FrameLayout back = view13.findViewById(R.id.left_btn);
            back.setVisibility(View.VISIBLE);
            back.setOnClickListener(new OnMultiClickListener() {
                @Override
                public void onMultiClick(View v) {
                    finish();
                }
            });
        });
    }

    protected void errorShowBack(FrameLayout back) {
        back.setVisibility(View.VISIBLE);
        back.setOnClickListener(new OnMultiClickListener() {
            @Override
            public void onMultiClick(View v) {
                finish();
            }
        });
    }

    /**
     * 重写这个方法，重新获取界面的数据
     */
    protected void errorRetry() {
        checkNetWork();
    }


    /**
     * 点击重新加载之后的代码逻辑
     */
    protected void errorRetryResult() {
        if (!NetworkUtils.isConnected()) {
            loadService.showCallback(ErrorNetWorkCallback.class);
        } else {
            returnStateCode();
        }
    }


    protected void setErrorTitleName(TextView tvTitle) {

    }

    protected void setErrorHead(LinearLayout llHead) {
        llHead.setVisibility(View.VISIBLE);
    }

    public void returnStateCode() {
        switch (BoxApplication.HttpStateCode) {
            case 0:
                loadService.showCallback(SuccessCallback.class);
                break;
            case 401:
                //未被授权的访问
                loadService.showCallback(Error401Callback.class);
                break;
            case 403:
                //禁止访问，可能是单个界面。
                loadService.showCallback(Error403Callback.class);
                break;
            case 404:
                //接口不存在导致界面不显示
                if (!NetworkUtils.isConnected()) {
                    loadService.showCallback(ErrorNetWorkCallback.class);
                } else {
                    loadService.showCallback(Error404Callback.class);
                }
                break;
            case 603:
                //域名不正确，一般存在主界面
                loadService.showCallback(Error603Callback.class);
                break;
            case 604:
                //域名过期
                loadService.showCallback(Error604Callback.class);
                break;
            case 605:
                //地区禁止访问
                loadService.showCallback(Error605Callback.class);
                break;
            case 607:
                //系统维护
                loadService.showCallback(Error607Callback.class);
                break;
            case 998:
                //系统维护
                loadService.showCallback(ErrorNetWorkCallback.class);
                break;
            case 999:
                //系统维护
                loadService.showCallback(ErrorBusyCallback.class);
                break;
            case 500:
                //系统维护
                loadService.showCallback(Error607Callback.class);
                break;
            default:
                loadService.showCallback(SuccessCallback.class);
        }

    }

    private void checkAppStatus() {
        if (AppStatusManager.getInstance().getAppStatus() == AppStatusManager.AppStatusConstant.APP_FORCE_KILLED) {
            //应用启动入口SplashActivity，走重启流程
            Intent intent = new Intent(this, SplashActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
        }
    }

    public void initProgressDialog(boolean cancelable, ProgressCancelListener mProgressCancelListener) {
        if (mProgressDialog == null) {
            mProgressDialog = new CustomProgressDialog(this);
        }
        mProgressDialog.setData(cancelable, mProgressCancelListener);
    }

    public void showProgressDialog() {
        if (mProgressDialog != null) {
            mProgressDialog.show();
        }
    }

    public void dissMissProgress() {
        if (mProgressDialog != null && mProgressDialog.isShowing()) {
            mProgressDialog.dismiss();
        }
    }

    /**
     * 复制功能
     *
     * @param content
     */

    public void copy(String content) {
        if (TextUtils.isEmpty(content)) return;
        // 得到剪贴板管理器
        ClipboardManager cmb = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        cmb.setText(content.trim());
        ToastUtil.showToastShort(this, "成功复制到剪切板");
    }

}
