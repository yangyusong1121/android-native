package com.dawoo.lotterybox.mvp.presenter;

import android.content.Context;
import android.text.TextUtils;

import com.blankj.utilcode.util.SPUtils;
import com.dawoo.coretool.ToastUtil;
import com.dawoo.coretool.util.ValidateUtil;
import com.dawoo.lotterybox.R;
import com.dawoo.lotterybox.bean.CheckAccountBean;
import com.dawoo.lotterybox.bean.DataCenter;
import com.dawoo.lotterybox.bean.InfoMation;
import com.dawoo.lotterybox.bean.IpBean;
import com.dawoo.lotterybox.bean.LoginBean;
import com.dawoo.lotterybox.bean.OALinkBean;
import com.dawoo.lotterybox.bean.User;
import com.dawoo.lotterybox.bean.help.HelpBaseBean;
import com.dawoo.lotterybox.mvp.model.user.IUserModel;
import com.dawoo.lotterybox.mvp.model.user.UserModel;
import com.dawoo.lotterybox.mvp.view.IBaseView;
import com.dawoo.lotterybox.mvp.view.IHelpCenter;
import com.dawoo.lotterybox.mvp.view.IIpView;
import com.dawoo.lotterybox.mvp.view.ILoginView;
import com.dawoo.lotterybox.mvp.view.IMCenterFragmentView;
import com.dawoo.lotterybox.mvp.view.IOALinklView;
import com.dawoo.lotterybox.mvp.view.IRegisterView;
import com.dawoo.lotterybox.mvp.view.ISignOutView;
import com.dawoo.lotterybox.mvp.view.IUpDatePasswoldView;
import com.dawoo.lotterybox.mvp.view.IUpdatePermissionPasswordView;
import com.dawoo.lotterybox.mvp.view.IUserApplyAgent;
import com.dawoo.lotterybox.mvp.view.IUserInfoMation;
import com.dawoo.lotterybox.net.BaseHttpResult;
import com.dawoo.lotterybox.net.HttpResult;
import com.dawoo.lotterybox.net.rx.DefaultCallback;
import com.dawoo.lotterybox.net.rx.DefaultSubscriber;
import com.dawoo.lotterybox.net.rx.ProgressSubscriber;
import com.dawoo.lotterybox.util.NumberFormaterUtils;
import com.dawoo.lotterybox.util.SPConfig;

import java.util.List;
import java.util.Random;

import io.reactivex.disposables.Disposable;


/**
 * 用户相关的presenter
 * Created by benson on 18-1-7.
 */

public class UserPresenter<T extends IBaseView> extends BasePresenter {
    private final Context mContext;
    private T mView;
    private final IUserModel mModel;

    public UserPresenter(Context context, T mView) {
        super(context, mView);

        mContext = context;
        this.mView = mView;
        mModel = new UserModel();
    }

    /**
     * 登录
     */
    public void login(String name, String pwd, String appKey, String appSecret, String serialNo, boolean isNeedDialog) {
        Disposable subscription = mModel.login(new ProgressSubscriber(o ->
                        ((ILoginView) mView).onLoginResult((LoginBean) o), mContext, isNeedDialog),
                name,
                pwd,
                appKey,
                appSecret,
                serialNo);
        subList.add(subscription);
    }

    /**
     * 获取头像
     *
     * @return
     */
    public String getHeadIcon() {
        String name = SPUtils.getInstance().getString(SPConfig.USERNAME);
        String url = SPUtils.getInstance().getString(name);
        if (TextUtils.isEmpty(url)) {
            // [0,1)  [0,42)  [1,43)
            int max = 16;
            int min = 1;
            Random random = new Random();
            int num = random.nextInt(max) + min;
            url = "a" + num;
            setIcon(url);
        }
        return url;
    }

    /**
     * 设置头像
     *
     * @return
     */
    public void setIcon(String url) {
        String name = SPUtils.getInstance().getString(SPConfig.USERNAME);
        SPUtils.getInstance().put(name, url);
    }

    /**
     * 注册
     */
    public void register(String name, String pwd, String confirmPwd, String createChannel, String playerType, String mode, String promoCode) {
        /*if (!validate(name, pwd, confirmPwd)) {
            return;
        }*/

        Disposable subscription = mModel.register(new ProgressSubscriber(o ->
                        ((IRegisterView) mView).onRigsterResult((Boolean) o), mContext),
                name,
                pwd,
                confirmPwd,
                createChannel,
                playerType,
                mode,
                promoCode);
        subList.add(subscription);
    }

    public void createAccount(String name, String pwd, String createChannel, String playerType, String parentId) {
        if (!validate(name, pwd, pwd)) {
            return;
        }
        Disposable subscription = mModel.createAccount(new ProgressSubscriber(o ->
                        ((IRegisterView) mView).onRigsterResult((Boolean) o), mContext),
                name,
                pwd,
                createChannel,
                playerType,
                parentId);
        subList.add(subscription);
    }

    /**
     * 注册的验证
     *
     * @param name
     * @param pwd
     * @param confirmPwd
     * @return
     */
    public boolean validate(String name, String pwd, String confirmPwd) {
        // 判断空
        if (TextUtils.isEmpty(name)) {
            ToastUtil.showResShort(mContext, R.string.validate_register_user);
            return false;
        }
        if (TextUtils.isEmpty(pwd)) {
            ToastUtil.showResShort(mContext, R.string.validate_register_pwd);
            return false;
        }
        if (TextUtils.isEmpty(confirmPwd)) {
            ToastUtil.showResShort(mContext, R.string.validate_register_confirm_pwd);
            return false;
        }

        // 密码不相等
        if (!pwd.equals(confirmPwd)) {
            ToastUtil.showResShort(mContext, R.string.validate_register_pwd_not_same);
            return false;
        }

        // 位数不正确
        if (name.length() < 4 || name.length() > 16) {
            ToastUtil.showResShort(mContext, R.string.validate_register_user_regular_correct);
            return false;
        }
        if (pwd.length() < 6 || pwd.length() > 16) {
            ToastUtil.showResShort(mContext, R.string.validate_register_pwd_regular_correct);
            return false;
        }

        // 格式不正确
        if (!ValidateUtil.isStringFormatCorrect(name)) {
            ToastUtil.showResShort(mContext, R.string.validate_register_regular_correct);
            return false;
        }

        return true;
    }


    /**
     * 获取用户信息
     */
    public void getUserInfo(boolean isNeedDialog) {
        Disposable subscription = mModel.getUserInfo(new ProgressSubscriber(o -> ((ILoginView) mView).onGetUserInfo((User) o), mContext, isNeedDialog));
        subList.add(subscription);
    }

    /**
     * 获取用户信息
     */
    public void getUerInfoWithoutDialog() {
        Disposable subscription = mModel.getUserInfo(new ProgressSubscriber(o -> ((IMCenterFragmentView) mView).onInfoResult(o), mContext, false));
        subList.add(subscription);
    }

    public void setUserWithoutToken(User userWithoutToken) {
        User user = DataCenter.getInstance().getUser();
        user.setUsername(userWithoutToken.getUsername() + "");
        String nickName = userWithoutToken.getNickname();
        if (TextUtils.isEmpty(nickName)) user.setNickname("--");
        else user.setNickname(nickName);
        user.setBalance(NumberFormaterUtils.formaterS2S(userWithoutToken.getBalance()));
        user.setUserId(userWithoutToken.getUserId());
        user.setHasSecPwd(userWithoutToken.isHasSecPwd());
        user.setPlayerLevel(userWithoutToken.getPlayerLevel());
        user.setRealName(userWithoutToken.getRealName());
        user.setPlayerType(userWithoutToken.getPlayerType());
        user.setAuthKey(userWithoutToken.getAuthKey());
        user.setPromoCode(userWithoutToken.getPromoCode());
        user.setBecomeAgent(userWithoutToken.getBecomeAgent());
        user.setMode(userWithoutToken.getMode());
    }


    /**
     * 用户登出
     */
    public void signOut() {
        Disposable subscription = mModel.signOut(new ProgressSubscriber(o -> ((ISignOutView) mView).onResult(o), mContext));
        subList.add(subscription);
    }

    /**
     * 用户登出
     */
    public void loginOut() {
        Disposable subscription = mModel.signOut(new ProgressSubscriber(o -> ((IUpDatePasswoldView) mView).onLoginOutResult(o), mContext));
        subList.add(subscription);
    }

    /**
     * 修改密码
     */
    public void upDatePasswold(String oldPwd, String newPwd) {
        Disposable subscription = mModel.upDatePasswold(new ProgressSubscriber(o -> ((IUpDatePasswoldView) mView).onResult((BaseHttpResult) o), mContext), oldPwd, newPwd);
        subList.add(subscription);
    }

    /**
     * 修改玩家昵称
     */
    public void upDateNickName(String nickname) {
        Disposable subscription = mModel.upDateNickName(new ProgressSubscriber(o -> ((IUserInfoMation) mView).onResultNickName((BaseHttpResult) o), mContext), nickname);
        subList.add(subscription);
    }

    /**
     * 修改玩家真实姓名
     */
    public void upDateRealName(String realName) {
        Disposable subscription = mModel.upDateRealName(new ProgressSubscriber(o -> ((IUserInfoMation) mView).onResultNickName((BaseHttpResult) o), mContext), realName);
        subList.add(subscription);
    }


    /**
     * 修改安全密碼
     */
    public void IUpdatePermissionPassword(String upDatePermissionPassword) {
        Disposable subscription = mModel.upDatePermissionPassword(new ProgressSubscriber(o -> ((IUpdatePermissionPasswordView) mView).onResult((BaseHttpResult) o), mContext), upDatePermissionPassword);
        subList.add(subscription);
    }

    /**
     * 校验安全密碼
     */
    public void qureyPermissionPassword(String upDatePermissionPassword) {
        Disposable subscription = mModel.quirePermissionPassword(new ProgressSubscriber(o -> ((IUpdatePermissionPasswordView) mView).onResult((BaseHttpResult) o), mContext), upDatePermissionPassword);
        subList.add(subscription);
    }

    /**
     * 合并Ｕser和Setting,my bank card的请求
     */
    public void getUserInfoWithSystemSetting() {
        Disposable subscription = mModel.getUserInfoWithSystemSetting(new ProgressSubscriber(o -> ((IMCenterFragmentView) mView).onInfoResult(o), mContext));
        subList.add(subscription);
    }


    public void getCreateOALink() {
        Disposable subscription = mModel.getCreateAccocuntLink(new ProgressSubscriber(o -> ((IOALinklView) mView).onLinkResult((OALinkBean) o), mContext));
        subList.add(subscription);
    }


    /**
     * 转战用户名称校验
     *
     * @param name
     */
    public void checkName(String name) {
        Disposable subscription = mModel.checkLoginName(new ProgressSubscriber(o -> ((ILoginView) mView).checkName((CheckAccountBean) o), mContext), name);
        subList.add(subscription);
    }

    /**
     * 申请代理
     */
    public void applyAgent() {
        Disposable subscription = mModel.applyAgent(new ProgressSubscriber(o -> ((IUserApplyAgent) mView).applyAgentResult(o), mContext));
        subList.add(subscription);
    }

    public void checkReal(String name, String realName, String bankNum) {
        Disposable subscription = mModel.checkAccount(new ProgressSubscriber(o -> ((ILoginView) mView).onCheckReal((HttpResult) o), mContext), name, realName, bankNum);
        subList.add(subscription);
    }

    public void setpwd(String name, String pwd) {
        Disposable subscription = mModel.accountPassword(new ProgressSubscriber(o -> ((ILoginView) mView).doPwdToggle(), mContext), name, pwd);
        subList.add(subscription);
    }

    public void testAccountLogin(String appkey, String appSecret, String serialNo) {
        Disposable subscription = mModel.testAccountLogin(new ProgressSubscriber(o -> ((ILoginView) mView).onLoginResult((LoginBean) o), mContext, true), appkey, appSecret, serialNo);
        subList.add(subscription);
    }

    /**
     * 帮助中心
     */
    public void getHelp() {
        Disposable subscription = mModel.getHelp(new ProgressSubscriber(o -> ((IHelpCenter) mView).helpCenter((HelpBaseBean) o), mContext));
        subList.add(subscription);
    }

    @Override
    public void onDestory() {
        super.onDestory();
    }
}
