package com.dawoo.lotterybox.bean.lottery.lotteryenum;

public enum BaseLotteryEnum {
    K3("k3", 40),
    LHC("lhc", 30),
    SSC("ssc", 10),
    PK10("pk10", 20),
    SFC("sfc", 50),
    KENO("keno", 60),
    XY28("xy28", 80),
    PL3("pl3", 70),
    SYXW("syx5", 91),
    NN("nn", 20),
    BJL("bjl", 20);
    private String type;
    private int rcdFlag;

    BaseLotteryEnum(String type, int rcdFlag) {
        this.type = type;
        this.rcdFlag = rcdFlag;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getRcdFlag() {
        return rcdFlag;
    }

    public void setRcdFlag(int rcdFlag) {
        this.rcdFlag = rcdFlag;
    }
}
