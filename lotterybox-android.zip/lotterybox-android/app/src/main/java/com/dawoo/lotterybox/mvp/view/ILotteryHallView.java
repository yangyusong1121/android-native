package com.dawoo.lotterybox.mvp.view;

import com.dawoo.lotterybox.bean.User;

/**
 * Created by benson on 18-2-8.
 */

public interface ILotteryHallView extends IBaseView {
}
