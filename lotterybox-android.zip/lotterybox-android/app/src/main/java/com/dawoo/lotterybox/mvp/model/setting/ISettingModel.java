package com.dawoo.lotterybox.mvp.model.setting;

import java.util.Date;
import java.util.Map;

import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;


/**
 * Created by alex on 18-4-3.
 */

public interface ISettingModel {

    Disposable getSystemSetting(Observer subscriber);

    Disposable updateSystemSetting(Observer subscriber, Map<String, String> params);


    Disposable getFeedback(Observer subscriber,String type,  String module, String faultTime,
                              String content,  String contact,  String Platform);

}
