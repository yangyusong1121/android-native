package com.dawoo.lotterybox.mvp.view;

/**
 * webview的iveiw
 * Created by benson on 18-1-8.
 */

public interface IWebView extends IBaseView {
    void initWebSetting();
}
