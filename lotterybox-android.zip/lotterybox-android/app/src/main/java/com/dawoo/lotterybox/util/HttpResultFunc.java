package com.dawoo.lotterybox.util;

import com.dawoo.lotterybox.BoxApplication;
import com.dawoo.lotterybox.net.ApiException;
import com.dawoo.lotterybox.net.HttpResult;

import io.reactivex.functions.Function;

public class HttpResultFunc<T> implements Function<HttpResult<T>, T> {


    @Override
    public T apply(HttpResult<T> httpResult) {
        if (0 != httpResult.getError()) {
            throw new ApiException(httpResult.getCode(), httpResult.getMessage());

        }
        BoxApplication.HttpStateCode = httpResult.getError();

        return httpResult.getData();
    }
}