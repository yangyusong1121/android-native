package com.dawoo.lotterybox.adapter.lhc;

import android.graphics.Color;
import android.os.Build;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.view.View;
import android.widget.TextView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.dawoo.lotterybox.BoxApplication;
import com.dawoo.lotterybox.R;
import com.dawoo.lotterybox.bean.playtype.ParentPlayTypeBean;

import java.util.List;

/**
 * Created by rain on 18-3-7.
 */

public class LHCParentPlayAdapter extends BaseQuickAdapter{
    public LHCParentPlayAdapter(int layoutResId, @Nullable List data) {
        super(layoutResId, data);
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void convert(BaseViewHolder helper, Object item) {
        ParentPlayTypeBean typeBean= (ParentPlayTypeBean) item;
        helper.setText(R.id.tv_sscb_palyType,typeBean.getName());
        helper.itemView.setSelected(typeBean.isChoose());
       /* if(typeBean.isChoose()){
            helper.itemView.setSelected(true);
            TextView viewById = helper.itemView.findViewById(R.id.tv_sscb_palyType);
            viewById.setTextAppearance(R.style.check_text_style);
          //  helper.setTextColor(R.id.tv_sscb_palyType,mContext.getResources().getColor(R.color.colorPrimary));
        }else{

            helper.setTextColor(R.id.tv_sscb_palyType, mContext.getResources().getColor(R.color.text_blue));

        }*/
    }
}
