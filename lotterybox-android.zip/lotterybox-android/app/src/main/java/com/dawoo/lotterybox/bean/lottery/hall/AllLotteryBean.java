package com.dawoo.lotterybox.bean.lottery.hall;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by b on 18-5-30.
 */

public class AllLotteryBean {

//         "smallImageUrl":""
//        "name":"时时彩"

    private String smallImageUrl="";
    private String name="";
    private List<LotteryBean> datas = new ArrayList<>();

    public String getSmallImageUrl() {
        return smallImageUrl;
    }

    public void setSmallImageUrl(String smallImageUrl) {
        this.smallImageUrl = smallImageUrl;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<LotteryBean> getLotterys() {
        return datas;
    }

    public void setLotterys(List<LotteryBean> lotterys) {
        this.datas = lotterys;
    }
}
