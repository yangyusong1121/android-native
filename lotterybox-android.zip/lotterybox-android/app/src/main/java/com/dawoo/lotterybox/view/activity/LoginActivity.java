package com.dawoo.lotterybox.view.activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;

import com.blankj.utilcode.util.ActivityUtils;
import com.blankj.utilcode.util.SPUtils;
import com.blankj.utilcode.util.ToastUtils;
import com.dawoo.coretool.util.LogUtils;
import com.dawoo.coretool.util.activity.KeyboardUtil;
import com.dawoo.lotterybox.ConstantValue;
import com.dawoo.lotterybox.R;
import com.dawoo.lotterybox.bean.CheckAccountBean;
import com.dawoo.lotterybox.bean.DataCenter;
import com.dawoo.lotterybox.bean.LoginBean;
import com.dawoo.lotterybox.bean.User;
import com.dawoo.lotterybox.mvp.presenter.UserPresenter;
import com.dawoo.lotterybox.mvp.view.ILoginView;
import com.dawoo.lotterybox.net.HttpResult;
import com.dawoo.lotterybox.net.RetrofitHelper;
import com.dawoo.lotterybox.net.TlsSniSocketFactory;
import com.dawoo.lotterybox.net.TrueHostnameVerifier;
import com.dawoo.lotterybox.util.ActivityUtil;
import com.dawoo.lotterybox.util.NetUtil;
import com.dawoo.lotterybox.util.SPConfig;
import com.dawoo.lotterybox.util.SSLUtil;
import com.dawoo.lotterybox.util.SharePreferenceUtil;
import com.dawoo.lotterybox.util.SingleToast;
import com.dawoo.lotterybox.view.activity.account.CheckRealActivity;
import com.dawoo.lotterybox.view.view.ClearEditText;
import com.dawoo.lotterybox.view.view.HeaderView;
import com.hwangjr.rxbus.RxBus;
import com.hwangjr.rxbus.annotation.Subscribe;
import com.hwangjr.rxbus.annotation.Tag;

import java.io.IOException;

import butterknife.BindView;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * 登录
 * Created by benson on 17-12-21.
 */

public class LoginActivity extends BaseActivity implements ILoginView {

    @BindView(R.id.head_view)
    HeaderView mHeadView;
    @BindView(R.id.name_et)
    ClearEditText mNameEt;
    @BindView(R.id.user_pwd_iv)
    ImageView mUserPwdIv;
    @BindView(R.id.pwd_et)
    ClearEditText mPwdEt;
    @BindView(R.id.input_type_iv)
    ImageView mInputTypeIv;
    @BindView(R.id.forget_pwd_tv)
    TextView mForgetPwdTv;
    @BindView(R.id.login_btn)
    Button mLoginBtn;
    @BindView(R.id.register_btn)
    Button mRegisterBtn;
    @BindView(R.id.tv_head)
    TextView mCopyRightTv;
    @BindView(R.id.password_switch)
    Switch mPasswordSwitch;
    private UserPresenter mPresenter;
    private boolean ispwdLogin;

    @Override
    protected void createLayoutView() {
        setContentView(R.layout.activity_login);
    }

    @Override
    protected void initViews() {
        RxBus.get().register(this);
        mHeadView.setHeader(getString(R.string.title_name_activity_login), true);
        mNameEt.setText(SPUtils.getInstance().getString(SPConfig.USERNAME));
        mNameEt.setSelection(mNameEt.getText().toString().trim().length());
    }

    @Override
    protected void initData() {
        mPasswordSwitch.setChecked(SPUtils.getInstance().getBoolean(SPConfig.IS_SAVE_PASSWORD, false));
        if (SPUtils.getInstance().getBoolean(SPConfig.IS_SAVE_PASSWORD, false)) {
            mPwdEt.setText(SPUtils.getInstance().getString(SPConfig.PASSWORD));
        }
        mCopyRightTv.setText(ConstantValue.COPY_RIGHT);
        mPresenter = new UserPresenter<>(this, this);
    }

    @Override
    protected void onDestroy() {
        mPresenter.onDestory();
        RxBus.get().unregister(this);
        super.onDestroy();
    }


    @Override
    public void onLoginResult(LoginBean loginBean) {
        if (loginBean != null) {
            if (ispwdLogin) {
                String name = mNameEt.getText().toString().trim();
                String pwd = mPwdEt.getText().toString().trim();
                SPUtils.getInstance().put(SPConfig.USERNAME, name);
                SPUtils.getInstance().put(SPConfig.PASSWORD, pwd);
                SPUtils.getInstance().put(SPConfig.IS_SAVE_PASSWORD, mPasswordSwitch.isChecked());
            }
            User user = new User();
            //user.setUsername(name);
            user.setLogin(true);
            user.setToken(loginBean.getToken());
            user.setRefreshToken(loginBean.getRefreshToken());
            user.setExpire(loginBean.getExpire());
            //user.setPassword(pwd);
            user.setAvatarUrl(mPresenter.getHeadIcon());
            DataCenter.getInstance().setUser(user);
            RxBus.get().post(ConstantValue.EVENT_TYPE_LOGINED, "login");
            mPresenter.getUserInfo(true);
        }
    }

    @Override
    public void doLogin() {
        KeyboardUtil.hideInputKeyboard(this);
        String name = mNameEt.getText().toString().trim();
        String pwd = mPwdEt.getText().toString().trim();
        String appKey = getResources().getString(R.string.app_key);
        String appSecret = getResources().getString(R.string.app_secret);
        String serialNo = DataCenter.getInstance().getSysInfo().getMac();
        ispwdLogin = true;
        mPresenter.login(name, pwd, appKey, appSecret, serialNo, true);

    }


    @Override
    public void doPwdToggle() {
        if (mInputTypeIv.isSelected()) {
            mInputTypeIv.setSelected(false);
            mPwdEt.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        } else {
            mInputTypeIv.setSelected(true);
            mPwdEt.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_NORMAL);
        }
        mPwdEt.setSelection(mPwdEt.getText().length());
        KeyboardUtil.hideInputKeyboard(this);
    }

    @Override
    public void onGetUserInfo(User user) {
        if (user != null) {
            mPresenter.setUserWithoutToken(user);
            RxBus.get().post(ConstantValue.EVENT_TYPE_USER_INFO, "mcfragment_user_info");
            finish();
        }
    }

    @Override
    public void checkName(CheckAccountBean bean) {
        if (!bean.isVerification() || bean.getStatus() != 0) {
            doLogin();
        } else {
            Bundle mBundle = new Bundle();
            mBundle.putString("name", mNameEt.getText().toString().trim());
            mBundle.putString("pwd", mPwdEt.getText().toString().trim());
            mBundle.putBoolean("isRealName", bean.isName_verification());
            mBundle.putBoolean("isBankCard", bean.isBankNumber_verification());
            ActivityUtils.startActivity(mBundle, CheckRealActivity.class);
        }
    }

    @Override
    public void onCheckReal(HttpResult httpResult) {

    }


    @OnClick({R.id.input_type_iv, R.id.forget_pwd_tv, R.id.login_btn, R.id.register_btn, R.id.test_login_btn})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.input_type_iv:
                doPwdToggle();
                break;
            case R.id.forget_pwd_tv:
                ActivityUtil.gotoCustomerService();
                break;
            case R.id.login_btn:
                KeyboardUtil.hideInputKeyboard(this);
                String name = mNameEt.getText().toString().trim();
                String pwd = mPwdEt.getText().toString().trim();
                if (name.isEmpty()) {
                    SingleToast.showMsg("请输入用户名");
                    return;
                }
                if (pwd.isEmpty() || mPwdEt.getText().toString().trim().length() < 6) {
                    SingleToast.showMsg("请输入正确的密码");
                    return;
                }
                mPresenter.checkName(name);
                break;
            case R.id.register_btn:
                startRegisterActivity();
                break;
            case R.id.test_login_btn:
                ispwdLogin = false;
                mPresenter.testAccountLogin(getResources().getString(R.string.app_key),
                        getResources().getString(R.string.app_secret), DataCenter.getInstance().getSysInfo().getMac());
                break;
            default:
        }
    }

    private void startRegisterActivity() {
        Intent intent = new Intent(this, RegisterActivity.class);
        intent.putExtra(RegisterActivity.MODE, RegisterActivity.MODE_STANDAR);
        startActivity(intent);
    }

    String msg = "";

    @Subscribe(tags = @Tag(ConstantValue.EVENT_TYPE_NETWORK_EXCEPTION))
    public void onReturnError(String message) {
        //错误的密码，SP滞空
        SPUtils.getInstance().put(SPConfig.PASSWORD, "");
        if (msg.equals(message)) {
        } else {
            ToastUtils.showShort(message);
            msg = message;
        }
    }

    @Subscribe(tags = {@Tag("accountFinish")})
    public void finshThisActivity(String s) {
        //  收起刷新
        doLogin();
    }
}
