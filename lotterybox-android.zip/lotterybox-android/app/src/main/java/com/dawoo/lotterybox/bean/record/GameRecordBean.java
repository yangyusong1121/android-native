package com.dawoo.lotterybox.bean.record;

public class GameRecordBean {
    private String code = "";
    private double payout = 0.00;
    private double profitloss = 0.00;
    private String lotteryName = "";
    private double betamount = 0.00;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public double getPayout() {
        return payout;
    }

    public void setPayout(double payout) {
        this.payout = payout;
    }

    public double getProfitloss() {
        return profitloss;
    }

    public void setProfitloss(double profitloss) {
        this.profitloss = profitloss;
    }

    public String getLotteryName() {
        return lotteryName;
    }

    public void setLotteryName(String lotteryName) {
        this.lotteryName = lotteryName;
    }

    public double getBetamount() {
        return betamount;
    }

    public void setBetamount(double betamount) {
        this.betamount = betamount;
    }
}
