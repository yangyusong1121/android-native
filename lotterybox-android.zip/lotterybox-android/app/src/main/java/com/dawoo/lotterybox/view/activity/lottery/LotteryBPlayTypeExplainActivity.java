package com.dawoo.lotterybox.view.activity.lottery;

import android.content.Context;
import android.content.Intent;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.FrameLayout;

import com.dawoo.lotterybox.BoxApplication;
import com.dawoo.lotterybox.ConstantValue;
import com.dawoo.lotterybox.R;
import com.dawoo.lotterybox.bean.lottery.lotteryenum.BaseLotteryEnum;
import com.dawoo.lotterybox.view.activity.BaseActivity;
import com.dawoo.lotterybox.view.view.HeaderView;

import butterknife.BindView;

/**
 * Created by archar on 18-3-12.
 */

public class LotteryBPlayTypeExplainActivity extends BaseActivity {
    public static final String LT_CODE = "lottery_code";
    public static final String HkLHC = "hklhc";

    @BindView(R.id.head_view)
    HeaderView mHeadView;
    @BindView(R.id.fl_webViewLayout)
    FrameLayout mFlWebViewLayout;


    private WebView mWebview;

    private String mCurrentLotteryCode;

    public static void goWfActivity(Context context, String lotteryType) {
        Intent intent = new Intent(context, LotteryBPlayTypeExplainActivity.class);
        intent.putExtra(ConstantValue.LT_TYPE, lotteryType);
        context.startActivity(intent);
    }


    @Override
    protected void createLayoutView() {
        setContentView(R.layout.activity_lottery_b_explain);
    }

    @Override
    protected void initViews() {
        mCurrentLotteryCode = "ssc";
        mHeadView.setHeader(getString(R.string.wf_pop), true);
        if (getIntent().getStringExtra(ConstantValue.LT_TYPE) != null) {
            mCurrentLotteryCode = getIntent().getStringExtra(ConstantValue.LT_TYPE);
        }
        createWebView();
    }


    private void createWebView() {
        mWebview = new WebView(BoxApplication.getContext());
        FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT);
        mWebview.setLayoutParams(layoutParams);
        mFlWebViewLayout.addView(mWebview);
        WebSettings webSettings = mWebview.getSettings();
        webSettings.setLoadWithOverviewMode(true);
        webSettings.setUseWideViewPort(true);
        mWebview.setVerticalScrollBarEnabled(true);
        mWebview.setBackgroundColor(getResources().getColor(R.color.custom_blue_light));
    }

    @Override
    protected void initData() {

        if (mCurrentLotteryCode.equalsIgnoreCase(BaseLotteryEnum.SSC.getType())) {
            mWebview.loadUrl("file:///android_asset/html/playexplain/sscB_explain.html");
        } else if (mCurrentLotteryCode.equalsIgnoreCase(BaseLotteryEnum.PK10.getType())){
            mWebview.loadUrl("file:///android_asset/html/playexplain/bjPk10B_explain.html");
        } else if (mCurrentLotteryCode.equalsIgnoreCase(BaseLotteryEnum.K3.getType())) {
            mWebview.loadUrl("file:///android_asset/html/playexplain/jsk3B_explain.html");
        } else if (mCurrentLotteryCode.equalsIgnoreCase(BaseLotteryEnum.KENO.getType())) {
            mWebview.loadUrl("file:///android_asset/html/playexplain/bjkl8_explain.html");
        } else if (mCurrentLotteryCode.equalsIgnoreCase(BaseLotteryEnum.XY28.getType())) {
            mWebview.loadUrl("file:///android_asset/html/playexplain/xy28_explain.html");
        } else if (mCurrentLotteryCode.equalsIgnoreCase(BaseLotteryEnum.LHC.getType())) {
            mWebview.loadUrl("file:///android_asset/html/playexplain/hklhc_explain.html");
        } else if (mCurrentLotteryCode.equalsIgnoreCase(BaseLotteryEnum.SFC.getType())) {
            mWebview.loadUrl("file:///android_asset/html/playexplain/cqxync.html");
        } else if (mCurrentLotteryCode.equalsIgnoreCase(BaseLotteryEnum.PL3.getType())) {
            mWebview.loadUrl("file:///android_asset/html/playexplain/qt_explain.html");
        } else if(mCurrentLotteryCode.equalsIgnoreCase(BaseLotteryEnum.SYXW.getType())){
           // mWebview.loadUrl("file:///android_asset/html/playexplain/syx5_explain.html");
        }
    }

    @Override
    protected void onDestroy() {
        if (mWebview != null) {
            mWebview.clearHistory();
            ((ViewGroup) mWebview.getParent()).removeView(mWebview);
            mWebview.destroy();
            mWebview = null;
        }
        super.onDestroy();
    }

}
