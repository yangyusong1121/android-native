package com.dawoo.lotterybox.bean;

public class ChooseBean {
    String data;
    boolean isChoosed;

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public boolean isChoosed() {
        return isChoosed;
    }

    public void setChoosed(boolean choosed) {
        isChoosed = choosed;
    }
}
