package com.dawoo.lotterybox.mvp.view;


import com.dawoo.lotterybox.bean.CheckAccountBean;
import com.dawoo.lotterybox.bean.LoginBean;
import com.dawoo.lotterybox.bean.User;
import com.dawoo.lotterybox.net.HttpResult;

/**
 * Created by benson on 17-12-21.
 */

public interface ILoginView extends IBaseView {

    void onLoginResult(LoginBean o);
    void doLogin();
    void doPwdToggle();
    void onGetUserInfo(User user);

    void checkName(CheckAccountBean bean);
    void onCheckReal(HttpResult httpResult);
}

