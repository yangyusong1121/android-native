package com.dawoo.lotterybox.bean.Deposit;

/**
 * Created by rain on 18-5-4.
 */

public class SaleBean {
    private String activityName;
    private int id;
    private double money;

    public double getMoney() {
        return money;
    }

    public void setMoney(double money) {
        this.money = money;
    }

    public String getActivityName() {
        return activityName;
    }

    public void setActivityName(String activityName) {
        this.activityName = activityName;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public SaleBean() {
        activityName = "不参与活动";
        id = 0;
    }
}
