package com.dawoo.lotterybox.mvp.view;

/**
 * Created by alex on 18-4-9.
 */

public interface IRecordView  extends IBaseView{
    void result(Object o);
}
