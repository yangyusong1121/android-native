package com.dawoo.lotterybox.bean;

public class TeamAgentDetail {


    /**
     * rebate : 0
     * bonus : 0
     * memberCount : 0
     * payout : 0
     * betaumont : 0
     * favorable : 0
     * deposittotal : 0
     * effectivevolume : 0
     * wages : 0
     * balance : 0
     * id : 11265
     * withdrawtotal : 0
     * profit : 0
     * agentCount : 0
     * username : jite01
     */

    private double rebate;
    private double bonus;
    private int memberCount;
    private double payout;
    private double betaumont;
    private double favorable;
    private double deposittotal;
    private double effectivevolume;
    private double wages;
    private double balance;
    private double id;
    private double withdrawtotal;
    private double profit;
    private int agentCount;
    private String username;
    private long lastlogintime;

    public double getRebate() {
        return rebate;
    }

    public void setRebate(double rebate) {
        this.rebate = rebate;
    }

    public double getBonus() {
        return bonus;
    }

    public void setBonus(double bonus) {
        this.bonus = bonus;
    }

    public int getMemberCount() {
        return memberCount;
    }

    public void setMemberCount(int memberCount) {
        this.memberCount = memberCount;
    }

    public double getPayout() {
        return payout;
    }

    public void setPayout(double payout) {
        this.payout = payout;
    }

    public double getBetaumont() {
        return betaumont;
    }

    public void setBetaumont(double betaumont) {
        this.betaumont = betaumont;
    }

    public double getFavorable() {
        return favorable;
    }

    public void setFavorable(double favorable) {
        this.favorable = favorable;
    }

    public double getDeposittotal() {
        return deposittotal;
    }

    public void setDeposittotal(double deposittotal) {
        this.deposittotal = deposittotal;
    }

    public double getEffectivevolume() {
        return effectivevolume;
    }

    public void setEffectivevolume(double effectivevolume) {
        this.effectivevolume = effectivevolume;
    }

    public double getWages() {
        return wages;
    }

    public void setWages(double wages) {
        this.wages = wages;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public double getId() {
        return id;
    }

    public void setId(double id) {
        this.id = id;
    }

    public double getWithdrawtotal() {
        return withdrawtotal;
    }

    public void setWithdrawtotal(double withdrawtotal) {
        this.withdrawtotal = withdrawtotal;
    }

    public double getProfit() {
        return profit;
    }

    public void setProfit(double profit) {
        this.profit = profit;
    }

    public int getAgentCount() {
        return agentCount;
    }

    public void setAgentCount(int agentCount) {
        this.agentCount = agentCount;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public long getLastlogintime() {
        return lastlogintime;
    }

    public void setLastlogintime(long lastlogintime) {
        this.lastlogintime = lastlogintime;
    }
}
