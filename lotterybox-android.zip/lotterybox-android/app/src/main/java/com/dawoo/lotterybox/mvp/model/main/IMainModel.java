package com.dawoo.lotterybox.mvp.model.main;


import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;

/**
 * Created by b on 18-2-16.
 */

public interface IMainModel {

    Disposable getVersionsData(Observer subscriber, int versionCode);

}
