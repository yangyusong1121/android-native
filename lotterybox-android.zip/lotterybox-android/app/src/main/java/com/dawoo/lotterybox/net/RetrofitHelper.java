package com.dawoo.lotterybox.net;


import android.content.SharedPreferences;
import android.os.Build;
import android.util.Log;
import android.webkit.CookieManager;

import com.dawoo.coretool.util.LogUtils;
import com.dawoo.coretool.util.packageref.PackageInfoUtil;
import com.dawoo.lotterybox.BoxApplication;
import com.dawoo.lotterybox.BuildConfig;
import com.dawoo.lotterybox.ConstantValue;
import com.dawoo.lotterybox.bean.DataCenter;
import com.dawoo.lotterybox.util.NetUtil;
import com.dawoo.lotterybox.util.NullOnEmptyConverterFactory;
import com.dawoo.lotterybox.util.SSLUtil;
import com.google.gson.Gson;
import com.hwangjr.rxbus.RxBus;

import java.io.IOException;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

import okhttp3.Headers;
import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * Created by benson on 17-12-20.
 */

public class RetrofitHelper {
    private static final int DEFAULT_TIMEOUT_SECONDS = 7;
    private static final int DEFAULT_READ_TIMEOUT_SECONDS = 20;
    private static final int DEFAULT_WRITE_TIMEOUT_SECONDS = 20;
    private Retrofit mRetrofit;

    private static RetrofitHelper INSTANCE;

    private RetrofitHelper() {
        OkHttpClient.Builder builder = new OkHttpClient.Builder();
        builder.connectTimeout(DEFAULT_TIMEOUT_SECONDS, TimeUnit.SECONDS)
                .readTimeout(DEFAULT_READ_TIMEOUT_SECONDS, TimeUnit.SECONDS)
                .writeTimeout(DEFAULT_WRITE_TIMEOUT_SECONDS, TimeUnit.SECONDS)
                .retryOnConnectionFailure(true)
//                .addInterceptor(new ReceivedCookiesInterceptor())
//                .addInterceptor(new AddCookiesInterceptor())
                .addInterceptor(new LoggingInterceptor());
        String domain = DataCenter.getInstance().getDomain();
        builder.sslSocketFactory(new TlsSniSocketFactory(domain), new SSLUtil.TrustAllManager())
                .hostnameVerifier(new TrueHostnameVerifier(domain));

        // HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor();
        //   日志拦截器
        HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor();
        if (BuildConfig.DEBUG) {
            interceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
        } else {
            interceptor.setLevel(HttpLoggingInterceptor.Level.NONE);
        }
        builder.addInterceptor(interceptor);  // 添加httplog

        if (mRetrofit == null) {
            mRetrofit = new Retrofit.Builder()
                    .baseUrl(DataCenter.getInstance().getHsot())
                    .addConverterFactory(new NullOnEmptyConverterFactory())
                    .addConverterFactory(GsonConverterFactory.create(new Gson())) //添加Gson支持
                    .addCallAdapterFactory(RxJava2CallAdapterFactory.create()) //添加RxJava支持
                    .client(builder.build()) //关联okhttp
                    .build();
        }

    }


    public static RetrofitHelper getInstance() {
        if(INSTANCE==null){
            INSTANCE = new RetrofitHelper();
        }
        return INSTANCE;
    }


    /**
     * kies) {
     * if(cookie.contains("SID=")&&c
     * 获取服务对象   Rxjava+Retrofit建立在接口对象的基础上的
     * 泛型避免强制转换
     */
    public static <T> T getService(Class<T> classz) {
        return RetrofitHelper.getInstance().mRetrofit.create(classz);
    }

    public Response responseS;

    class LoggingInterceptor implements Interceptor {
        @Override
        public Response intercept(Chain chain) throws IOException {
            Request request = chain.request();
            Request.Builder builder = request.newBuilder();
            setHeaderToken(builder);
            setHeaderBaseParams(builder);
            request = builder.build();
            return processResponse(chain.proceed(request));
        }

        //访问网络之后，处理Response(这里没有做特别处理)
        private Response processResponse(Response response) {
            responseS = response;
            doHttpCode(response);
            refreshToken(response);
            refreshCookies(response);
            return response;
        }

        public Response getResponse() {
            return responseS;
        }

        /**
         * 设置token
         *
         * @param builder
         */
        private void setHeaderToken(Request.Builder builder) {
            String token = DataCenter.getInstance().getUser().getToken();
            if (token != null) {
                builder.addHeader("token", DataCenter.getInstance().getUser().getToken());
            }
        }

        /**
         * 设置基本参数
         *
         * @param builder
         */
        private void setHeaderBaseParams(Request.Builder builder) {
            if (!BuildConfig.DEBUG) {
                builder.addHeader("Host", DataCenter.getInstance().getDomain());
            }
            builder.addHeader("User-Agent", "app_android");
            builder.addHeader("VersionName", PackageInfoUtil.getVersionName(BoxApplication.getContext()));//app版本号
            builder.addHeader("SysCode", Build.VERSION.RELEASE);// 系统版本号
            builder.addHeader("Brand", Build.BRAND);//手机品牌
            builder.addHeader("Model", Build.MODEL);//手机型号
            builder.addHeader("serialNo", DataCenter.getInstance().getSysInfo().getMac());
            if (DataCenter.getInstance().getSysInfo().getSid() != null) {
                builder.addHeader("Cookie", DataCenter.getInstance().getSysInfo().getSid());
            }
//            builder.addHeader("Connection", "close"); //关闭链接
        }

        /**
         * 处理http code
         *
         * @param response
         */
        private void doHttpCode(Response response) {
            // 处理http code
            int statusCode = response.code();
            //code直接返回
            RxBus.get().post(ConstantValue.RESPONSED_STATE_CODE, statusCode);
            if (statusCode != 200) {
                throw new CustomHttpException(statusCode);
            }
        }


        /**
         * 刷新token
         *
         * @param response
         */
        private void refreshToken(Response response) {
            // 处理token
            Headers headers = response.headers();
            String token = headers.get("token");
            if (token != null && !token.equals(DataCenter.getInstance().getUser().getToken())) {
                DataCenter.getInstance().getUser().setToken(token);
            }
        }
    }

    /**
     * 保存cookies
     *
     * @param response
     */
    private void refreshCookies(Response response) {
        // 处理token
        Headers headers = response.headers();
        List<String> cookies = headers.values("Set-Cookie");
        if (cookies != null && !cookies.isEmpty()) {
            for (String cookie : cookies) {
                if (cookie.contains("SID=") && cookie.length() > 80) {
                    String[] sids = cookie.split(";");
                    if (sids != null && sids.length > 0 && sids[0].length() > 80) {
                        DataCenter.getInstance().getSysInfo().setSid(cookie);
                        // CookieManager.getInstance().setCookie(DataCenter.getInstance().getDomain(), cookie);
                        break;
                    }
                }
            }
        }
    }


    public class ReceivedCookiesInterceptor implements Interceptor {
        @Override
        public Response intercept(Chain chain) throws IOException {
            Response originalResponse = chain.proceed(chain.request());

            if (!originalResponse.headers("Set-Cookie").isEmpty()) {
                HashSet<String> cookies = new HashSet<>();

                for (String header : originalResponse.headers("Set-Cookie")) {
                    cookies.add(header);
                }

                SharedPreferences.Editor config = BoxApplication.getContext().getSharedPreferences("config", BoxApplication.getContext().MODE_PRIVATE)
                        .edit();
                config.putStringSet("cookie", cookies);
                config.commit();
            }

            return originalResponse;
        }
    }


    public class AddCookiesInterceptor implements Interceptor {

        @Override
        public Response intercept(Chain chain) throws IOException {
            Request.Builder builder = chain.request().newBuilder();
            HashSet<String> preferences = (HashSet) BoxApplication.getContext().getSharedPreferences("config",
                    BoxApplication.getContext().MODE_PRIVATE).getStringSet("cookie", null);
            if (preferences != null) {
                for (String cookie : preferences) {
                    builder.addHeader("Cookie", cookie);
                    Log.v("OkHttp", "Adding Header: " + cookie); // This is done so I know which headers are being added; this interceptor is used after the normal logging of OkHttp
                }
            }
            return chain.proceed(builder.build());
        }
    }
}
