package com.dawoo.lotterybox.util;

import android.graphics.Color;

import com.dawoo.lotterybox.BoxApplication;
import com.dawoo.lotterybox.R;

import cn.aigestudio.datepicker.bizs.themes.DPTheme;

/**
 * 主题的默认实现类
 * <p>
 * The default implement of theme
 *
 * @author AigeStudio 2015-06-17
 */
public class DPBaseTheme extends DPTheme {
    @Override
    public int colorBG() {
        return 0xFFFFFFFF;
    }

    @Override
    public int colorBGCircle() {
        return BoxApplication.getContext().getResources().getColor(R.color.colorAccent);
    }

    @Override
    public int colorTitleBG() {
        return R.drawable.shape_title_bg;
    }

    @Override
    public int colorTitle() {
        return 0xEEFFFFFF;
    }

    @Override
    public int colorToday() {
        return 0xFFFFFFFF;
    }

    @Override
    public int colorG() {
        return 0xEE333333;
    }

    @Override
    public int colorF() {
         return 0xEE333333;
    }

    @Override
    public int colorWeekend() {
        return 0xEEF78082;
    }

    @Override
    public int colorHoliday() {
        return 0x80FED6D6;
    }

    @Override
    public int colorNotSelect() {
        return 0xff999999;
    }

    @Override
    public int colorCanSelect() {
        return 0xff81cfe1;
    }

    /**
     * 农历文本颜色
     * <p>
     * Color of Lunar text
     *
     * @return 16进制颜色值 hex color
     */
    @Override
    public int colorL() {
        return 0xEE888888;
    }

    /**
     * 补休日期背景颜色
     * <p>
     * Color of Deferred background
     *
     * @return 16进制颜色值 hex color
     */
    @Override
    public int colorDeferred() {
        return 0x50B48172;
    }
}
