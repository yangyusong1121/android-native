package cn.aigestudio.datepicker.bizs.themes;

/**
 * 主题的默认实现类
 * <p>
 * The default implement of theme
 *
 * @author AigeStudio 2015-06-17
 */
public class DPBaseTheme extends DPTheme {
    @Override
    public int colorBG() {
        return 0xFFFFFFFF;
    }

    @Override
    public int colorBGCircle() {
        return 0x44000000;
    }

    @Override
    public int colorTitleBG() {
        return 0xFF00c6ff;
    }

    @Override
    public int colorTitle() {
        return 0xEEFFFFFF;
    }

    @Override
    public int colorToday() {
        return 0x88F37B7A;
    }

    @Override
    public int colorG() {
        return 0xEE333333;
    }

    @Override
    public int colorF() {
        return 0xEEC08AA4;
    }

    @Override
    public int colorWeekend() {
        return 0xEEF78082;
    }

    @Override
    public int colorHoliday() {
        return 0x80FED6D6;
    }

    @Override
    public int colorNotSelect() {
        return 0xff999999;
    }

    @Override
    public int colorCanSelect() {
        return 0xff81cfe1;
    }
    /**
     * 农历文本颜色
     *
     * Color of Lunar text
     *
     * @return 16进制颜色值 hex color
     */
    @Override
    public int colorL() {
        return 0xEE888888;
    }

    /**
     * 补休日期背景颜色
     *
     * Color of Deferred background
     *
     * @return 16进制颜色值 hex color
     */
    @Override
    public int colorDeferred() {
        return 0x50B48172;
    }
}
